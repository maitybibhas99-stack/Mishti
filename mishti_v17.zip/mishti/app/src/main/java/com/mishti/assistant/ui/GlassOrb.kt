package com.mishti.assistant.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.sin

private val Tau = (2.0 * PI).toFloat()

private val DeepBlue = Color(0xFF0A2A8F)
private val RoyalBlue = Color(0xFF2F7BFF)
private val SkyBlue = Color(0xFF58B8FF)
private val IceBlue = Color(0xFFBFE8FF)
private val Night = Color(0xFF040A1E)

/**
 * A 3D glass sphere: dark glassy body, bright blue light ribbons flowing inside, a glowing rim,
 * highlights and a soft reflection under it. It breathes by itself and swells with sound.
 *
 * [level] is read only while drawing. [energy]: about 0.3 asleep, 0.6 listening, 1.0 speaking.
 * The sphere is sized from the smaller side of the box, so the box can be animated small or big.
 */
@Composable
fun GlassOrb(
    modifier: Modifier = Modifier,
    level: () -> Float = { 0f },
    energy: Float = 0.6f,
) {
    val clock = rememberInfiniteTransition(label = "glassOrb")
    val spin = clock.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(20000, easing = LinearEasing), RepeatMode.Restart),
        label = "spin"
    )
    val flow = clock.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart),
        label = "flow"
    )
    val breath = clock.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4800, easing = LinearEasing), RepeatMode.Restart),
        label = "breath"
    )

    Canvas(modifier) {
        val lv = level().coerceIn(0f, 1f)
        val e = energy.coerceIn(0f, 1f)
        val c = Offset(size.width / 2f, size.height / 2f)
        val reach = size.minDimension / 2f
        val br = sin(breath.value * Tau)
        val ph = flow.value * Tau
        val sp = spin.value * Tau
        val r = reach * 0.60f * (1f + 0.030f * br + 0.12f * lv)

        // Wide soft glow around the sphere.
        drawCircle(
            brush = Brush.radialGradient(
                0f to RoyalBlue.copy(alpha = 0.40f + 0.25f * lv),
                0.45f to DeepBlue.copy(alpha = 0.22f + 0.10f * e),
                1f to Color.Transparent,
                center = c,
                radius = reach
            ),
            radius = reach,
            center = c
        )

        // Reflection on the "floor" under the sphere.
        val refW = r * 1.5f
        val refH = r * 0.20f
        drawOval(
            brush = Brush.radialGradient(
                0f to SkyBlue.copy(alpha = 0.30f + 0.20f * lv),
                1f to Color.Transparent,
                center = Offset(c.x, c.y + r * 1.18f),
                radius = refW / 2f
            ),
            topLeft = Offset(c.x - refW / 2f, c.y + r * 1.18f - refH / 2f),
            size = Size(refW, refH)
        )

        // Dark glass body, lit from the top left.
        drawCircle(
            brush = Brush.radialGradient(
                0f to Color(0xFF123C9A).copy(alpha = 0.70f),
                0.55f to Night.copy(alpha = 0.92f),
                1f to Color(0xFF02050F),
                center = Offset(c.x - r * 0.25f, c.y - r * 0.30f),
                radius = r * 1.45f
            ),
            radius = r,
            center = c
        )

        val body = Path().apply { addOval(Rect(c, r)) }
        clipPath(body) {
            // Flowing ribbons of light.
            val ribbons = 5
            for (j in 0 until ribbons) {
                val col = when (j % 3) {
                    0 -> SkyBlue
                    1 -> RoyalBlue
                    else -> IceBlue
                }
                val dir = if (j % 2 == 0) 1f else -1f
                val deg = Math.toDegrees((sp * (0.5f + 0.2f * j)).toDouble()).toFloat() * dir + j * 37f
                rotate(degrees = deg, pivot = c) {
                    val path = Path()
                    val n = 40
                    for (i in 0..n) {
                        val t = i / n.toFloat()
                        val x = c.x + (t * 2f - 1f) * r * 1.08f
                        val taper = sin(t * PI.toFloat())
                        val swing = r * (0.26f + 0.20f * e + 0.30f * lv)
                        val y = c.y + swing * taper *
                            sin(t * Tau * (0.9f + 0.25f * j) + ph * (1f + 0.2f * j) + j * 1.3f)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    val w = r * (0.045f + 0.012f * j)
                    drawPath(
                        path = path,
                        color = col.copy(alpha = 0.10f),
                        style = Stroke(width = w * 5f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Plus
                    )
                    drawPath(
                        path = path,
                        color = col.copy(alpha = 0.22f),
                        style = Stroke(width = w * 2.4f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Plus
                    )
                    drawPath(
                        path = path,
                        color = Color.White.copy(alpha = 0.55f),
                        style = Stroke(width = w * 0.7f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Plus
                    )
                }
            }
            // Light gathering at the bottom right, like glass catching a lamp.
            val glowC = Offset(c.x + r * 0.55f, c.y + r * 0.60f)
            drawCircle(
                brush = Brush.radialGradient(
                    0f to SkyBlue.copy(alpha = 0.55f + 0.20f * lv),
                    1f to Color.Transparent,
                    center = glowC,
                    radius = r * 0.95f
                ),
                radius = r * 0.95f,
                center = glowC,
                blendMode = BlendMode.Plus
            )
        }

        // Soft outer rim, then a bright turning edge.
        drawCircle(
            color = SkyBlue.copy(alpha = 0.22f + 0.15f * lv),
            radius = r,
            center = c,
            style = Stroke(width = r * 0.10f)
        )
        rotate(degrees = Math.toDegrees(sp.toDouble()).toFloat(), pivot = c) {
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        IceBlue,
                        SkyBlue.copy(alpha = 0.25f),
                        Color.Transparent,
                        RoyalBlue.copy(alpha = 0.70f),
                        IceBlue
                    ),
                    center = c
                ),
                radius = r,
                center = c,
                style = Stroke(width = r * 0.035f),
                blendMode = BlendMode.Plus
            )
        }

        // A faint second ring that swells with the voice.
        drawCircle(
            color = IceBlue.copy(alpha = 0.10f + 0.25f * lv),
            radius = r * (1.10f + 0.10f * lv),
            center = c,
            style = Stroke(width = r * 0.012f)
        )

        // Highlights: a crescent on the top left and a small bright spot.
        drawArc(
            color = Color.White.copy(alpha = 0.75f),
            startAngle = 200f,
            sweepAngle = 62f,
            useCenter = false,
            topLeft = Offset(c.x - r * 0.90f, c.y - r * 0.90f),
            size = Size(r * 1.80f, r * 1.80f),
            style = Stroke(width = r * 0.05f, cap = StrokeCap.Round)
        )
        val spot = Offset(c.x - r * 0.45f, c.y - r * 0.58f)
        drawCircle(
            brush = Brush.radialGradient(
                0f to Color.White.copy(alpha = 0.85f),
                1f to Color.Transparent,
                center = spot,
                radius = r * 0.13f
            ),
            radius = r * 0.13f,
            center = spot
        )
    }
}

/**
 * Blue light that rises from the bottom edge of the screen, behind the typing bar.
 * It breathes slowly and climbs a little when someone speaks.
 */
@Composable
fun BlueGlow(
    modifier: Modifier = Modifier,
    level: () -> Float = { 0f },
    energy: Float = 0.6f,
) {
    val clock = rememberInfiniteTransition(label = "blueGlow")
    val breath = clock.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(5200, easing = LinearEasing), RepeatMode.Restart),
        label = "breath"
    )
    Canvas(modifier) {
        val lv = level().coerceIn(0f, 1f)
        val e = energy.coerceIn(0.2f, 1f)
        val br = 0.5f + 0.5f * sin(breath.value * Tau)
        val a = (0.60f + 0.15f * br + 0.25f * lv) * (0.6f + 0.4f * e)
        val w = size.width
        val h = size.height
        drawRect(
            brush = Brush.verticalGradient(
                0f to Color.Transparent,
                0.55f to Color(0xFF0A2C8A).copy(alpha = 0.35f * a),
                1f to RoyalBlue.copy(alpha = 0.85f * a)
            )
        )
        val c = Offset(w / 2f, h)
        drawCircle(
            brush = Brush.radialGradient(
                0f to SkyBlue.copy(alpha = 0.55f * a),
                1f to Color.Transparent,
                center = c,
                radius = w * 0.85f
            ),
            radius = w * 0.85f,
            center = c
        )
    }
}
