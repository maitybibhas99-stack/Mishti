package com.mishti.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.mishti.assistant.ui.HomeScreen
import com.mishti.assistant.ui.MishtiTheme
import com.mishti.assistant.ui.SettingsScreen
import com.mishti.assistant.ui.VoiceScreen

class MainActivity : ComponentActivity() {

    private val vm: Assistant
        get() = (application as MishtiApplication).assistant

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MishtiTheme {
                MishtiApp(vm)
            }
        }
        handleWake(intent)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWake(intent)
    }

    /** Tapped the "Mishti ghumiye ache" note after a restart: start listening, no orb screen. */
    private fun handleWake(intent: android.content.Intent?) {
        if (intent?.getBooleanExtra("wake", false) != true) return
        intent.removeExtra("wake")
        val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (micOk) vm.prepareWake()
    }
}

@Composable
private fun MishtiApp(vm: Assistant) {
    val ui by vm.ui.collectAsState()
    val wakeStatus by vm.wakeStatus.collectAsState()
    val context = LocalContext.current
    // Opening the app (re)starts the "Hey Mishti" listener if that mode is on.
    LaunchedEffect(Unit) { vm.prepareWake() }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val micOk = result[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        // Contacts / call / SMS can stay denied; Mishti will say so when asked to use them.
        if (micOk) {
            vm.startListening()
            vm.prepareWake()
        }
    }

    fun startVoice() {
        if (ui.listening) {
            vm.showVoice()
            return
        }
        val wanted = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS
        ) + (if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.POST_NOTIFICATIONS) else emptyArray<String>())
        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) vm.startListening() else permissionLauncher.launch(missing.toTypedArray())
    }

    var showSettings by remember { mutableStateOf(false) }
    BackHandler(enabled = showSettings) { showSettings = false }

    Box(Modifier) {
        HomeScreen(
            ui = ui,
            userName = vm.prefs.userName,
            level = { vm.level.floatValue },
            onSend = vm::sendText,
            onVoice = { startVoice() },
            onOff = vm::turnOff,
            onNewChat = vm::newChat,
            onSettings = { showSettings = true },
        )
        AnimatedVisibility(visible = showSettings, enter = fadeIn(), exit = fadeOut()) {
            SettingsScreen(
                prefs = vm.prefs,
                wakeStatus = wakeStatus,
                onSaved = {
                    vm.dismissError()
                    vm.prepareWake()
                    showSettings = false
                },
                onBack = { showSettings = false },
            )
        }
        AnimatedVisibility(visible = ui.voiceOpen, enter = fadeIn(), exit = fadeOut()) {
            VoiceScreen(
                ui = ui,
                level = { vm.level.floatValue },
                onHide = vm::hideVoice,
                onToggleMute = vm::toggleMute,
                onOff = vm::stopListening,
            )
        }
    }
}
