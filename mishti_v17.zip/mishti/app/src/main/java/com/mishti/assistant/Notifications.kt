package com.mishti.assistant

enum class NotifKind { IMPORTANT, MESSAGE, JUNK, OTHER }

data class NotifInfo(
    val id: String,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val kind: NotifKind,
    /** OTP / bank: Mishti says that it came, but does not read the numbers aloud unless asked. */
    val sensitive: Boolean,
)

/** Sorts a notification into: a message from a person, something to just mention, junk, or other. */
object NotifClassifier {

    private val chatApps = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "org.telegram.plus",
        "com.facebook.orca", "com.facebook.mlite", "org.thoughtcrime.securesms",
        "com.google.android.apps.messaging", "com.android.mms", "com.samsung.android.messaging",
        "com.miui.mms", "com.oneplus.mms", "com.instagram.android", "com.snapchat.android",
        "com.discord", "com.google.android.apps.dynamite", "com.truecaller"
    )

    private val callCategories = setOf("call", "missed_call")

    private val sensitiveRx = Regex(
        "\\b(otp|one[- ]time (password|pin)|verification code|security code|passcode|cvv|login code)\\b"
    )
    private val bankRx = Regex(
        "(debited|credited|a/c|acct|upi|txn|transaction|withdrawn|spent (rs|inr|₹)|available balance|emi due|statement)"
    )

    private val junkWords = listOf(
        "% off", "sale", "offer", "discount", "cashback", "coupon", "deal of", "deals", "limited time",
        "exclusive", "hurry", "order now", "shop now", "buy now", "you've won", "you have won", "reward",
        "free gift", "sponsored", "recommended for you", "trending", "new arrival", "recharge now",
        "pre-approved", "subscribe", "download now", "flat ", "upto ", "up to ", "special price",
        "last chance", "ends today", "grab now", "claim now", "bonus", "lucky"
    )

    fun isSensitive(text: String): Boolean {
        val t = text.lowercase()
        return sensitiveRx.containsMatchIn(t) || bankRx.containsMatchIn(t)
    }

    fun classify(pkg: String, category: String?, title: String, text: String): NotifKind {
        val t = ("$title $text").lowercase()
        if (isSensitive(t)) return NotifKind.IMPORTANT
        if (category != null && category in callCategories) return NotifKind.IMPORTANT
        if (pkg in chatApps) return NotifKind.IMPORTANT
        if (category == "promo" || category == "recommendation") return NotifKind.JUNK
        if (junkWords.any { t.contains(it) }) return NotifKind.JUNK
        if (category == "msg" || category == "email") return NotifKind.MESSAGE
        return NotifKind.OTHER
    }
}
