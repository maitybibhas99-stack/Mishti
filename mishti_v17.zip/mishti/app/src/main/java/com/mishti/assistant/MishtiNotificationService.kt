package com.mishti.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Lets Mishti see new notifications so she can tell him about messages, clear junk, and reply.
 * The user turns it on in Settings > Notification access.
 */
class MishtiNotificationService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: MishtiNotificationService? = null
            private set
    }

    private val ids = ConcurrentHashMap<String, String>() // short id -> notification key
    private val seen = ConcurrentHashMap<String, Long>()

    override fun onListenerConnected() {
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (!relevant(sbn)) return
            val info = describe(sbn) ?: return
            val sig = sbn.key + "|" + info.title + "|" + info.text
            val now = System.currentTimeMillis()
            val before = seen[sig]
            if (before != null && now - before < 60_000) return
            if (seen.size > 300) seen.clear()
            seen[sig] = now
            (application as MishtiApplication).assistant.onNotification(info)
        } catch (_: Exception) {
        }
    }

    /** Skips Mishti's own, ongoing (music, downloads, running services) and group-summary notifications. */
    private fun relevant(sbn: StatusBarNotification): Boolean {
        if (sbn.packageName == packageName) return false
        val n = sbn.notification
        if (sbn.isOngoing) return false
        val bad = Notification.FLAG_GROUP_SUMMARY or Notification.FLAG_FOREGROUND_SERVICE
        return (n.flags and bad) == 0
    }

    private fun describe(sbn: StatusBarNotification): NotifInfo? {
        val n = sbn.notification
        val ex = n.extras
        val title = (ex.getCharSequence(Notification.EXTRA_TITLE)
            ?: ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE))?.toString().orEmpty().trim()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty().trim()
        if (title.isEmpty() && text.isEmpty()) return null
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        val id = "n" + (sbn.key.hashCode() and 0xFFFFF).toString(36)
        ids[id] = sbn.key
        val kind = NotifClassifier.classify(sbn.packageName, n.category, title, text)
        return NotifInfo(
            id = id,
            pkg = sbn.packageName,
            app = app,
            title = title.take(120),
            text = text.take(400),
            kind = kind,
            sensitive = NotifClassifier.isSensitive("$title $text")
        )
    }

    private fun active(): List<StatusBarNotification> =
        try {
            activeNotifications.filter { relevant(it) }.sortedByDescending { it.postTime }
        } catch (e: Exception) {
            emptyList()
        }

    // ------------------------------------------------------------------ tools

    fun list(limit: Int): JSONObject {
        val arr = JSONArray()
        active().mapNotNull { describe(it) }.take(limit.coerceIn(1, 15)).forEach { n ->
            arr.put(
                JSONObject()
                    .put("id", n.id)
                    .put("app", n.app)
                    .put("title", n.title)
                    .put("text", n.text.take(300))
                    .put("kind", n.kind.name.lowercase())
            )
        }
        return JSONObject().put("status", "ok").put("notifications", arr)
    }

    fun dismiss(id: String): JSONObject {
        val k = id.trim().lowercase()
        return when (k) {
            "junk" -> {
                var count = 0
                active().forEach { sbn ->
                    val d = describe(sbn)
                    if (d != null && d.kind == NotifKind.JUNK) {
                        cancelNotification(sbn.key)
                        count++
                    }
                }
                ok("$count ta faltu notification uriye dilam.")
            }
            "all" -> {
                cancelAllNotifications()
                ok("Shob notification muchhe dilam.")
            }
            else -> {
                val key = ids[k] ?: return fail("'$id' notification ar nei. read_notifications diye dekho.")
                cancelNotification(key)
                ok("Notification uriye dilam.")
            }
        }
    }

    private fun find(id: String): StatusBarNotification? {
        val key = ids[id.trim().lowercase()] ?: return null
        return active().firstOrNull { it.key == key }
    }

    /** Sends a reply through the notification's own reply box (WhatsApp, Telegram, SMS...). */
    fun reply(id: String, text: String): JSONObject {
        if (text.isBlank()) return fail("Ki reply debo?")
        val sbn = find(id) ?: return fail("Notification-ta ar nei. read_notifications diye dekho.")
        val action = sbn.notification.actions
            ?.firstOrNull { it.remoteInputs?.isNotEmpty() == true && it.actionIntent != null }
            ?: return fail("Ei notification-e sorasori reply kora jay na. App khule reply koro.")
        val inputs = action.remoteInputs
        val results = Bundle()
        inputs.forEach { results.putCharSequence(it.resultKey, text) }
        val intent = Intent()
        RemoteInput.addResultsToIntent(inputs, intent, results)
        return try {
            action.actionIntent.send(this, 0, intent)
            ok("Reply pathano hoyeche.")
        } catch (e: Exception) {
            fail("Reply jayni: ${e.message}")
        }
    }

    fun openIt(id: String): JSONObject {
        val sbn = find(id) ?: return fail("Notification-ta ar nei.")
        val pi = sbn.notification.contentIntent ?: return fail("Ei notification khola jay na.")
        return try {
            pi.send()
            ok("Khola hocche.")
        } catch (e: Exception) {
            fail("Khola gelo na: ${e.message}")
        }
    }

    private fun ok(m: String) = JSONObject().put("status", "ok").put("message", m)
    private fun fail(m: String) = JSONObject().put("status", "error").put("message", m)
}
