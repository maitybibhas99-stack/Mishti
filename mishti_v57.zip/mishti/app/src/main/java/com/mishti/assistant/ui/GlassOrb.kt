package com.mishti.assistant.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val Tau = (2.0 * PI).toFloat()

private val DeepBlue = Color(0xFF0A2A8F)
private val RoyalBlue = Color(0xFF2F7BFF)
private val SkyBlue = Color(0xFF58B8FF)
private val IceBlue = Color(0xFFBFE8FF)
private val Night = Color(0xFF040A1E)

/**
 * A 3D glass sphere: dark glassy body, bright blue light ribbons flowing inside, a glowing rim,
 * highlights and a soft reflection under it. It breathes by itself and swells with sound.
 *
 * [level] is read only while drawing. [energy]: about 0.3 asleep, 0.6 listening, 1.0 speaking.
 * The sphere is sized from the smaller side of the box, so the box can be animated small or big.
 */
/** The three slow clocks of the orb. When [animate] is false they stand still, so nothing redraws 60 times a second (saves heat and battery). */
@Composable
private fun orbClocks(animate: Boolean): List<State<Float>> {
    if (!animate) {
        return listOf(
            remember { mutableStateOf(0f) },
            remember { mutableStateOf(0.3f) },
            remember { mutableStateOf(0f) },
        )
    }
    val clock = rememberInfiniteTransition(label = "glassOrb")
    val spin = clock.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(20000, easing = LinearEasing), RepeatMode.Restart), label = "spin"
    )
    val flow = clock.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart), label = "flow"
    )
    val breath = clock.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4800, easing = LinearEasing), RepeatMode.Restart), label = "breath"
    )
    return listOf(spin, flow, breath)
}

@Composable
fun GlassOrb(
    modifier: Modifier = Modifier,
    level: () -> Float = { 0f },
    energy: Float = 0.6f,
    animate: Boolean = true,
) {
    val clocks = orbClocks(animate)
    val spin = clocks[0]
    val flow = clocks[1]
    val breath = clocks[2]

    Canvas(modifier) {
        val lv = level().coerceIn(0f, 1f)
        val e = energy.coerceIn(0f, 1f)
        val reach = size.minDimension / 2f
        // The sphere floats: a slow gentle bob, like a drop hanging in water.
        val c = Offset(size.width / 2f, size.height / 2f + reach * 0.025f * sin(breath.value * Tau))
        val br = sin(breath.value * Tau)
        val ph = flow.value * Tau
        val sp = spin.value * Tau
        val r = reach * 0.60f * (1f + 0.030f * br + 0.12f * lv)

        // Wide soft glow around the sphere.
        drawCircle(
            brush = Brush.radialGradient(
                0f to RoyalBlue.copy(alpha = 0.40f + 0.25f * lv),
                0.45f to DeepBlue.copy(alpha = 0.22f + 0.10f * e),
                1f to Color.Transparent,
                center = c,
                radius = reach
            ),
            radius = reach,
            center = c
        )

        // Liquid ripples that spread out from the sphere, stronger when it is speaking.
        for (k in 0 until 3) {
            val tt = (flow.value * 3f + k / 3f) % 1f
            val a = (1f - tt) * (1f - tt) * (0.07f + 0.26f * lv + 0.07f * e)
            val rr = r * (1.05f + 0.60f * tt) * 1.15f
            // A soft wave of light, no hard edge.
            drawCircle(
                brush = Brush.radialGradient(
                    0f to Color.Transparent,
                    0.70f to Color.Transparent,
                    0.87f to SkyBlue.copy(alpha = a * 1.6f),
                    1f to Color.Transparent,
                    center = c,
                    radius = rr
                ),
                radius = rr,
                center = c
            )
        }

        // Reflection on the "floor" under the sphere.
        val refW = r * 1.5f
        val refH = r * 0.20f
        drawOval(
            brush = Brush.radialGradient(
                0f to SkyBlue.copy(alpha = 0.30f + 0.20f * lv),
                1f to Color.Transparent,
                center = Offset(c.x, c.y + r * 1.18f),
                radius = refW / 2f
            ),
            topLeft = Offset(c.x - refW / 2f, c.y + r * 1.18f - refH / 2f),
            size = Size(refW, refH)
        )

        // Dark glass body, lit from the top left.
        drawCircle(
            brush = Brush.radialGradient(
                0f to Color(0xFF0B2468).copy(alpha = 0.55f),
                0.55f to Night.copy(alpha = 0.90f),
                1f to Color(0xFF02050F),
                center = Offset(c.x - r * 0.25f, c.y - r * 0.30f),
                radius = r * 1.45f
            ),
            radius = r,
            center = c
        )

        val body = Path().apply { addOval(Rect(c, r)) }
        clipPath(body) {
            // Ribbons of light that wrap round the sphere. Each one is a tilted, wobbling loop on the
            // sphere's surface, projected flat; the far side is skipped and the light is brightest at the edge.
            val ribbons = 4
            val n = 70
            for (j in 0 until ribbons) {
                val col = when (j % 3) {
                    0 -> SkyBlue
                    1 -> RoyalBlue
                    else -> IceBlue
                }
                val tiltA = 0.9f + j * 0.75f + 0.25f * sin(ph + j)
                val tiltB = 0.5f + j * 0.9f
                val spin = sp * (0.7f + 0.25f * j) * (if (j % 2 == 0) 1f else -1f)
                val amp = 0.55f + 0.20f * e + 0.25f * lv
                var px = 0f
                var py = 0f
                var pAlpha = -1f
                for (i in 0..n) {
                    val th = i * Tau / n + spin
                    val phi = amp * sin(2f * th + ph * (1f + 0.3f * j) + j)
                    // point on the unit sphere
                    var x = kotlin.math.cos(phi) * kotlin.math.cos(th)
                    var y = sin(phi)
                    var z = kotlin.math.cos(phi) * sin(th)
                    // tilt the loop in space
                    val y1 = y * kotlin.math.cos(tiltA) - z * sin(tiltA)
                    val z1 = y * sin(tiltA) + z * kotlin.math.cos(tiltA)
                    val x2 = x * kotlin.math.cos(tiltB) + z1 * sin(tiltB)
                    val z2 = -x * sin(tiltB) + z1 * kotlin.math.cos(tiltB)
                    x = x2; y = y1; z = z2
                    val sx = c.x + x * r * 0.97f
                    val sy = c.y + y * r * 0.97f
                    val front = z > -0.15f
                    val rim = 1f - kotlin.math.abs(z).coerceIn(0f, 1f)
                    val al = if (front) (0.35f + 0.65f * rim * rim) else 0f
                    if (i > 0 && pAlpha > 0f && al > 0f) {
                        val a2 = (pAlpha + al) / 2f
                        val w = r * (0.030f + 0.030f * rim) * (1f + 0.6f * lv)
                        drawLine(col.copy(alpha = 0.16f * a2), Offset(px, py), Offset(sx, sy),
                            strokeWidth = w * 4.5f, cap = StrokeCap.Round, blendMode = BlendMode.Plus)
                        drawLine(Color.White.copy(alpha = 0.60f * a2), Offset(px, py), Offset(sx, sy),
                            strokeWidth = w * 0.8f, cap = StrokeCap.Round, blendMode = BlendMode.Plus)
                    }
                    px = sx; py = sy; pAlpha = al
                }
            }
            // Small bubbles drift up through the liquid, each with its own speed, a thin rim and a tiny glint.
            for (b in 0 until 6) {
                val t = (flow.value * (1f + 0.35f * b) + b * 0.17f) % 1f
                val bx = c.x + sin(b * 2.3f + ph * 0.5f) * r * 0.55f
                val by = c.y + r * 0.85f - t * r * 1.7f
                val rad = r * (0.035f + 0.02f * (b % 3))
                val fade = sin(t * Tau / 2f).coerceIn(0f, 1f)
                drawCircle(IceBlue.copy(alpha = 0.30f * fade), rad, Offset(bx, by),
                    style = Stroke(width = r * 0.010f), blendMode = BlendMode.Plus)
                drawCircle(Color.White.copy(alpha = 0.60f * fade), rad * 0.28f,
                    Offset(bx - rad * 0.35f, by - rad * 0.35f), blendMode = BlendMode.Plus)
            }
            // Fresnel rim: glass glows at the edge, strongest on the side facing the light (right/bottom).
            drawCircle(
                brush = Brush.radialGradient(
                    0.60f to Color.Transparent,
                    0.86f to RoyalBlue.copy(alpha = 0.22f),
                    1.00f to SkyBlue.copy(alpha = 0.80f),
                    center = Offset(c.x - r * 0.22f, c.y - r * 0.18f),
                    radius = r * 1.20f
                ),
                radius = r,
                center = c,
                blendMode = BlendMode.Plus
            )
            // Light gathering at the bottom right.
            val glowC = Offset(c.x + r * 0.62f, c.y + r * 0.55f)
            drawCircle(
                brush = Brush.radialGradient(
                    0f to IceBlue.copy(alpha = 0.50f + 0.20f * lv),
                    0.4f to SkyBlue.copy(alpha = 0.25f),
                    1f to Color.Transparent,
                    center = glowC,
                    radius = r * 0.85f
                ),
                radius = r * 0.85f,
                center = glowC,
                blendMode = BlendMode.Plus
            )
            // A hint of violet low on the left, like the reference.
            val vio = Offset(c.x - r * 0.45f, c.y + r * 0.70f)
            drawCircle(
                brush = Brush.radialGradient(
                    0f to Color(0xFF8A5CFF).copy(alpha = 0.35f),
                    1f to Color.Transparent,
                    center = vio,
                    radius = r * 0.55f
                ),
                radius = r * 0.55f,
                center = vio,
                blendMode = BlendMode.Plus
            )
        }

        // No outline: the sphere melts into a soft glow that breathes, and two lights flow around its side.
        drawCircle(
            brush = Brush.radialGradient(
                0f to Color.Transparent,
                0.70f to Color.Transparent,
                0.76f to SkyBlue.copy(alpha = 0.22f + 0.30f * lv + 0.06f * br),
                0.88f to RoyalBlue.copy(alpha = 0.10f + 0.10f * lv),
                1f to Color.Transparent,
                center = c,
                radius = r * 1.38f
            ),
            radius = r * 1.38f,
            center = c,
            blendMode = BlendMode.Plus
        )
        for (k in 0 until 2) {
            val ang = sp * (if (k == 0) 0.5f else -0.35f) + k * 2.4f
            val pc = Offset(c.x + cos(ang) * r * 0.93f, c.y + sin(ang) * r * 0.93f)
            drawCircle(
                brush = Brush.radialGradient(
                    0f to IceBlue.copy(alpha = 0.55f + 0.30f * lv),
                    0.45f to SkyBlue.copy(alpha = 0.22f),
                    1f to Color.Transparent,
                    center = pc,
                    radius = r * 0.55f
                ),
                radius = r * 0.55f,
                center = pc,
                blendMode = BlendMode.Plus
            )
        }

        // A soft highlight on the top left (no hard line).
        val hl = Offset(c.x - r * 0.52f, c.y - r * 0.60f)
        drawCircle(
            brush = Brush.radialGradient(
                0f to Color.White.copy(alpha = 0.40f),
                1f to Color.Transparent,
                center = hl,
                radius = r * 0.50f
            ),
            radius = r * 0.50f,
            center = hl,
            blendMode = BlendMode.Plus
        )
        val spot = Offset(c.x - r * 0.45f, c.y - r * 0.58f)
        drawCircle(
            brush = Brush.radialGradient(
                0f to Color.White.copy(alpha = 0.85f),
                1f to Color.Transparent,
                center = spot,
                radius = r * 0.13f
            ),
            radius = r * 0.13f,
            center = spot
        )
    }
}

/**
 * Blue light that rises from the bottom edge of the screen, behind the typing bar.
 * It breathes slowly and climbs a little when someone speaks.
 */
@Composable
fun BlueGlow(
    modifier: Modifier = Modifier,
    level: () -> Float = { 0f },
    energy: Float = 0.6f,
) {
    val clock = rememberInfiniteTransition(label = "blueGlow")
    val breath = clock.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(5200, easing = LinearEasing), RepeatMode.Restart),
        label = "breath"
    )
    Canvas(modifier) {
        val lv = level().coerceIn(0f, 1f)
        val e = energy.coerceIn(0.2f, 1f)
        val br = 0.5f + 0.5f * sin(breath.value * Tau)
        val a = (0.60f + 0.15f * br + 0.25f * lv) * (0.6f + 0.4f * e)
        val w = size.width
        val h = size.height
        drawRect(
            brush = Brush.verticalGradient(
                0f to Color.Transparent,
                0.55f to Color(0xFF0A2C8A).copy(alpha = 0.35f * a),
                1f to RoyalBlue.copy(alpha = 0.85f * a)
            )
        )
        val c = Offset(w / 2f, h)
        drawCircle(
            brush = Brush.radialGradient(
                0f to SkyBlue.copy(alpha = 0.55f * a),
                1f to Color.Transparent,
                center = c,
                radius = w * 0.85f
            ),
            radius = w * 0.85f,
            center = c
        )
    }
}
