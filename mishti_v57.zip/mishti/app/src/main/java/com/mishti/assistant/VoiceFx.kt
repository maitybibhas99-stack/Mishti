package com.mishti.assistant

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Polishes Mishti's voice on the way to the speaker: removes rumble, shapes the tone (clarity, air, warmth),
 * lifts the loudness and keeps peaks from distorting. Works on 16-bit mono PCM and keeps its state between chunks.
 */
class VoiceFx(private val rate: Int, preset: String, private val gain: Float) {

    private class Biquad(var b0: Float, var b1: Float, var b2: Float, var a1: Float, var a2: Float) {
        private var x1 = 0f
        private var x2 = 0f
        private var y1 = 0f
        private var y2 = 0f
        fun run(x: Float): Float {
            val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1; x1 = x
            y2 = y1; y1 = y
            return y
        }
    }

    private val stages = ArrayList<Biquad>()

    init {
        when (preset) {
            "clear" -> {
                highPass(100.0)
                lowShelf(250.0, -1.5)
                peak(3200.0, 0.9, 2.5)
                highShelf(8000.0, 1.5)
            }
            "silky" -> {
                // Thin, light, airy: less low body, a soft lift in the presence, plenty of air on top.
                highPass(140.0)
                lowShelf(300.0, -4.0)
                peak(2600.0, 0.8, 1.2)
                peak(5200.0, 0.9, 1.5)
                highShelf(6500.0, 4.5)
            }
            "warm" -> {
                highPass(80.0)
                lowShelf(200.0, 2.0)
                peak(2000.0, 0.8, 1.0)
                highShelf(9000.0, -1.0)
            }
            else -> Unit // natural
        }
    }

    /** Processes little-endian 16-bit PCM and returns a new array. */
    fun process(pcm: ByteArray): ByteArray {
        if (stages.isEmpty() && abs(gain - 1f) < 0.01f) return pcm
        val out = ByteArray(pcm.size)
        var i = 0
        while (i + 1 < pcm.size) {
            var x = ((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF)).toShort().toInt() / 32768f
            for (s in stages) x = s.run(x)
            x *= gain
            // soft knee: gentle above 0.6 so louder speech never clips
            val a = abs(x)
            if (a > 0.6f) x = (if (x < 0) -1f else 1f) * (0.6f + 0.4f * tanh((a - 0.6f) / 0.4f))
            val v = (x * 32767f).toInt().coerceIn(-32768, 32767)
            out[i] = (v and 0xFF).toByte()
            out[i + 1] = ((v shr 8) and 0xFF).toByte()
            i += 2
        }
        return out
    }

    // ---- RBJ audio-EQ-cookbook filters ----

    private fun add(b0: Double, b1: Double, b2: Double, a0: Double, a1: Double, a2: Double) {
        stages.add(
            Biquad(
                (b0 / a0).toFloat(), (b1 / a0).toFloat(), (b2 / a0).toFloat(),
                (a1 / a0).toFloat(), (a2 / a0).toFloat()
            )
        )
    }

    private fun highPass(f: Double) {
        val w = 2 * PI * f / rate
        val alpha = sin(w) / (2 * 0.707)
        add((1 + cos(w)) / 2, -(1 + cos(w)), (1 + cos(w)) / 2, 1 + alpha, -2 * cos(w), 1 - alpha)
    }

    private fun peak(f: Double, q: Double, db: Double) {
        val a = 10.0.pow(db / 40)
        val w = 2 * PI * f / rate
        val alpha = sin(w) / (2 * q)
        add(1 + alpha * a, -2 * cos(w), 1 - alpha * a, 1 + alpha / a, -2 * cos(w), 1 - alpha / a)
    }

    private fun lowShelf(f: Double, db: Double) {
        val a = 10.0.pow(db / 40)
        val w = 2 * PI * f / rate
        val alpha = sin(w) / 2 * sqrt(2.0)
        val sq = 2 * sqrt(a) * alpha
        add(
            a * ((a + 1) - (a - 1) * cos(w) + sq),
            2 * a * ((a - 1) - (a + 1) * cos(w)),
            a * ((a + 1) - (a - 1) * cos(w) - sq),
            (a + 1) + (a - 1) * cos(w) + sq,
            -2 * ((a - 1) + (a + 1) * cos(w)),
            (a + 1) + (a - 1) * cos(w) - sq
        )
    }

    private fun highShelf(f: Double, db: Double) {
        val a = 10.0.pow(db / 40)
        val w = 2 * PI * f / rate
        val alpha = sin(w) / 2 * sqrt(2.0)
        val sq = 2 * sqrt(a) * alpha
        add(
            a * ((a + 1) + (a - 1) * cos(w) + sq),
            -2 * a * ((a - 1) + (a + 1) * cos(w)),
            a * ((a + 1) + (a - 1) * cos(w) - sq),
            (a + 1) - (a - 1) * cos(w) + sq,
            2 * ((a - 1) - (a + 1) * cos(w)),
            (a + 1) - (a - 1) * cos(w) - sq
        )
    }
}
