package com.mishti.assistant

import android.app.Application
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.mishti.assistant.ui.GlassOrb
import com.mishti.assistant.ui.MishtiTheme
import com.mishti.assistant.ui.liquid
import kotlinx.coroutines.delay

/** Lets Compose run inside a plain window (there is no Activity here). */
private class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)
    override val viewModelStore = ViewModelStore()
    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry

    fun start() {
        controller.performAttach()
        controller.performRestore(null)
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun stop() {
        registry.currentState = Lifecycle.State.DESTROYED
        viewModelStore.clear()
    }
}

/**
 * The small glowing orb that stays on screen over every app while Mishti is on.
 * Tap it for Stop / Mute / Hide. It is hidden while the Mishti app itself is open.
 */
object OrbOverlay {
    private val main = Handler(Looper.getMainLooper())
    private var view: ComposeView? = null
    private var owner: OverlayOwner? = null
    private var params: WindowManager.LayoutParams? = null
    private var wm: WindowManager? = null

    @Volatile private var appVisible = false
    @Volatile private var hidden = false
    @Volatile private var listening = false

    // where the orb sits (kept while the process lives)
    private var offsetX = 0
    private var offsetY = 0
    private var placed = false

    fun isAppVisible() = appVisible

    /** The Mishti app came to the front or left it. */
    fun appVisible(app: Application, vm: Assistant, visible: Boolean) {
        appVisible = visible
        // Coming back to the app, then leaving, shows the orb again even if it was hidden.
        if (visible) hidden = false
        sync(app, vm, listening)
    }

    fun sync(app: Application, vm: Assistant, isListening: Boolean) {
        listening = isListening
        main.post {
            if (listening && !appVisible && !hidden) show(app, vm) else remove()
        }
    }

    private fun hideForNow(app: Application, vm: Assistant) {
        hidden = true
        sync(app, vm, listening)
    }

    private fun show(app: Application, vm: Assistant) {
        if (view != null) return
        val svc = MishtiAccessibilityService.instance
        val ctx: Context
        val type: Int
        if (svc != null) {
            ctx = svc
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        } else if (Settings.canDrawOverlays(app)) {
            ctx = app
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            return // needs Accessibility or "Show over apps"
        }
        val density = ctx.resources.displayMetrics.density
        if (!placed) {
            offsetX = 0
            offsetY = (96 * density).toInt()
            placed = true
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        lp.x = offsetX
        lp.y = offsetY
        val o = OverlayOwner()
        val cv = ComposeView(ctx)
        cv.setViewTreeLifecycleOwner(o)
        cv.setViewTreeSavedStateRegistryOwner(o)
        cv.setViewTreeViewModelStoreOwner(o)
        cv.setContent {
            MishtiTheme(animated = false) {
                OverlayOrb(
                    vm = vm,
                    onStop = { vm.stopListening() },
                    onMute = { vm.toggleMute() },
                    onHide = { hideForNow(app, vm) },
                    onDrag = { dx, dy ->
                        offsetX += dx.toInt()
                        offsetY -= dy.toInt()
                        lp.x = offsetX
                        lp.y = offsetY
                        try { wm?.updateViewLayout(cv, lp) } catch (_: Exception) {}
                    }
                )
            }
        }
        try {
            o.start()
            val w = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            w.addView(cv, lp)
            wm = w; view = cv; owner = o; params = lp
        } catch (_: Exception) {
            o.stop()
        }
    }

    private fun remove() {
        val v = view ?: return
        try { wm?.removeView(v) } catch (_: Exception) {}
        owner?.stop()
        view = null; owner = null; params = null
    }
}

@Composable
private fun OverlayOrb(
    vm: Assistant,
    onStop: () -> Unit,
    onMute: () -> Unit,
    onHide: () -> Unit,
    onDrag: (Float, Float) -> Unit,
) {
    val ui by vm.ui.collectAsState()
    var open by remember { mutableStateOf(false) }
    LaunchedEffect(open) {
        if (open) {
            delay(6000)
            open = false
        }
    }
    val energy = when {
        ui.muted || ui.asleep -> 0.3f
        ui.phase == Phase.Speaking -> 1f
        else -> 0.6f
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        AnimatedVisibility(
            visible = open,
            enter = fadeIn() + scaleIn(initialScale = 0.6f),
            exit = fadeOut() + scaleOut(targetScale = 0.6f)
        ) {
            Row(
                Modifier.padding(bottom = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OrbAction(Icons.Default.Stop, "Stop", Color(0x66FF6B6B)) { onStop() }
                OrbAction(
                    if (ui.muted) Icons.Default.MicOff else Icons.Default.Mic,
                    if (ui.muted) "Unmute" else "Mute",
                    if (ui.muted) Color(0x66FFC857) else Color(0x33FFFFFF)
                ) { onMute() }
                OrbAction(Icons.Default.VisibilityOff, "Hide", Color(0x33FFFFFF)) { onHide() }
            }
        }
        GlassOrb(
            Modifier
                .size(100.dp)
                .pointerInput(Unit) { detectTapGestures { open = !open } }
                .pointerInput(Unit) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        onDrag(drag.x, drag.y)
                    }
                },
            level = { vm.level.floatValue },
            energy = energy,
            // Only move while she speaks or works; resting, the orb stands still so the phone stays cool.
            animate = ui.phase == Phase.Speaking || ui.activity != null
        )
    }
}

@Composable
private fun OrbAction(icon: ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(46.dp)
                .background(tint, CircleShape)
                .liquid(CircleShape, 1.3f)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = Color.White)
        }
        Text(label, color = Color.White, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
    }
}
