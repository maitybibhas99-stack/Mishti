package com.mishti.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.draw.drawWithContent
import kotlinx.coroutines.launch
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.graphicsLayer
import kotlin.math.PI
import kotlin.math.sin
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.random.Random

object MishtiColors {
    val Bg = Color(0xFF02040C)
    val Surface = Color(0xFF0E1630)
    val SurfaceHigh = Color(0xFF24315A)
    val Coral = Color(0xFFFF8A6B)
    val Accent = Color(0xFF58B8FF)
    val Good = Color(0xFF4ADE9A)
    val Text = Color(0xFFF4F7FF)
    val TextDim = Color(0xFF8FA0BF)
    val Danger = Color(0xFFE5484D)
}

@Composable
fun MishtiTheme(animated: Boolean = true, content: @Composable () -> Unit) {
    // One clock drives every liquid surface in the app, so many glass parts cost almost nothing extra.
    // The floating orb turns it off: a clock that runs all day makes the phone warm.
    val flow: State<Float> = if (animated) {
        val clock = rememberInfiniteTransition(label = "liquidClock")
        clock.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Restart),
            label = "flow"
        )
    } else {
        remember { mutableStateOf(0f) }
    }
    CompositionLocalProvider(LocalLiquidClock provides flow) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = MishtiColors.Bg,
            surface = MishtiColors.Surface,
            primary = MishtiColors.Accent,
            onBackground = MishtiColors.Text,
            onSurface = MishtiColors.Text,
        ),
        content = content
    )
    }
}

val LocalLiquidClock = compositionLocalOf<State<Float>> { mutableStateOf(0f) }

/**
 * Deep night background with a few faint coloured glows and a fine film grain,
 * so flat black becomes something with depth and texture.
 */
fun Modifier.auroraBackground(): Modifier = this
    .drawBehind {
        drawRect(MishtiColors.Bg)
        val w = size.width
        val h = size.height
        fun glow(color: Color, cx: Float, cy: Float, r: Float, a: Float) {
            drawCircle(
                brush = Brush.radialGradient(
                    0f to color.copy(alpha = a),
                    1f to Color.Transparent,
                    center = Offset(cx, cy),
                    radius = r
                ),
                radius = r,
                center = Offset(cx, cy)
            )
        }
        glow(Color(0xFF5A4CFF), w * 0.10f, h * 0.00f, w * 0.95f, 0.20f)
        glow(Color(0xFF2F7BFF), w * 1.00f, h * 0.40f, w * 0.75f, 0.12f)
        glow(Color(0xFF2F7BFF), w * 0.30f, h * 1.02f, w * 1.10f, 0.22f)
        val rnd = Random(11)
        repeat(900) {
            drawCircle(
                color = Color.White.copy(alpha = 0.025f + 0.035f * rnd.nextFloat()),
                radius = 0.7f,
                center = Offset(rnd.nextFloat() * w, rnd.nextFloat() * h)
            )
        }
    }


/**
 * Liquid glass, no blur: a clear body with a bright curved rim, a specular band on top,
 * a caustic glow at the bottom, a faint colour fringe on the edges and a soft light that drifts across.
 */
private fun outlinePath(outline: Outline): Path = Path().apply {
    when (outline) {
        is Outline.Rectangle -> addRect(outline.rect)
        is Outline.Rounded -> addRoundRect(outline.roundRect)
        is Outline.Generic -> addPath(outline.path)
    }
}

private fun DrawScope.drawGlass(shape: Shape, strength: Float, phase: Float, flow: Float = -1f) {
    val outline = shape.createOutline(size, layoutDirection, this)
    val path = outlinePath(outline)
    val s = strength
    val px = 1.dp.toPx()
    val w = size.width
    val h = size.height

    // clear body, a touch bluer at the bottom
    drawPath(
        path,
        Brush.verticalGradient(
            0f to Color.White.copy(alpha = 0.07f * s),
            0.6f to Color(0xFF8FB8FF).copy(alpha = 0.06f * s),
            1f to Color(0xFF6FA8FF).copy(alpha = 0.16f * s)
        )
    )
    // caustic: light gathered at the bottom, sliding slowly
    drawPath(
        path,
        Brush.radialGradient(
            0f to Color(0xFFBFE0FF).copy(alpha = 0.22f * s),
            1f to Color.Transparent,
            center = Offset(w * (0.3f + 0.4f * phase), h),
            radius = w * 0.5f
        )
    )
    // a soft band of light that drifts across like liquid
    val cx = w * (-0.2f + 1.4f * phase)
    drawPath(
        path,
        Brush.linearGradient(
            0f to Color.Transparent,
            0.5f to Color.White.copy(alpha = 0.13f * s),
            1f to Color.Transparent,
            start = Offset(cx - h, 0f),
            end = Offset(cx + h, h)
        )
    )
    // Clean liquid glass: smooth light drifts through it like liquid. No lines, no waves, no blur.
    if (flow >= 0f) {
        clipPath(path) {
            val tw = (2.0 * PI).toFloat()
            // two soft pools of light that wander slowly
            for (k in 0 until 2) {
                val a = flow * tw * (if (k == 0) 1f else -0.7f) + k * 2.1f
                val cx = w * (0.5f + 0.38f * sin(a))
                val cy = h * (0.55f + 0.30f * sin(a * 1.3f + 1f))
                val rad = maxOf(w, h) * (if (k == 0) 0.42f else 0.34f)
                drawPath(
                    path,
                    Brush.radialGradient(
                        0f to (if (k == 0) Color(0xFFBFE0FF) else Color(0xFF9FB8FF)).copy(alpha = 0.20f * s),
                        1f to Color.Transparent,
                        center = Offset(cx, cy),
                        radius = rad
                    )
                )
            }
            // a clear diagonal glint that glides across, like light crossing glass
            val gx = w * (-0.4f + 1.8f * ((flow * 1.3f) % 1f))
            drawPath(
                path,
                Brush.linearGradient(
                    0f to Color.Transparent,
                    0.40f to Color.White.copy(alpha = 0.0f),
                    0.5f to Color.White.copy(alpha = 0.20f * s),
                    0.60f to Color.White.copy(alpha = 0.0f),
                    1f to Color.Transparent,
                    start = Offset(gx - h * 0.9f, 0f),
                    end = Offset(gx + h * 0.9f, h)
                )
            )
        }
    }
    // thickness: the glass is a slab, so its lower edge is a little deeper and its top edge shows a bright ledge
    drawPath(
        path,
        Brush.verticalGradient(
            0.68f to Color.Transparent,
            1f to Color(0xFF0A2A66).copy(alpha = 0.16f * s)
        )
    )
    clipPath(path) {
        translate(top = 2.5f * px) {
            drawPath(path, Color.White.copy(alpha = 0.22f * s), style = Stroke(px * 1.1f))
        }
        translate(top = -2.5f * px) {
            drawPath(path, Color(0xFF9FD0FF).copy(alpha = 0.16f * s), style = Stroke(px * 1.1f))
        }
    }
    // specular band on the upper edge
    val bandH = minOf(h * 0.42f, 26.dp.toPx())
    val inset = minOf(h * 0.28f, 14.dp.toPx())
    if (w > 2 * inset + 4f) {
        drawRoundRect(
            brush = Brush.verticalGradient(
                0f to Color.White.copy(alpha = 0.30f * s),
                1f to Color.Transparent,
                endY = bandH
            ),
            topLeft = Offset(inset, 2f * px),
            size = Size(w - 2 * inset, bandH),
            cornerRadius = CornerRadius(bandH / 2f)
        )
    }
    // faint colour split at the edge, like light bending through glass
    translate(left = -px, top = -px * 0.6f) {
        drawPath(path, Color(0xFF39F2E0).copy(alpha = 0.28f * s), style = Stroke(px * 1.2f))
    }
    translate(left = px, top = px * 0.6f) {
        drawPath(path, Color(0xFFFF5FA8).copy(alpha = 0.20f * s), style = Stroke(px * 1.2f))
    }
    // inner glow just inside the edge
    drawPath(path, Color.White.copy(alpha = 0.10f * s), style = Stroke(px * 7f))
    // bright rim: strongest top left and bottom right
    drawPath(
        path,
        Brush.linearGradient(
            0f to Color.White.copy(alpha = 0.85f * s),
            0.35f to Color.White.copy(alpha = 0.15f),
            0.65f to Color.White.copy(alpha = 0.10f),
            1f to Color.White.copy(alpha = 0.55f * s),
            start = Offset.Zero,
            end = Offset(w, h)
        ),
        style = Stroke(px * 1.4f)
    )
}

/** Still liquid-glass surface. */
fun Modifier.glass(shape: Shape, strength: Float = 1f): Modifier = this
    .clip(shape)
    .drawBehind { drawGlass(shape, strength, 0.3f) }

/** Liquid glass whose light slowly flows across it. Use on a few things only (bar, buttons). */
fun Modifier.liquid(shape: Shape, strength: Float = 1f): Modifier = composed {
    val clock = LocalLiquidClock.current
    Modifier
        .clip(shape)
        .drawBehind {
            val fv = clock.value
            val p = 0.5f + 0.5f * sin(fv * (2.0 * PI).toFloat())
            drawGlass(shape, strength, p, fv)
        }
}


/** Springy press: the thing squashes a little under the finger and bounces back. Put it FIRST in the chain. */
fun Modifier.pressable(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val down by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        targetValue = if (down) 0.90f else 1f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 500f),
        label = "press"
    )
    // A ring of light spreads out from the thing you touched, like a drop landing on water.
    val ripple = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    Modifier
        .graphicsLayer {
            scaleX = sc
            scaleY = sc
        }
        .drawWithContent {
            drawContent()
            val t = ripple.value
            if (t < 1f) {
                val rr = maxOf(size.width, size.height) * (0.25f + 0.75f * t)
                drawCircle(
                    Color.White.copy(alpha = 0.30f * (1f - t)),
                    rr,
                    Offset(size.width / 2f, size.height / 2f),
                    style = Stroke(2.dp.toPx())
                )
            }
        }
        .clickable(interactionSource = src, indication = null, onClick = {
            scope.launch {
                ripple.snapTo(0f)
                ripple.animateTo(1f, tween(480))
            }
            onClick()
        })
}

/** Pops in with a fade, a rise and a small spring scale. [delayMs] staggers a row of things. */
@Composable
fun Appear(delayMs: Int = 0, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        if (delayMs > 0) delay(delayMs.toLong())
        shown = true
    }
    AnimatedVisibility(
        visible = shown,
        enter = fadeIn(tween(350)) +
            slideInVertically(spring(dampingRatio = 0.7f, stiffness = 300f)) { it / 3 } +
            scaleIn(spring(dampingRatio = 0.7f, stiffness = 300f), initialScale = 0.9f),
    ) { content() }
}

private val TwoPi = (2.0 * PI).toFloat()

/** Slow liquid light drifting behind everything. No blur: soft radial gradients on lazy loops. */
@Composable
fun LiquidBackground(modifier: Modifier = Modifier, level: () -> Float = { 0f }) {
    val clock = rememberInfiniteTransition(label = "liquidBg")
    val t = clock.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(30000, easing = LinearEasing), RepeatMode.Restart),
        label = "t"
    )
    Canvas(modifier) {
        val ph = t.value * TwoPi
        val lv = level().coerceIn(0f, 1f)
        val w = size.width
        val h = size.height
        val colors = listOf(
            Color(0xFF2F7BFF) to 0.16f,
            Color(0xFF5A4CFF) to 0.14f,
            Color(0xFF39F2E0) to 0.06f,
            Color(0xFFA16BFF) to 0.09f
        )
        colors.forEachIndexed { i, (col, a) ->
            val cx = w * (0.5f + 0.38f * sin(ph * (1f + 0.3f * i) + i * 1.7f))
            val cy = h * (0.5f + 0.40f * sin(ph * (0.7f + 0.2f * i) + i * 2.3f))
            val rad = w * (0.55f + 0.10f * sin(ph * 2f + i)) * (1f + 0.25f * lv)
            drawCircle(
                brush = Brush.radialGradient(
                    0f to col.copy(alpha = a + 0.06f * lv),
                    1f to Color.Transparent,
                    center = Offset(cx, cy),
                    radius = rad
                ),
                radius = rad,
                center = Offset(cx, cy)
            )
        }
    }
}
