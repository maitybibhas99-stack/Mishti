package com.mishti.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * On-device settings. Values typed in the Settings screen win; if empty, the
 * build-time values from local.properties (BuildConfig) are used as a fallback.
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("mishti", Context.MODE_PRIVATE)

    init {
        // v05 moved to a newer default model; forget any older model name saved by earlier versions.
        if (sp.getInt("schema", 0) < 15) {
            // v57: back to the calmer profile of the earlier versions: slower pace, natural pitch, clear tone.
            sp.edit().putFloat("voice_pitch", 1.05f).putFloat("voice_speed", 0.96f)
                .putString("voice_polish", "clear").putFloat("voice_loud", 1.3f).putInt("schema", 15).apply()
        }
        if (sp.getInt("schema", 0) < 14) {
            // v52: a thinner, airier, silkier young-woman voice by default.
            sp.edit().putFloat("voice_pitch", 1.15f).putString("voice_polish", "silky")
                .putFloat("voice_loud", 1.25f).putInt("schema", 14).apply()
        }
        if (sp.getInt("schema", 0) < 13) {
            sp.edit().putInt("silence_ms", 140).putInt("schema", 13).apply()
        }
        if (sp.getInt("schema", 0) < 11) {
            // Voice is fixed: lighter pitch, normal pace, clear tone. No chatter on its own.
            sp.edit().putFloat("voice_pitch", 1.12f).putFloat("voice_speed", 1.0f)
                .putString("voice_polish", "clear").putFloat("voice_loud", 1.3f)
                .putBoolean("spontaneous", false).putInt("schema", 11).apply()
        }
        if (sp.getInt("schema", 0) < 10) {
            // Brighter, higher default pitch.
            sp.edit().remove("voice_pitch").putInt("schema", 10).apply()
        }
        if (sp.getInt("schema", 0) < 9) {
            // New default model and a softer default voice: drop what older versions saved.
            sp.edit().remove("model").remove("voice").putBoolean("web_search", true)
                .remove("voice_pitch").remove("voice_speed").putInt("schema", 9).apply()
        }
    }

    var apiKey: String
        get() = sp.getString("api_key", "").orEmpty().ifBlank { BuildConfig.GEMINI_API_KEY }
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", "").orEmpty().ifBlank { BuildConfig.GEMINI_MODEL }
        set(v) = sp.edit().putString("model", v.trim()).apply()

    var voice: String
        get() = sp.getString("voice", "").orEmpty().ifBlank { BuildConfig.GEMINI_VOICE }
        set(v) = sp.edit().putString("voice", v.trim()).apply()

    var userName: String
        get() = sp.getString("user_name", "").orEmpty()
        set(v) = sp.edit().putString("user_name", v.trim()).apply()

    /** Pause length (ms) that ends the user's turn. 300 = fast, 800 = relaxed. */
    var silenceMs: Int
        get() = sp.getInt("silence_ms", 140)
        set(v) = sp.edit().putInt("silence_ms", v).apply()

    var webSearch: Boolean
        get() = sp.getBoolean("web_search", true)
        set(v) = sp.edit().putBoolean("web_search", v).apply()

    /** auto, bangla, hindi, english */
    var language: String
        get() = sp.getString("language", "bangla").orEmpty().let { if (it == "hindi") "hindi" else "bangla" }
        set(v) = sp.edit().putString("language", v).apply()

    /** True = Mishti answers only when she hears her name. */
    var nameOnly: Boolean
        get() = sp.getBoolean("name_only", false)
        set(v) = sp.edit().putBoolean("name_only", v).apply()

    /** True = the user can interrupt Mishti by talking. */
    var bargeIn: Boolean
        get() = sp.getBoolean("barge_in", true)
        set(v) = sp.edit().putBoolean("barge_in", v).apply()

    /** Voice pitch applied while playing. 1.0 = original, lower = softer and lower. */
    var voicePitch: Float
        get() = sp.getFloat("voice_pitch", 1.05f)
        set(v) = sp.edit().putFloat("voice_pitch", v).apply()

    /** Voice speed applied while playing. 1.0 = original, lower = slower and calmer. */
    var voiceSpeed: Float
        get() = sp.getFloat("voice_speed", 0.96f)
        set(v) = sp.edit().putFloat("voice_speed", v).apply()

    /** Tone preset for her voice: natural, clear, silky or warm. */
    var voicePolish: String
        get() = sp.getString("voice_polish", "clear").orEmpty().ifBlank { "clear" }
        set(v) = sp.edit().putString("voice_polish", v).apply()

    /** Playback loudness gain (1.0 = as made). */
    var voiceLoud: Float
        get() = sp.getFloat("voice_loud", 1.3f)
        set(v) = sp.edit().putFloat("voice_loud", v).apply()

    /** What to do with junk notifications: auto (clear them), ask (ask first), off. */
    var junkMode: String
        get() = sp.getString("junk_mode", "auto").orEmpty().ifBlank { "auto" }
        set(v) = sp.edit().putString("junk_mode", v).apply()

    /** True = Mishti speaks up about new messages. */
    var notifyAloud: Boolean
        get() = sp.getBoolean("notify_aloud", true)
        set(v) = sp.edit().putBoolean("notify_aloud", v).apply()

    // ---- conversation memory: short lines of what was said, so she can recall before standby and from days ago ----
    var convMemory: Boolean
        get() = sp.getBoolean("conv_memory", true)
        set(v) = sp.edit().putBoolean("conv_memory", v).apply()

    private val secretLike = Regex("""\d[\d\s-]{5,}\d|password|passcode|\bpin\b|\botp\b|পাসওয়ার্ড|पासवर्ड""", RegexOption.IGNORE_CASE)

    /** Saves one exchange. Anything that looks like a password, PIN, OTP or long number is never stored. */
    @Synchronized
    fun addJournal(user: String, reply: String) {
        if (!convMemory) return
        val u = user.trim().replace("\n", " ").take(140)
        val r = reply.trim().replace("\n", " ").take(160)
        if (r.isEmpty() || secretLike.containsMatchIn(u) || secretLike.containsMatchIn(r)) return
        val t = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date())
        writeList("journal", (readList("journal") + "$t | he: $u | you: $r").takeLast(300))
    }

    /** The last few exchanges, oldest first. */
    fun journalRecent(n: Int): List<String> = readList("journal").takeLast(n)

    fun journalSearch(q: String): List<String> {
        val k = q.trim().lowercase(); if (k.isEmpty()) return emptyList()
        return readList("journal").filter { it.lowercase().contains(k) }.takeLast(12)
    }

    @Synchronized
    fun clearJournal() = writeList("journal", emptyList())

    fun journalSize(): Int = readList("journal").size

    /** Most proactive remarks per day (1, 3 or 5). */
    var proactiveMax: Int
        get() = sp.getInt("proactive_max", 3)
        set(v) = sp.edit().putInt("proactive_max", v).apply()

    /** Quiet hours: no proactive remarks from [quietFrom] to [quietTo] (24h clock, wraps midnight). */
    var quietFrom: Int
        get() = sp.getInt("quiet_from", 22)
        set(v) = sp.edit().putInt("quiet_from", v).apply()
    var quietTo: Int
        get() = sp.getInt("quiet_to", 8)
        set(v) = sp.edit().putInt("quiet_to", v).apply()

    fun inQuietHours(): Boolean {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val a = quietFrom; val b = quietTo
        return if (a == b) false else if (a < b) h in a until b else (h >= a || h < b)
    }

    /**
     * The proactive gate. True (and counted) only outside quiet hours, under today's cap,
     * and when she has not been dismissed too often. A "don't" from him lowers the cap to zero for today.
     */
    @Synchronized
    fun proactiveAllow(): Boolean {
        if (inQuietHours()) return false
        val cal = java.util.Calendar.getInstance()
        val day = "${cal.get(java.util.Calendar.YEAR)}-${cal.get(java.util.Calendar.DAY_OF_YEAR)}"
        if (sp.getString("pro_day", "") != day) sp.edit().putString("pro_day", day).putInt("pro_count", 0).apply()
        val n = sp.getInt("pro_count", 0)
        if (n >= proactiveMax) return false
        sp.edit().putInt("pro_count", n + 1).apply()
        return true
    }

    /** He said stop / don't: no more proactive remarks for the rest of today. */
    @Synchronized
    fun proactiveSilenceToday() {
        sp.edit().putInt("pro_count", 999).apply()
    }

    // ---- action log: the last tool calls, so a failure can be seen and shared ----
    @Synchronized
    fun logAction(line: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        val list = readList("action_log") + "$t $line".take(180)
        writeList("action_log", list.takeLast(50))
    }

    fun actionLog(): List<String> = readList("action_log").asReversed()

    @Synchronized
    fun clearActionLog() = writeList("action_log", emptyList())

    /** Forget what she learned about his habits, lessons and usage (notes are cleared separately). */
    @Synchronized
    fun clearBrainAll() {
        writeList("habits", emptyList()); writeList("lessons", emptyList())
        sp.edit().remove("usage").apply()
    }

    /** True = Mishti sometimes starts talking on her own (miss you, tease, news). */
    var spontaneous: Boolean
        get() = sp.getBoolean("spontaneous", true)
        set(v) = sp.edit().putBoolean("spontaneous", v).apply()

    // ---- saved routines: a name and the list of steps to replay ----

    private fun routineJson(): JSONObject = try {
        JSONObject(sp.getString("routines", "{}"))
    } catch (e: Exception) {
        JSONObject()
    }

    val routineNames: List<String>
        get() = routineJson().keys().asSequence().toList()

    @Synchronized
    fun saveRoutine(name: String, steps: JSONArray) {
        val o = routineJson()
        o.put(name.trim().lowercase(), steps)
        sp.edit().putString("routines", o.toString()).apply()
    }

    fun routine(name: String): JSONArray? = routineJson().optJSONArray(name.trim().lowercase())

    /** True = Mishti keeps an eye on battery, heat, storage, memory and internet, and speaks up. */
    var deviceWatch: Boolean
        get() = sp.getBoolean("device_watch", true)
        set(v) = sp.edit().putBoolean("device_watch", v).apply()

    /** True = she answers only a clear, close voice, and stays silent when the room is noisy or others talk. */
    var focusVoice: Boolean
        get() = sp.getBoolean("focus_voice", true)
        set(v) = sp.edit().putBoolean("focus_voice", v).apply()

    /** Voice ID: answer only his own voice (needs the voice files and his taught voice). */
    var voiceIdOn: Boolean
        get() = sp.getBoolean("voiceid_on", false)
        set(v) = sp.edit().putBoolean("voiceid_on", v).apply()

    /** His taught voice as comma separated numbers (empty = not taught yet). */
    var voiceIdVec: String
        get() = sp.getString("voiceid_vec", "").orEmpty()
        set(v) = sp.edit().putString("voiceid_vec", v).apply()

    /** Largest voice distance still counted as him: 0.45 strict, 0.55 normal, 0.65 easy. */
    var voiceIdThr: Float
        get() = sp.getFloat("voiceid_thr", 0.55f)
        set(v) = sp.edit().putFloat("voiceid_thr", v).apply()

    /** True = she talks rough, with swearing, like a foul-mouthed close friend. Off by default. */
    var roughTalk: Boolean
        get() = sp.getBoolean("rough_talk", false)
        set(v) = sp.edit().putBoolean("rough_talk", v).apply()

    /** True = noisy room: needs a clearer voice to start a turn. */
    var noisyRoom: Boolean
        get() = sp.getBoolean("noisy_room", false)
        set(v) = sp.edit().putBoolean("noisy_room", v).apply()

    /** Raw typed values, so the Settings screen does not show the build fallback as if it were typed. */
    fun typed(key: String): String = sp.getString(key, "").orEmpty()

    // ---- things Mishti was asked to remember ----

    val notes: List<String>
        get() {
            val arr = try {
                JSONArray(sp.getString("notes", "[]"))
            } catch (e: Exception) {
                JSONArray()
            }
            return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
        }

    private fun saveNotes(list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        sp.edit().putString("notes", arr.toString()).apply()
    }

    @Synchronized
    fun addNote(note: String) {
        val clean = note.trim().take(200)
        if (clean.isEmpty()) return
        if (notes.any { it.equals(clean, ignoreCase = true) }) return
        saveNotes((notes + clean).takeLast(60))
    }

    @Synchronized
    fun removeNotes(keyword: String): Int {
        val k = keyword.trim().lowercase()
        if (k.isEmpty()) return 0
        val before = notes
        val after = before.filterNot { it.lowercase().contains(k) }
        saveNotes(after)
        return before.size - after.size
    }

    @Synchronized
    fun clearNotes() = saveNotes(emptyList())

    // ---- game controls: where the stick and buttons are, per game ----
    fun pad(game: String): JSONObject = try {
        JSONObject(sp.getString("pad_" + game.trim().lowercase(), "{}"))
    } catch (e: Exception) {
        JSONObject()
    }

    @Synchronized
    fun savePad(game: String, name: String, x: Double, y: Double, kind: String) {
        val o = pad(game)
        o.put(name.trim().lowercase(), JSONObject().put("x", x).put("y", y).put("kind", kind))
        sp.edit().putString("pad_" + game.trim().lowercase(), o.toString()).apply()
    }

    // ---- brain: habits he showed, lessons he taught, and what he uses when ----

    private fun readList(key: String): List<String> {
        val arr = try { JSONArray(sp.getString(key, "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    }

    private fun writeList(key: String, list: List<String>) {
        val arr = JSONArray(); list.forEach { arr.put(it) }
        sp.edit().putString(key, arr.toString()).apply()
    }

    val habits: List<String> get() = readList("habits")
    val lessons: List<String> get() = readList("lessons")

    @Synchronized
    fun addHabit(h: String): Boolean {
        val c = h.trim().take(160); if (c.isEmpty()) return false
        writeList("habits", (habits.filterNot { it.equals(c, true) } + c).takeLast(30)); return true
    }

    @Synchronized
    fun addLesson(r: String): Boolean {
        val c = r.trim().take(200); if (c.isEmpty()) return false
        writeList("lessons", (lessons.filterNot { it.equals(c, true) } + c).takeLast(40)); return true
    }

    @Synchronized
    fun removeBrain(keyword: String): Int {
        val k = keyword.trim().lowercase(); if (k.isEmpty()) return 0
        var n = 0
        for (key in listOf("habits", "lessons")) {
            val b = readList(key); val a = b.filterNot { it.lowercase().contains(k) }
            n += b.size - a.size; writeList(key, a)
        }
        return n
    }

    private fun slot(): String {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when (h) { in 5..11 -> "morning"; in 12..16 -> "afternoon"; in 17..21 -> "evening"; else -> "night" }
    }

    fun timeSlot(): String = slot()

    /**
     * Which greeting is due right now ("morning" or "noon"), once per day each.
     * It is marked as given at once, so she never greets twice in one day, even after a restart.
     */
    @Synchronized
    fun greetingDue(): String {
        val cal = java.util.Calendar.getInstance()
        val day = "${cal.get(java.util.Calendar.YEAR)}-${cal.get(java.util.Calendar.DAY_OF_YEAR)}"
        if (sp.getString("greet_day", "") != day) sp.edit().putString("greet_day", day).putString("greeted", "").apply()
        val done = sp.getString("greeted", "").orEmpty().split(",").filter { it.isNotBlank() }
        val due = when (cal.get(java.util.Calendar.HOUR_OF_DAY)) { in 5..11 -> "morning"; in 12..15 -> "noon"; else -> "" }
        if (due.isEmpty() || due in done) return ""
        sp.edit().putString("greeted", (done + due).joinToString(",")).apply()
        return due
    }

    /** What was already greeted today, so she knows not to repeat. */
    fun greetedToday(): String = sp.getString("greeted", "").orEmpty()

    /** Counts what he opens / plays / calls, per part of the day. */
    @Synchronized
    fun logUse(kind: String, what: String) {
        val w = what.trim().lowercase().take(40); if (w.isEmpty()) return
        val o = try { JSONObject(sp.getString("usage", "{}")) } catch (e: Exception) { JSONObject() }
        val key = "$kind|$w|${slot()}"
        o.put(key, o.optInt(key, 0) + 1)
        // keep it small: drop the weakest entries when too many
        if (o.length() > 150) {
            val weakest = o.keys().asSequence().sortedBy { o.optInt(it) }.take(30).toList()
            weakest.forEach { o.remove(it) }
        }
        sp.edit().putString("usage", o.toString()).apply()
    }

    /** Short lines like "opens youtube (evening x9)" for the habits seen at least 3 times. */
    fun usageSummary(): List<String> {
        val o = try { JSONObject(sp.getString("usage", "{}")) } catch (e: Exception) { return emptyList() }
        return o.keys().asSequence().map { it to o.optInt(it) }.filter { it.second >= 3 }
            .sortedByDescending { it.second }.take(12).map { (k, n) ->
                val p = k.split("|")
                val verb = when (p[0]) { "app" -> "opens"; "call" -> "calls"; "play" -> "plays"; "sms" -> "messages"; else -> "uses" }
                "$verb ${p.getOrElse(1) { "" }} (${p.getOrElse(2) { "" }}, ${n}x)"
            }.toList()
    }
}
