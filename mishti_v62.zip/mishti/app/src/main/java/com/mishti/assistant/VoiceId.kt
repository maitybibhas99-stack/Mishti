package com.mishti.assistant

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.SpeakerModel
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream
import kotlin.math.sqrt

/**
 * Voice ID: tells whether the voice speaking is HIS, offline, with Vosk speaker vectors (x-vectors).
 * He teaches his voice once (three short takes); later each spoken sentence is compared with it.
 * Every failure here lets the sound through (never blocks him by mistake because of a missing file or an error).
 */
object VoiceId {
    private const val SPK_URL = "https://alphacephei.com/vosk/models/vosk-model-spk-0.4.zip"

    fun spkDir(ctx: Context) = File(ctx.filesDir, "vosk-spk")

    fun filesReady(ctx: Context) = File(spkDir(ctx), ".ready").exists() && WakeWordEngine.modelReady(ctx)

    /** Downloads the speech model (if the wake word has not) and the speaker model. Returns null when done, or an error text. */
    fun download(ctx: Context, onProgress: (Int) -> Unit): String? {
        if (!WakeWordEngine.modelReady(ctx)) {
            val e = WakeWordEngine.download(ctx) { onProgress(it * 70 / 100) }
            if (e != null) return e
        }
        if (File(spkDir(ctx), ".ready").exists()) return null
        val dir = spkDir(ctx)
        dir.deleteRecursively()
        dir.mkdirs()
        val client = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()
        return try {
            client.newCall(Request.Builder().url(SPK_URL).build()).execute().use { resp ->
                if (!resp.isSuccessful) return "HTTP ${resp.code}"
                val body = resp.body ?: return "khali uttor"
                val total = body.contentLength().coerceAtLeast(1L)
                val counting = Counting(body.byteStream(), total) { onProgress(70 + it * 30 / 100) }
                val base = dir.canonicalPath
                ZipInputStream(counting).use { zin ->
                    var entry = zin.nextEntry
                    while (entry != null) {
                        val name = entry.name.substringAfter('/', "")
                        if (name.isNotEmpty()) {
                            val out = File(dir, name)
                            if (!out.canonicalPath.startsWith(base)) return "zip-e bhul path"
                            if (entry.isDirectory) out.mkdirs() else {
                                out.parentFile?.mkdirs()
                                FileOutputStream(out).use { zin.copyTo(it) }
                            }
                        }
                        entry = zin.nextEntry
                    }
                }
            }
            if ((dir.list()?.size ?: 0) == 0) return "speaker model khola gelo na"
            File(dir, ".ready").writeText("ok")
            null
        } catch (e: Exception) {
            e.message ?: "unknown error"
        }
    }

    private class Counting(input: InputStream, private val total: Long, private val on: (Int) -> Unit) : FilterInputStream(input) {
        private var read = 0L
        private var last = -1
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) {
                read += n
                val p = (read * 100 / total).toInt().coerceIn(0, 100)
                if (p != last) { last = p; on(p) }
            }
            return n
        }
    }

    /** 0 = same voice ... 1 = different. */
    fun distance(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size || a.isEmpty()) return 1f
        var dot = 0f; var na = 0f; var nb = 0f
        for (i in a.indices) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
        val d = sqrt(na) * sqrt(nb)
        return if (d <= 0f) 1f else 1f - dot / d
    }

    fun encode(v: FloatArray): String = v.joinToString(",")

    fun decode(s: String): FloatArray? = try {
        if (s.isBlank()) null else s.split(",").map { it.trim().toFloat() }.toFloatArray()
    } catch (_: Exception) { null }

    /**
     * Teaches his voice: [takes] recordings of [seconds] each, one speaker vector per take, averaged.
     * Runs on the calling thread (call it from a background thread). Returns the saved vector text, or null with [onStatus] saying why.
     */
    @SuppressLint("MissingPermission")
    fun enroll(ctx: Context, checker: SpeakerChecker, takes: Int, seconds: Int, onStatus: (String) -> Unit): FloatArray? {
        if (ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            onStatus("Mic permission nei."); return null
        }
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) { onStatus("Mic khola gelo na."); return null }
        val vecs = ArrayList<FloatArray>()
        for (t in 1..takes) {
            onStatus("Take $t/$takes: ekhon $seconds second normal-bhabe kotha bolo (jekono kotha).")
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8192))
            } catch (e: Exception) { onStatus("Mic khola gelo na."); return null }
            if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); onStatus("Mic khola gelo na. Mishti bondho kore abar chesta koro."); return null }
            val out = ByteArrayOutputStream()
            val buf = ByteArray(2048)
            val end = System.currentTimeMillis() + seconds * 1000L
            rec.startRecording()
            while (System.currentTimeMillis() < end) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) out.write(buf, 0, n) else if (n < 0) break
            }
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
            onStatus("Take $t/$takes: bujhchhi...")
            val v = checker.embed(out.toByteArray())
            if (v == null) { onStatus("Take $t-e kotha bujhte parini. Jore ar spashto bolo, abar chesta koro."); return null }
            vecs.add(v)
        }
        val n = vecs[0].size
        val avg = FloatArray(n)
        for (v in vecs) for (i in 0 until n) avg[i] += v[i] / vecs.size
        onStatus("Tomar voice shikha hoyeche.")
        return avg
    }
}

/** Turns a piece of 16 kHz speech into a speaker vector. Heavy: call from a background thread. */
class SpeakerChecker(private val ctx: Context) {
    private var asr: Model? = null
    private var spk: SpeakerModel? = null

    @Synchronized
    private fun ensure(): Boolean = try {
        if (asr == null) asr = Model(WakeWordEngine.modelDir(ctx).absolutePath)
        if (spk == null) spk = SpeakerModel(VoiceId.spkDir(ctx).absolutePath)
        true
    } catch (_: Throwable) {
        false
    }

    @Synchronized
    fun embed(pcm: ByteArray): FloatArray? {
        if (!ensure()) return null
        val m = asr ?: return null
        val sm = spk ?: return null
        var r: Recognizer? = null
        return try {
            val rec = Recognizer(m, 16000f, sm)
            r = rec
            rec.acceptWaveForm(pcm, pcm.size)
            val j = JSONObject(rec.finalResult)
            val a = j.optJSONArray("spk") ?: return null
            FloatArray(a.length()) { a.getDouble(it).toFloat() }
        } catch (_: Throwable) {
            null
        } finally {
            try { r?.close() } catch (_: Throwable) {}
        }
    }
}
