package com.mishti.assistant

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * A small offline listener that waits for "Mishti" / "Hey Mishti" while Mishti is off or resting.
 * It uses a ~36 MB offline speech model (downloaded once) and only looks for a few wake words,
 * so it needs no internet, and uses far less power than a live session.
 */
class WakeWordEngine(private val ctx: Context, private val onWake: () -> Unit) {

    companion object {
        private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip"

        // Spellings the English model knows that sound like "Mishti".
        private const val GRAMMAR =
            "[\"hey misty\", \"misty\", \"hey missy\", \"missy\", \"hey mishti\", \"mishti\", \"hey mishty\", \"mishty\", \"[unk]\"]"
        private val HEARD = Regex("\\b(misty|missy|mishti|mishty)\\b")

        fun modelDir(ctx: Context) = File(ctx.filesDir, "vosk-model")

        fun modelReady(ctx: Context) = File(modelDir(ctx), ".ready").exists()

        /** Downloads and unpacks the speech model. Returns null when done, or a short error text. */
        fun download(ctx: Context, onProgress: (Int) -> Unit): String? {
            val dir = modelDir(ctx)
            dir.deleteRecursively()
            dir.mkdirs()
            val client = OkHttpClient.Builder()
                .readTimeout(60, TimeUnit.SECONDS)
                .build()
            return try {
                client.newCall(Request.Builder().url(MODEL_URL).build()).execute().use { resp ->
                    if (!resp.isSuccessful) return "HTTP ${resp.code}"
                    val body = resp.body ?: return "khali uttor"
                    val total = body.contentLength().coerceAtLeast(1L)
                    val counting = CountingStream(body.byteStream(), total, onProgress)
                    val base = dir.canonicalPath
                    ZipInputStream(counting).use { zin ->
                        var entry = zin.nextEntry
                        while (entry != null) {
                            // drop the zip's top folder name
                            val name = entry.name.substringAfter('/', "")
                            if (name.isNotEmpty()) {
                                val out = File(dir, name)
                                if (!out.canonicalPath.startsWith(base)) return "zip-e bhul path"
                                if (entry.isDirectory) {
                                    out.mkdirs()
                                } else {
                                    out.parentFile?.mkdirs()
                                    FileOutputStream(out).use { zin.copyTo(it) }
                                }
                            }
                            entry = zin.nextEntry
                        }
                    }
                }
                if (!File(dir, "am").exists()) return "model thik moto khola gelo na"
                File(dir, ".ready").writeText("ok")
                null
            } catch (e: Exception) {
                e.message ?: "unknown error"
            }
        }
    }

    private class CountingStream(
        input: InputStream,
        private val total: Long,
        private val onProgress: (Int) -> Unit,
    ) : FilterInputStream(input) {
        private var read = 0L
        private var last = -1

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) {
                read += n
                val pct = (read * 100 / total).toInt().coerceIn(0, 100)
                if (pct != last) {
                    last = pct
                    onProgress(pct)
                }
            }
            return n
        }
    }

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var thread: Thread? = null

    @Volatile
    private var running = false

    val isRunning: Boolean get() = running

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (running) return true
        if (!modelReady(ctx)) return false
        val rec: Recognizer
        try {
            if (model == null) model = Model(modelDir(ctx).absolutePath)
            if (recognizer == null) recognizer = Recognizer(model, 16000f, GRAMMAR)
            rec = recognizer!!
        } catch (e: Exception) {
            return false
        }
        val minBuf = AudioRecord.getMinBufferSize(
            16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return false
        val record = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 16000 * 2)
            )
        } catch (e: Exception) {
            return false
        }
        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            return false
        }
        running = true
        rec.reset()
        record.startRecording()
        thread = Thread({
            val buf = ByteArray(3200) // 100 ms
            var fired = false
            while (running && !fired) {
                val n = record.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                val text = try {
                    if (rec.acceptWaveForm(buf, n)) field(rec.result, "text") else field(rec.partialResult, "partial")
                } catch (e: Exception) {
                    ""
                }
                if (text.isNotEmpty() && HEARD.containsMatchIn(text)) fired = true
            }
            try {
                record.stop()
            } catch (_: Exception) {
            }
            record.release()
            running = false
            if (fired) {
                try {
                    rec.reset()
                } catch (_: Exception) {
                }
                onWake()
            }
        }, "mishti-wake").also { it.start() }
        return true
    }

    private fun field(json: String, key: String): String =
        try {
            JSONObject(json).optString(key)
        } catch (e: Exception) {
            ""
        }

    fun stop() {
        running = false
        val t = thread
        thread = null
        if (t != null && t !== Thread.currentThread()) {
            try {
                t.join(700)
            } catch (_: InterruptedException) {
            }
        }
    }

    /** Frees the model memory too. */
    fun release() {
        stop()
        try {
            recognizer?.close()
        } catch (_: Exception) {
        }
        recognizer = null
        try {
            model?.close()
        } catch (_: Exception) {
        }
        model = null
    }
}
