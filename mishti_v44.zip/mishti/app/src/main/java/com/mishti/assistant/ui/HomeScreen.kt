package com.mishti.assistant.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mishti.assistant.ChatMessage
import com.mishti.assistant.Phase
import com.mishti.assistant.Ui
import java.util.Calendar
import kotlin.math.sin

private val IDEAS = listOf(
    "Play a song on YouTube",
    "Turn on the flashlight",
    "What's the latest news?",
    "Set an alarm for 7 AM",
    "Install an app from Play Store",
    "Check my notifications",
    "Turn off Wi-Fi",
    "Write a web page in Notes",
)

@Composable
fun HomeScreen(
    ui: Ui,
    userName: String,
    level: () -> Float,
    onSend: (String) -> Unit,
    onVoice: () -> Unit,
    onOff: () -> Unit,
    onNewChat: () -> Unit,
    onSettings: () -> Unit,
    onNotifications: () -> Unit,
) {
    val empty = ui.messages.isEmpty()
    // The orb is big and central at first; once a message is sent it shrinks and sits above the typing bar.
    val orbHeight by animateDpAsState(
        targetValue = if (empty) 260.dp else 84.dp,
        animationSpec = tween(650, easing = FastOutSlowInEasing),
        label = "orbHeight"
    )
    val energy = when {
        ui.muted || ui.asleep -> 0.3f
        ui.phase == Phase.Speaking -> 1f
        else -> 0.6f
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MishtiColors.Bg)
    ) {
        LiquidBackground(Modifier.fillMaxSize(), level = level)
        BlueGlow(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(0.40f),
            level = level,
            energy = energy
        )
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .imePadding()
        ) {
            TopBar(ui = ui, level = level, onNewChat = onNewChat, showNewChat = !empty, onSettings = onSettings, onNotifications = onNotifications)

            if (ui.listening || ui.armed) LiveBar(ui = ui, onOpen = onVoice, onOff = onOff)

            if (empty) {
                Spacer(Modifier.weight(1f))
            } else {
                Box(Modifier.weight(1f).fillMaxWidth()) { ChatList(ui.messages) }
            }

            // What Mishti is doing right now (opening an app, tapping, ...).
            AnimatedVisibility(
                visible = ui.activity != null,
                enter = fadeIn() + slideInVertically { it / 2 },
                exit = fadeOut()
            ) {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    ActivityPill(ui.activity.orEmpty())
                }
            }

            GlassOrb(
                Modifier
                    .fillMaxWidth()
                    .height(orbHeight),
                level = level,
                energy = energy
            )
            AnimatedVisibility(visible = empty, enter = fadeIn(), exit = fadeOut()) {
                StatusLine(ui)
            }

            AnimatedVisibility(visible = empty, enter = fadeIn(), exit = fadeOut()) {
                Column(
                    Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        if (userName.isBlank()) greeting() else "Hello $userName",
                        color = Color(0xB3FFFFFF),
                        fontSize = 15.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "How can I help\nyou today?",
                        color = Color.White,
                        fontSize = 30.sp,
                        lineHeight = 36.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                }
            }

            if (empty) Spacer(Modifier.weight(1.1f))

            if (empty) IdeaRow(onSend)

            if (ui.error != null) {
                Text(
                    ui.error,
                    color = MishtiColors.Coral,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
                )
            }

            InputBar(onSend = onSend, onVoice = onVoice)
        }
    }
}

internal fun statusOf(ui: Ui): Pair<String, Color> = when {
    ui.muted -> "Standby · mic off" to Color(0xFFFFC857)
    ui.asleep -> "Resting · say \"Hey Mishti\"" to Color(0xFF8FA0BF)
    ui.armed && !ui.listening -> "Waiting for \"Hey Mishti\"" to Color(0xFF8FA0BF)
    ui.phase == Phase.Connecting -> "Connecting..." to Color(0xFFFFC857)
    ui.phase == Phase.Speaking -> "Connected · Speaking" to MishtiColors.Accent
    ui.listening -> "Connected · Listening" to MishtiColors.Good
    else -> "Off · tap the wave button to switch Mishti on" to Color(0xFF8FA0BF)
}

@Composable
private fun TopBar(
    ui: Ui,
    level: () -> Float,
    onNewChat: () -> Unit,
    showNewChat: Boolean,
    onSettings: () -> Unit,
    onNotifications: () -> Unit,
) {
    val (status, dot) = statusOf(ui)
    Row(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GlassOrb(Modifier.size(46.dp), level = level, energy = 0.5f)
        Spacer(Modifier.size(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Mishti", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(dot)
                )
                Spacer(Modifier.size(6.dp))
                Text(status, color = MishtiColors.TextDim, fontSize = 12.sp, maxLines = 1)
            }
        }
        if (showNewChat) {
            GlassIcon(onClick = onNewChat) {
                Icon(Icons.Default.Edit, contentDescription = "New chat", tint = Color.White, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.size(8.dp))
        }
        GlassIcon(onClick = onNotifications) {
            Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.size(8.dp))
        GlassIcon(onClick = onSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun GlassIcon(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .pressable(onClick)
            .size(42.dp)
            .liquid(CircleShape),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun LiveBar(ui: Ui, onOpen: () -> Unit, onOff: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .liquid(shape)
            .clickable(onClick = onOpen)
            .padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Mic, contentDescription = null, tint = MishtiColors.Accent, modifier = Modifier.size(20.dp))
        Spacer(Modifier.size(10.dp))
        Text(
            when {
                ui.muted -> "Mic is off · tap to open"
                ui.asleep || (ui.armed && !ui.listening) -> "Waiting for \"Hey Mishti\""
                else -> "Voice is live · tap to open"
            },
            color = Color.White,
            fontSize = 14.sp,
            modifier = Modifier.weight(1f)
        )
        Row(
            Modifier
                .pressable(onOff)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0x40E5484D))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.PowerSettingsNew, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            Spacer(Modifier.size(6.dp))
            Text("Off", color = Color.White, fontSize = 13.sp)
        }
    }
}

@Composable
private fun ActivityPill(text: String) {
    val clock = rememberInfiniteTransition(label = "act")
    val pulse = clock.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "pulse"
    )
    Row(
        Modifier
            .padding(bottom = 6.dp)
            .liquid(RoundedCornerShape(50))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(8.dp)
                .drawBehind { drawCircle(MishtiColors.Accent.copy(alpha = pulse.value)) }
        )
        Spacer(Modifier.size(8.dp))
        Text(text, color = Color.White, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
private fun IdeaRow(onSend: (String) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        IDEAS.forEachIndexed { i, idea ->
            Appear(delayMs = 250 + i * 70) {
                Text(
                    idea,
                    color = Color.White,
                    fontSize = 13.sp,
                    maxLines = 1,
                    modifier = Modifier
                        .pressable { onSend(idea) }
                        .liquid(RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 9.dp)
                )
            }
        }
    }
}

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when (h) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..20 -> "Good evening"
        else -> "Hello, night owl"
    }
}

@Composable
private fun ChatList(messages: List<ChatMessage>) {
    val state = rememberLazyListState()
    val waiting = messages.lastOrNull()?.fromUser == true
    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length, waiting) {
        val n = messages.size + (if (waiting) 1 else 0)
        if (n > 0) state.animateScrollToItem(n - 1)
    }
    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items(messages, key = { it.id }) { m ->
            Appear {
            if (m.fromUser) {
                val userShape = RoundedCornerShape(22.dp, 22.dp, 6.dp, 22.dp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Text(
                        m.text,
                        color = Color.White,
                        fontSize = 16.sp,
                        modifier = Modifier
                            .widthIn(max = 300.dp)
                            .clip(userShape)
                            .background(
                                Brush.verticalGradient(0f to Color(0x663F8CFF), 1f to Color(0x4D2F5BFF))
                            )
                            .liquid(userShape, strength = 1.1f)
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    GlassOrb(Modifier.size(34.dp), level = { 0f }, energy = 0.4f)
                    Spacer(Modifier.size(8.dp))
                    Text(
                        m.text,
                        color = Color.White,
                        fontSize = 16.sp,
                        lineHeight = 23.sp,
                        modifier = Modifier
                            .widthIn(max = 300.dp)
                            .liquid(RoundedCornerShape(6.dp, 22.dp, 22.dp, 22.dp))
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            }
            }
        }
        if (waiting) {
            item(key = "typing") {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    GlassOrb(Modifier.size(34.dp), level = { 0f }, energy = 0.4f)
                    Spacer(Modifier.size(8.dp))
                    Box(
                        Modifier
                            .liquid(RoundedCornerShape(22.dp))
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                    ) { TypingDots() }
                }
            }
        }
    }
}

@Composable
private fun TypingDots() {
    val clock = rememberInfiniteTransition(label = "dots")
    val t = clock.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Restart),
        label = "t"
    )
    Canvas(Modifier.size(width = 34.dp, height = 8.dp)) {
        val r = size.height / 2f
        for (i in 0 until 3) {
            val a = 0.35f + 0.65f * (0.5f + 0.5f * sin((t.value * 2f - i * 0.25f) * 6.2831855f))
            drawCircle(
                Color.White.copy(alpha = a),
                radius = r,
                center = Offset(r + i * (size.width - 2 * r) / 2f, r)
            )
        }
    }
}

@Composable
private fun InputBar(onSend: (String) -> Unit, onVoice: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val hasText = text.isNotBlank()
    val shape = RoundedCornerShape(34.dp)
    var focused by remember { mutableStateOf(false) }
    val glassStrength by animateFloatAsState(if (focused) 2.3f else 1.5f, tween(350), label = "focusGlass")
    val sendBg by animateColorAsState(if (hasText) Color.White else Color.Transparent, tween(250), label = "sendBg")

    fun submit() {
        if (text.isBlank()) return
        onSend(text)
        text = ""
    }

    // Liquid glass: a light-blue translucent body that is brighter at the bottom, with a wet top highlight.
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 16.dp)
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    0f to Color(0x26BFD8FF),
                    0.55f to Color(0x406FA8FF),
                    1f to Color(0x7AA6CCFF)
                )
            )
            .liquid(shape, strength = glassStrength)
            .padding(start = 24.dp, end = 10.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f)) {
            if (text.isEmpty()) {
                Text("Ask anything...", color = Color(0xCCFFFFFF), fontSize = 17.sp)
            }
            BasicTextField(
                value = text,
                onValueChange = { text = it },
                textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
                cursorBrush = SolidColor(Color.White),
                maxLines = 5,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { submit() }),
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { focused = it.isFocused }
            )
        }
        Spacer(Modifier.size(8.dp))
        Box(
            Modifier
                .pressable { if (hasText) submit() else onVoice() }
                .size(44.dp)
                .clip(CircleShape)
                .background(sendBg),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = hasText, animationSpec = tween(220), label = "sendIcon") { typing ->
                if (typing) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = "Send", tint = Color(0xFF0B1B4A))
                } else {
                    MiniWaveIcon()
                }
            }
        }
    }
}

@Composable
private fun MiniWaveIcon() {
    val clock = rememberInfiniteTransition(label = "wave")
    val ph = clock.animateFloat(
        initialValue = 0f,
        targetValue = 6.2831855f,
        animationSpec = infiniteRepeatable(tween(2200, easing = androidx.compose.animation.core.LinearEasing)),
        label = "ph"
    )
    Canvas(Modifier.size(26.dp)) {
        val heights = floatArrayOf(0.30f, 0.60f, 0.95f, 0.50f, 0.75f, 0.35f)
        val gap = size.width / heights.size
        heights.forEachIndexed { i, base ->
            val h = base * (0.80f + 0.20f * sin(ph.value + i * 1.1f))
            val x = gap * (i + 0.5f)
            val half = size.height * h / 2f
            drawLine(
                Color.White,
                Offset(x, size.height / 2 - half),
                Offset(x, size.height / 2 + half),
                strokeWidth = size.width * 0.075f,
                cap = StrokeCap.Round
            )
        }
    }
}

/** A clear line under the orb so he can always tell whether Mishti is on, connecting or listening. */
@Composable
internal fun StatusLine(ui: Ui) {
    val (text, dot) = statusOf(ui)
    Box(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 6.dp), contentAlignment = Alignment.Center) {
        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(Color(0x1AFFFFFF))
                .padding(horizontal = 14.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.size(8.dp))
            Crossfade(targetState = text, label = "statusLine") {
                Text(it, color = Color.White, fontSize = 13.sp, maxLines = 1)
            }
        }
    }
}
