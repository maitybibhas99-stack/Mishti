package com.mishti.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Lets Mishti see new notifications so she can tell him about messages, clear junk, and reply.
 * The user turns it on in Settings > Notification access.
 */
class MishtiNotificationService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: MishtiNotificationService? = null
            private set

        /** True when the user switched Notification access on for Mishti (even if Android has not bound it yet). */
        fun enabled(ctx: Context): Boolean {
            val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners").orEmpty()
            return flat.split(":").any { ComponentName.unflattenFromString(it)?.packageName == ctx.packageName }
        }

        /**
         * After an app update or a process kill Android can leave the listener unbound even though access is on.
         * Toggling the component and asking for a rebind brings it back without the user doing anything.
         */
        fun rebind(ctx: Context) {
            if (instance != null || !enabled(ctx)) return
            try {
                val cn = ComponentName(ctx, MishtiNotificationService::class.java)
                val pm = ctx.packageManager
                pm.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                pm.setComponentEnabledSetting(cn, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
                if (Build.VERSION.SDK_INT >= 24) NotificationListenerService.requestRebind(cn)
            } catch (_: Exception) {
            }
        }
    }

    private val ids = ConcurrentHashMap<String, String>() // short id -> notification key
    private val seen = ConcurrentHashMap<String, Long>()

    override fun onListenerConnected() {
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (!relevant(sbn)) return
            val info = describe(sbn) ?: return
            val sig = sbn.key + "|" + info.title + "|" + info.text
            val now = System.currentTimeMillis()
            val before = seen[sig]
            if (before != null && now - before < 60_000) return
            if (seen.size > 300) seen.clear()
            seen[sig] = now
            (application as MishtiApplication).assistant.onNotification(info)
        } catch (_: Exception) {
        }
    }

    /** Skips Mishti's own, ongoing (music, downloads, running services) and group-summary notifications. */
    private fun relevant(sbn: StatusBarNotification): Boolean {
        if (sbn.packageName == packageName) return false
        val n = sbn.notification
        if (sbn.isOngoing) return false
        val bad = Notification.FLAG_GROUP_SUMMARY or Notification.FLAG_FOREGROUND_SERVICE
        return (n.flags and bad) == 0
    }

    private fun describe(sbn: StatusBarNotification): NotifInfo? {
        val n = sbn.notification
        val ex = n.extras
        val title = (ex.getCharSequence(Notification.EXTRA_TITLE)
            ?: ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE))?.toString().orEmpty().trim()
        var text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty().trim()
        // Chat apps (WhatsApp, Telegram...) put the recent messages in a list; read the last few.
        try {
            @Suppress("DEPRECATION")
            val msgs = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
            val parts = msgs?.takeLast(3)?.mapNotNull { m ->
                val b = m as? Bundle ?: return@mapNotNull null
                val t = b.getCharSequence("text")?.toString().orEmpty()
                val who = b.getCharSequence("sender")?.toString().orEmpty()
                if (t.isBlank()) null else if (who.isBlank()) t else "$who: $t"
            }.orEmpty()
            if (parts.isNotEmpty()) text = parts.joinToString("\n")
        } catch (_: Exception) {
        }
        if (text.isEmpty()) {
            val lines = ex.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            if (lines != null && lines.isNotEmpty()) text = lines.takeLast(3).joinToString("\n") { it.toString() }
        }
        if (text.isEmpty()) text = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty().trim()
        if (title.isEmpty() && text.isEmpty()) return null
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        val id = "n" + (sbn.key.hashCode() and 0xFFFFF).toString(36)
        ids[id] = sbn.key
        val kind = NotifClassifier.classify(sbn.packageName, n.category, title, text)
        return NotifInfo(
            id = id,
            pkg = sbn.packageName,
            app = app,
            title = title.take(120),
            text = text.take(400),
            kind = kind,
            sensitive = NotifClassifier.isSensitive("$title $text"),
            canReply = n.actions?.any { a -> a.remoteInputs?.isNotEmpty() == true } == true,
            whenMs = sbn.postTime
        )
    }

    private fun active(): List<StatusBarNotification> =
        try {
            activeNotifications.filter { relevant(it) }.sortedByDescending { it.postTime }
        } catch (e: Exception) {
            emptyList()
        }

    // ------------------------------------------------------------------ tools

    /** Everything currently in the shade, newest first. Used by the in-app inbox. */
    fun rows(): List<NotifInfo> = active().mapNotNull { describe(it) }

    fun list(limit: Int, app: String = ""): JSONObject {
        val arr = JSONArray()
        val filter = app.trim().lowercase()
        val now = System.currentTimeMillis()
        val all = rows().filter { filter.isEmpty() || it.app.lowercase().contains(filter) || it.pkg.lowercase().contains(filter) }
        all.take(limit.coerceIn(1, 20)).forEach { n ->
            val mins = ((now - n.whenMs) / 60000L).coerceAtLeast(0L)
            arr.put(
                JSONObject()
                    .put("id", n.id)
                    .put("app", n.app)
                    .put("title", n.title)
                    .put("text", n.text.take(400))
                    .put("kind", n.kind.name.lowercase())
                    .put("minutes_ago", mins)
                    .put("can_reply", n.canReply)
                    .put("sensitive", n.sensitive)
            )
        }
        return JSONObject().put("status", "ok").put("total", all.size).put("notifications", arr)
            .put("note", if (all.isEmpty()) "Shade is empty or nothing matched. If the user says there are notifications, use press_key('notifications') then read_screen, and press_key('back') after." else "")
    }

    fun dismiss(id: String): JSONObject {
        val k = id.trim().lowercase()
        return when (k) {
            "junk" -> {
                var count = 0
                active().forEach { sbn ->
                    val d = describe(sbn)
                    if (d != null && d.kind == NotifKind.JUNK) {
                        cancelNotification(sbn.key)
                        count++
                    }
                }
                ok("$count ta faltu notification uriye dilam.")
            }
            "all" -> {
                cancelAllNotifications()
                ok("Shob notification muchhe dilam.")
            }
            else -> {
                val key = ids[k] ?: return fail("'$id' notification ar nei. read_notifications diye dekho.")
                cancelNotification(key)
                ok("Notification uriye dilam.")
            }
        }
    }

    private fun find(id: String): StatusBarNotification? {
        val key = ids[id.trim().lowercase()] ?: return null
        return active().firstOrNull { it.key == key }
    }

    /** Sends a reply through the notification's own reply box (WhatsApp, Telegram, SMS...). */
    fun reply(id: String, text: String): JSONObject {
        if (text.isBlank()) return fail("Ki reply debo?")
        val sbn = find(id) ?: return fail("Notification-ta ar nei. read_notifications diye dekho.")
        val action = sbn.notification.actions
            ?.firstOrNull { it.remoteInputs?.isNotEmpty() == true && it.actionIntent != null }
            ?: return fail("Ei notification-e sorasori reply kora jay na. App khule reply koro.")
        val inputs = action.remoteInputs
        val results = Bundle()
        inputs.forEach { results.putCharSequence(it.resultKey, text) }
        val intent = Intent()
        RemoteInput.addResultsToIntent(inputs, intent, results)
        return try {
            action.actionIntent.send(this, 0, intent)
            ok("Reply pathano hoyeche.")
        } catch (e: Exception) {
            fail("Reply jayni: ${e.message}")
        }
    }

    fun openIt(id: String): JSONObject {
        val sbn = find(id) ?: return fail("Notification-ta ar nei.")
        val pi = sbn.notification.contentIntent ?: return fail("Ei notification khola jay na.")
        return try {
            pi.send()
            ok("Khola hocche.")
        } catch (e: Exception) {
            fail("Khola gelo na: ${e.message}")
        }
    }

    private fun ok(m: String) = JSONObject().put("status", "ok").put("message", m)
    private fun fail(m: String) = JSONObject().put("status", "error").put("message", m)
}
