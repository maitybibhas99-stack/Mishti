package com.mishti.assistant

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.PlaybackParams
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/** Mic capture (16 kHz) and speaker playback (24 kHz) for the Gemini Live session. */
class AudioEngine(context: Context) {

    companion object {
        const val IN_RATE = 16000
        const val OUT_RATE = 24000
    }

    /** Playback pitch and speed (1.0 = as the model made it). Lower pitch = softer, lower voice. */
    @Volatile var pitch = 1f
    @Volatile var speed = 1f

    /** Tone preset ("natural", "clear", "silky", "warm") and loudness gain for playback. */
    @Volatile var polish = "clear"
    @Volatile var loudness = 1.3f
    private var fx: VoiceFx? = null

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // ---- levels (0..1), read by the UI ticker ----
    @Volatile var micLevel = 0f
        private set
    @Volatile var outLevel = 0f
        private set

    // ---- mic ----
    private var record: AudioRecord? = null
    private var micThread: Thread? = null
    @Volatile private var micRunning = false
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var agc: AutomaticGainControl? = null

    @SuppressLint("MissingPermission")
    fun startMic(onChunk: (ByteArray) -> Unit): Boolean {
        if (micRunning) return true
        val minBuf = AudioRecord.getMinBufferSize(
            IN_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return false
        val chunkBytes = IN_RATE / 25 * 2 // 40 ms
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                IN_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, chunkBytes * 4)
            )
        } catch (e: Exception) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        val sid = rec.audioSessionId
        if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(sid)?.also { it.enabled = true }
        if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(sid)?.also { it.enabled = true }
        if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(sid)?.also { it.enabled = true }

        record = rec
        micRunning = true
        rec.startRecording()
        micThread = Thread({
            val buf = ByteArray(chunkBytes)
            while (micRunning) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) {
                    micLevel = rms(buf, n)
                    onChunk(buf.copyOf(n))
                } else if (n < 0) {
                    break
                }
            }
        }, "mishti-mic").also { it.start() }
        return true
    }

    fun stopMic() {
        micRunning = false
        try { micThread?.join(300) } catch (_: InterruptedException) {}
        micThread = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release()
        record = null
        aec?.release(); aec = null
        ns?.release(); ns = null
        agc?.release(); agc = null
        micLevel = 0f
    }

    // ---- playback ----
    private var track: AudioTrack? = null
    private var writer: Thread? = null
    private val queue = LinkedBlockingQueue<ByteArray>()
    private val framesWritten = AtomicLong(0)
    @Volatile private var writerRunning = false
    @Volatile private var generation = 0

    @Suppress("DEPRECATION")
    fun startPlayback() {
        if (track != null) return
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = true
        fx = VoiceFx(OUT_RATE, polish, loudness)
        if (loudness > 1.05f) {
            // Call volume is often set low; make sure a louder voice is actually heard.
            try {
                val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL)
                val cur = audioManager.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
                val want = (max * 0.85f).toInt()
                if (cur < want) audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, want, 0)
            } catch (_: Exception) {
            }
        }

        val minBuf = AudioTrack.getMinBufferSize(
            OUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(OUT_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(maxOf(minBuf, OUT_RATE / 8 * 2)) // ~125 ms
            .build()
        try {
            t.playbackParams = PlaybackParams().setPitch(pitch).setSpeed(speed)
        } catch (_: Exception) {
            // Some phones cannot change pitch; the voice then plays unchanged.
        }
        t.play()
        track = t
        framesWritten.set(0)

        writerRunning = true
        writer = Thread({
            val slice = OUT_RATE / 50 * 2 // 20 ms
            while (writerRunning) {
                val chunk = try { queue.take() } catch (e: InterruptedException) { break }
                val gen = generation
                var off = 0
                while (off < chunk.size && writerRunning && gen == generation) {
                    val len = min(slice, chunk.size - off)
                    outLevel = rms(chunk, off, len)
                    val w = t.write(chunk, off, len)
                    if (w <= 0) break
                    framesWritten.addAndGet((w / 2).toLong())
                    off += w
                }
            }
        }, "mishti-play").also { it.start() }
    }

    /**
     * Call mode gives echo cancellation and loud voice. Turn it off on standby so music or video
     * from other apps plays normally.
     */
    @Suppress("DEPRECATION")
    fun setCallMode(on: Boolean) {
        if (track == null) return
        audioManager.mode = if (on) AudioManager.MODE_IN_COMMUNICATION else AudioManager.MODE_NORMAL
        audioManager.isSpeakerphoneOn = on
    }

    fun play(pcm24k: ByteArray) {
        if (track == null) return
        val f = fx
        queue.offer(if (f != null) synchronized(f) { f.process(pcm24k) } else pcm24k)
    }

    /** User barged in: drop everything that is queued or buffered. */
    fun interrupt() {
        val t = track ?: return
        generation++
        queue.clear()
        fx = VoiceFx(OUT_RATE, polish, loudness)
        try {
            t.pause()
            t.flush()
            t.play()
        } catch (_: Exception) {}
        framesWritten.set(0)
        outLevel = 0f
    }

    /** Roughly how many ms of speech are still waiting to be heard. */
    fun outstandingMs(): Long {
        val t = track ?: return 0
        if (queue.isNotEmpty()) return 100
        val remaining = framesWritten.get() - t.playbackHeadPosition.toLong()
        if (remaining <= 0) {
            outLevel = 0f
            return 0
        }
        return remaining * 1000 / OUT_RATE
    }

    @Suppress("DEPRECATION")
    fun stopPlayback() {
        writerRunning = false
        writer?.interrupt()
        writer = null
        queue.clear()
        try { track?.stop() } catch (_: Exception) {}
        track?.release()
        track = null
        outLevel = 0f
        audioManager.isSpeakerphoneOn = false
        audioManager.mode = AudioManager.MODE_NORMAL
    }

    private fun rms(buf: ByteArray, len: Int): Float = rms(buf, 0, len)

    private fun rms(buf: ByteArray, off: Int, len: Int): Float {
        var sum = 0.0
        var count = 0
        var i = off
        val end = off + len - 1
        while (i < end) {
            val s = ((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort().toInt()
            sum += (s * s).toDouble()
            count++
            i += 2
        }
        if (count == 0) return 0f
        val r = sqrt(sum / count).toFloat() / 32768f
        return min(1f, abs(r) * 5f)
    }
}
