package com.mishti.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Foreground service that keeps Mishti alive (and the microphone allowed) while other apps are on screen.
 * It does no audio work itself; it just holds the process and shows the notification with Listen / Stop.
 */
class MishtiService : Service() {

    companion object {
        private const val CHANNEL = "mishti_session"
        private const val NOTIF_ID = 42
        private const val ACTION_TOGGLE = "com.mishti.assistant.TOGGLE"
        private const val ACTION_STOP = "com.mishti.assistant.STOP"

        @Volatile
        var running = false
            private set

        /** Starts the service (does nothing if it already runs). Best called while the app is on screen. */
        fun start(context: Context) {
            if (running) return
            try {
                ContextCompat.startForegroundService(context, Intent(context, MishtiService::class.java))
            } catch (_: Exception) {
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, MishtiService::class.java))
        }

        /** Changes the notification text without restarting the service (safe from the background). */
        fun refresh(context: Context, standby: Boolean, asleep: Boolean = false) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, build(context, standby, asleep))
        }

        private fun build(context: Context, standby: Boolean, asleep: Boolean = false): Notification {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Mishti session", NotificationManager.IMPORTANCE_LOW)
                )
            }
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java), flags
            )
            val toggle = PendingIntent.getService(
                context, 1, Intent(context, MishtiService::class.java).setAction(ACTION_TOGGLE), flags
            )
            val stop = PendingIntent.getService(
                context, 2, Intent(context, MishtiService::class.java).setAction(ACTION_STOP), flags
            )
            return NotificationCompat.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Mishti")
                .setContentText(
                    when {
                        standby -> "Standby: microphone off"
                        asleep -> "Resting. Say 'Hey Mishti' to wake me"
                        else -> "Listening, go ahead"
                    }
                )
                .setContentIntent(open)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(0, if (standby) "Listen" else "Standby", toggle)
                .addAction(0, "Off", stop)
                .build()
        }
    }

    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        wake?.let { if (it.isHeld) it.release() }
        wake = null
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val assistant = (application as MishtiApplication).assistant
        when (intent?.action) {
            ACTION_STOP -> {
                if (assistant.ui.value.armed && !assistant.ui.value.listening) {
                    assistant.disarm()
                } else {
                    assistant.stopListening()
                }
                // Still waiting for "Hey Mishti"? Then the service stays.
                if (!assistant.ui.value.armed) {
                    stopSelf()
                    return START_NOT_STICKY
                }
            }
            ACTION_TOGGLE -> assistant.toggleMute()
        }
        running = true
        if (wake == null) {
            // Keeps the CPU awake so Mishti hears you even with the screen off.
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mishti:listening").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
        ServiceCompat.startForeground(
            this,
            NOTIF_ID,
            build(this, assistant.ui.value.muted, assistant.ui.value.asleep),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        )
        return START_NOT_STICKY
    }
}
