package com.mishti.assistant

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.currentCoroutineContext

/**
 * Keeps an eye on the phone (battery, heat, storage, memory, internet) and calls [onAlert]
 * with a short note when something needs attention. Each kind of alert has a cool-down so
 * Mishti does not nag. Needs no special permission beyond network state.
 */
class DeviceWatcher(
    private val ctx: Context,
    private val onAlert: (String) -> Unit,
) {
    private val lastSent = HashMap<String, Long>()
    private var offlineSince = 0L

    suspend fun run() {
        delay(15_000)
        while (currentCoroutineContext().isActive) {
            try {
                check()
            } catch (_: Exception) {
            }
            delay(20_000)
        }
    }

    private fun due(key: String, cooldownMs: Long): Boolean {
        val now = System.currentTimeMillis()
        val prev = lastSent[key]
        if (prev != null && now - prev < cooldownMs) return false
        lastSent[key] = now
        return true
    }

    private fun check() {
        val min = 60_000L
        val battery: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (battery != null) {
            val level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
            val plugged = battery.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            val temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f

            if (pct >= 0 && !plugged) {
                when {
                    pct <= 5 && due("bat5", 5 * min) ->
                        onAlert("[DEVICE] Battery khub kom: $pct%, charge hochhe na. Ekhuni charger lagano dorkar.")
                    pct in 6..10 && due("bat10", 10 * min) ->
                        onAlert("[DEVICE] Battery $pct%, charge hochhe na.")
                    pct in 11..20 && due("bat20", 25 * min) ->
                        onAlert("[DEVICE] Battery $pct%, charge hochhe na.")
                }
            }
            if (plugged && pct >= 100 && due("full", 90 * min)) {
                onAlert("[DEVICE] Battery 100% hoye geche, charger kholar somoy.")
            }
            if (temp >= 45f && due("hot45", 6 * min)) {
                onAlert("[DEVICE] Phone khub gorom: ${"%.0f".format(temp)}°C. Bipod hote pare.")
            } else if (temp >= 41f && due("hot41", 12 * min)) {
                onAlert("[DEVICE] Phone gorom hoye jachhe: ${"%.0f".format(temp)}°C.")
            }
        }

        val stat = StatFs(Environment.getDataDirectory().path)
        val freeRatio = stat.availableBytes.toDouble() / stat.totalBytes.toDouble()
        if (freeRatio < 0.07 && due("storage", 90 * min)) {
            val freeGb = stat.availableBytes / 1_000_000_000.0
            onAlert("[DEVICE] Storage prai bhore geche: matro ${"%.1f".format(freeGb)} GB khali.")
        }

        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        if (mem.lowMemory && due("ram", 20 * min)) {
            onAlert("[DEVICE] Phone-er RAM ekdom kom, phone dhimi hote pare.")
        }

        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val online = cm.activeNetwork != null
        val now = System.currentTimeMillis()
        if (!online) {
            if (offlineSince == 0L) offlineSince = now
        } else {
            if (offlineSince != 0L && now - offlineSince >= 45_000 && due("net", 10 * min)) {
                onAlert("[DEVICE] Internet kichhukkhon chhilo na, ekhon abar eshechhe.")
            }
            offlineSince = 0L
        }
    }
}
