package com.mishti.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Where the phone is right now, and which apps are allowed to follow it. Runs on a background thread. */
object Locator {

    private const val FINE = Manifest.permission.ACCESS_FINE_LOCATION
    private const val COARSE = Manifest.permission.ACCESS_COARSE_LOCATION
    private const val BACKGROUND = "android.permission.ACCESS_BACKGROUND_LOCATION"

    private fun has(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun enabled(lm: LocationManager): Boolean =
        if (Build.VERSION.SDK_INT >= 28) {
            lm.isLocationEnabled
        } else {
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        }

    @SuppressLint("MissingPermission")
    private fun fresh(ctx: Context, lm: LocationManager, provider: String, waitSec: Long): Location? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var found: Location? = null
        try {
            lm.getCurrentLocation(provider, null, ctx.mainExecutor) { loc ->
                found = loc
                latch.countDown()
            }
            latch.await(waitSec, TimeUnit.SECONDS)
        } catch (_: Exception) {
        }
        return found
    }

    @Suppress("DEPRECATION")
    private fun addressOf(ctx: Context, lat: Double, lon: Double): String =
        try {
            if (!Geocoder.isPresent()) {
                ""
            } else {
                val a = Geocoder(ctx, Locale.getDefault()).getFromLocation(lat, lon, 1)?.firstOrNull()
                if (a == null) "" else (0..a.maxAddressLineIndex).joinToString(", ") { a.getAddressLine(it).orEmpty() }
            }
        } catch (_: Exception) {
            ""
        }

    /** The phone's position: coordinates, a street address, accuracy and speed. */
    @SuppressLint("MissingPermission")
    fun current(ctx: Context): JSONObject {
        val fine = has(ctx, FINE)
        val coarse = has(ctx, COARSE)
        if (!fine && !coarse) {
            return err("Location permission nei. User-ke bolo permission dite; na hole open_settings('apps') diye app info khulo.")
        }
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (!enabled(lm)) {
            return err("Phone-er Location switch bondho. User-ke jiggesh koro chalu korbe kina; haan bolle quick_toggle(tile='location', on=true).")
        }
        val providers = buildList {
            if (fine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) add(LocationManager.GPS_PROVIDER)
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) add(LocationManager.NETWORK_PROVIDER)
        }
        var best: Location? = null
        for (p in providers) {
            val loc = fresh(ctx, lm, p, if (p == LocationManager.GPS_PROVIDER) 6 else 3) ?: continue
            if (best == null || loc.accuracy < best.accuracy) best = loc
            if (loc.accuracy in 0.1f..40f) break
        }
        if (best == null) {
            for (p in providers + LocationManager.PASSIVE_PROVIDER) {
                val loc = try { lm.getLastKnownLocation(p) } catch (_: Exception) { null } ?: continue
                if (best == null || loc.time > best.time) best = loc
            }
        }
        val loc = best ?: return err("Ekhon location pelam na. Khola jaygay jete bolo, ba kichu khon por abar try koro.")
        val ageSec = ((System.currentTimeMillis() - loc.time) / 1000L).coerceAtLeast(0L)
        val address = addressOf(ctx, loc.latitude, loc.longitude)
        val out = JSONObject()
            .put("status", "ok")
            .put("latitude", loc.latitude)
            .put("longitude", loc.longitude)
            .put("accuracy_m", loc.accuracy.toInt())
            .put("address", address)
            .put("map_link", "https://maps.google.com/?q=${loc.latitude},${loc.longitude}")
            .put("fix_age_seconds", ageSec)
            .put("precise", fine)
        if (loc.hasSpeed()) {
            val kmh = (loc.speed * 3.6f).toInt()
            out.put("speed_kmh", kmh)
            out.put("moving", kmh >= 5)
        }
        if (ageSec > 300) out.put("note", "Ei position purono (${ageSec / 60} minute age-r). Bolo je eta shesh jana jaygar.")
        if (address.isEmpty()) out.put("note_address", "Thikana pelam na, shudhu coordinates ache. Map link dao.")
        return out
    }

    /** Is location on, what is Mishti allowed, and which apps can follow the phone (always, or only when open). */
    fun status(ctx: Context): JSONObject {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val always = ArrayList<String>()
        val whileUse = ArrayList<String>()
        val pm = ctx.packageManager
        val pkgs: List<PackageInfo> = try {
            pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        } catch (_: Exception) {
            emptyList()
        }
        for (p in pkgs) {
            val ai = p.applicationInfo ?: continue
            if (p.packageName == ctx.packageName) continue
            val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val updated = (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            if (system && !updated) continue
            val perms = p.requestedPermissions ?: continue
            val flags = p.requestedPermissionsFlags ?: continue
            fun granted(name: String): Boolean {
                val i = perms.indexOf(name)
                return i >= 0 && i < flags.size && (flags[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
            }
            if (!granted(FINE) && !granted(COARSE)) continue
            val label = pm.getApplicationLabel(ai).toString()
            if (granted(BACKGROUND)) always.add(label) else whileUse.add(label)
        }
        fun arr(l: List<String>) = JSONArray().also { a -> l.sorted().take(20).forEach { a.put(it) } }
        return JSONObject()
            .put("status", "ok")
            .put("location_switch_on", enabled(lm))
            .put("mishti_precise_permission", has(ctx, FINE))
            .put("mishti_approx_permission", has(ctx, COARSE))
            .put("mishti_background_permission", has(ctx, BACKGROUND))
            .put("apps_that_can_follow_you_always", arr(always))
            .put("apps_that_use_location_only_when_open", arr(whileUse))
            .put("note", "Eta shudhu permission dekhay: kon app kokhon location pachhe ta Android bolte dey na. 'always' app-gulo shobcheye beshi track korte pare.")
    }

    private fun err(m: String) = JSONObject().put("status", "error").put("message", m)
}
