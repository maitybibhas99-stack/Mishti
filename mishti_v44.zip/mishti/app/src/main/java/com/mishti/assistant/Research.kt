package com.mishti.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** A separate, non-live Gemini call with Google Search, used for research that runs in the background. */
object Research {
    private val http = OkHttpClient.Builder()
        .callTimeout(80, TimeUnit.SECONDS)
        .build()

    fun ask(apiKey: String, question: String, language: String): String {
        val lang = when (language) {
            "bangla" -> "Bangla"
            "hindi" -> "Hindi"
            "english" -> "English"
            else -> "the same language as the question"
        }
        val prompt = "Search the web if needed and answer accurately, briefly and in plain spoken style " +
            "(at most 6 short sentences, no markdown) in $lang. Question: $question"
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                )
            )
            .put("tools", JSONArray().put(JSONObject().put("googleSearch", JSONObject())))
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=$apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
            val parts = JSONObject(raw).optJSONArray("candidates")
                ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw IllegalStateException("khali uttor")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
            return sb.toString().trim().ifEmpty { throw IllegalStateException("khali uttor") }
        }
    }
}
