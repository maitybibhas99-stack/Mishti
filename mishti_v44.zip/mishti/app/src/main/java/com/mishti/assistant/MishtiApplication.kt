package com.mishti.assistant

import android.app.Application

class MishtiApplication : Application() {
    /** One assistant for the whole process, so it survives the screen being closed. */
    val assistant: Assistant by lazy { Assistant(this) }
}
