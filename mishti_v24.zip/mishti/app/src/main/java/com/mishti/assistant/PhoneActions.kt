package com.mishti.assistant

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

/** Everything Mishti can do on the phone. One function per tool in Tools.kt. Every result goes back to the model as JSON. */
class PhoneActions(
    private val ctx: Context,
    private val prefs: Prefs,
    private val hooks: Hooks,
) {
    interface Hooks {
        fun standby()
        fun endSession()

        /** Rest: the internet session closes but she still wakes on "Hey Mishti". */
        fun sleep()

        /** Starts web research in the background; the answer is announced later. */
        fun research(question: String): String

        /** Queues screen steps to run in the background after the current work; the result is announced later. */
        fun queueSteps(title: String, steps: JSONArray): String
    }

    private companion object {
        // Column names written out so we do not depend on inherited Java constants.
        const val COL_NAME = "display_name"
        const val COL_NUMBER = "data1"
        const val COL_TYPE = "data2"
        const val NEED_A11Y =
            "Accessibility chalu nei. User-ke bolo Mishti-r Settings-e giye Accessibility chalu korte, ba open_settings(accessibility) chalao."
    }

    fun run(name: String, args: JSONObject): JSONObject = try {
        when (name) {
            "call_contact" -> callContact(args.optString("name_or_number"))
            "send_sms" -> sendSms(args.optString("to"), args.optString("message"))
            "open_app" -> openApp(args.optString("app_name"))
            "open_url" -> openUrl(args.optString("url"))
            "play_youtube" -> playYoutube(args.optString("query"))
            "quick_toggle" -> quickToggle(args.optString("tile"), if (args.has("on")) args.optBoolean("on") else null)
            "do_steps" -> doSteps(args.optJSONArray("steps"))
            "read_notifications" -> notif { it.list(args.optInt("limit", 8), args.optString("app")) }
            "dismiss_notification" -> notif { it.dismiss(args.optString("id")) }
            "reply_notification" -> notif { it.reply(args.optString("id"), args.optString("text")) }
            "open_notification" -> notif { it.openIt(args.optString("id")) }
            "research" -> research(args.optString("question"))
            "queue_task" -> queueTask(args.optString("title"), args.optJSONArray("steps"))
            "save_routine" -> saveRoutine(args.optString("name"), args.optJSONArray("steps"))
            "run_routine" -> runRoutine(args.optString("name"))
            "play_media" -> playMedia(args.optString("query"), args.optString("app"))
            "read_screen" -> screen { it.snapshot() }
            "tap_text" -> screen { it.tapText(args.optString("text")) }
            "tap_index" -> screen { it.tapIndex(args.optInt("index", -1)) }
            "type_text" -> screen {
                it.typeText(
                    args.optString("text"),
                    if (args.has("index")) args.optInt("index", -1) else -1,
                    args.optBoolean("append", false)
                )
            }
            "scroll_find" -> screen {
                it.scrollFind(
                    args.optString("text"),
                    args.optString("direction"),
                    args.optInt("max", 6),
                    args.optBoolean("tap", false)
                )
            }
            "tap_at" -> screen {
                it.tapPercent(args.optInt("x", 50), args.optInt("y", 50), args.optInt("hold_ms", 70).toLong())
            }
            "wait_for_text" -> screen { it.waitForText(listOf(args.optString("text")), args.optInt("seconds", 6)) }
            "install_app" -> installApp(args.optString("name"), args.optString("package"))
            "press_key" -> screen { it.pressKey(args.optString("key")) }
            "swipe" -> screen { it.swipe(args.optString("direction")) }
            "wait" -> waitFor(if (args.has("ms")) args.optInt("ms", 500).toLong() else args.optInt("seconds", 2) * 1000L)
            "open_settings" -> openSettings(args.optString("page"))
            "torch" -> torch(args.optBoolean("on", true))
            "set_volume" -> setVolume(args.optInt("percent", -1), args.optString("stream"))
            "set_alarm" -> setAlarm(args.optInt("hour", -1), args.optInt("minute", 0), args.optString("label"))
            "set_timer" -> setTimer(args.optInt("seconds", -1), args.optString("label"))
            "device_info" -> deviceInfo()
            "remember" -> remember(args.optString("note"))
            "forget" -> forget(args.optString("keyword"))
            "standby" -> { hooks.standby(); ok("Standby: mic bondho, gaan-er jonno chup.") }
            "sleep" -> { hooks.sleep(); ok("Ghumote jachhi. Ar kichu bolo na.") }
            "end_session" -> { hooks.endSession(); ok("Session bondho hochhe.") }
            else -> err("Ei tool-ta nei: $name")
        }
    } catch (e: Exception) {
        err("${e.javaClass.simpleName}: ${e.message}")
    }

    // ------------------------------------------------------------------ launching

    /**
     * Starts an activity. Prefers the accessibility service's context, because Android blocks
     * ordinary apps from opening screens while another app is in front.
     */
    private fun launch(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val starter: Context = MishtiAccessibilityService.instance ?: ctx
        starter.startActivity(intent)
    }

    private fun notif(block: (MishtiNotificationService) -> JSONObject): JSONObject {
        var svc = MishtiNotificationService.instance
        val on = MishtiNotificationService.enabled(ctx)
        if (svc == null && on) {
            // Access is on but Android has not bound the listener (after an update or a kill): bring it back.
            MishtiNotificationService.rebind(ctx)
            var tries = 0
            while (svc == null && tries < 14) {
                Thread.sleep(250)
                svc = MishtiNotificationService.instance
                tries++
            }
        }
        if (svc == null) {
            return if (on) {
                err("Notification access is on but not connected right now. Do it by sight instead: press_key('notifications'), read_screen, read them out, then press_key('back'). Tell the user to turn Notification access off and on once in Settings if this keeps happening.")
            } else {
                err("Notification access is off. Tell the user warmly, and call open_settings('notification_access') so they can switch Mishti on. Meanwhile you can still read them by sight: press_key('notifications'), read_screen, then press_key('back').")
            }
        }
        return block(svc)
    }

    private fun screen(block: (MishtiAccessibilityService) -> JSONObject): JSONObject {
        val svc = MishtiAccessibilityService.instance ?: return err(NEED_A11Y)
        return block(svc)
    }

    // ------------------------------------------------------------------ call / sms

    private fun callContact(query: String): JSONObject {
        if (!has(Manifest.permission.CALL_PHONE)) {
            return err("Call permission nei. User-ke bolo Settings > Apps > Mishti > Permissions theke Phone allow korte.")
        }
        val r = resolve(query)
        r.error?.let { return it }
        launch(Intent(Intent.ACTION_CALL, Uri.fromParts("tel", r.number, null)))
        return ok("${r.label}-ke call lagano hocche.")
    }

    private fun sendSms(to: String, message: String): JSONObject {
        if (message.isBlank()) return err("Message khali. User-ke jiggesh koro ki likhbe.")
        if (!has(Manifest.permission.SEND_SMS)) {
            return err("SMS permission nei. User-ke bolo Settings > Apps > Mishti > Permissions theke SMS allow korte.")
        }
        val r = resolve(to)
        r.error?.let { return it }
        val sms = smsManager()
        val parts = sms.divideMessage(message)
        sms.sendMultipartTextMessage(r.number, null, parts, null, null)
        return ok("${r.label}-ke SMS pathano hoyeche.")
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private class Resolved(val number: String? = null, val label: String? = null, val error: JSONObject? = null)

    /** Turns "Rahul", "Rahul Das" or "98300 12345" into a number. Ambiguous names are handed back to the model. */
    private fun resolve(query: String): Resolved {
        val q = query.trim()
        if (q.isEmpty()) return Resolved(error = err("Kar naam ba number? User-ke jiggesh koro."))

        val looksLikeNumber = q.count { it.isDigit() } >= 3 && q.all { it.isDigit() || it in "+ -()" }
        if (looksLikeNumber) return Resolved(number = q.filter { it.isDigit() || it == '+' }, label = q)

        if (!has(Manifest.permission.READ_CONTACTS)) {
            return Resolved(error = err("Contacts permission nei. User-ke bolo Settings > Apps > Mishti > Permissions theke Contacts allow korte."))
        }

        val rows = mutableListOf<Triple<String, String, Int>>() // name, number, type
        ctx.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(COL_NAME, COL_NUMBER, COL_TYPE),
            "$COL_NAME LIKE ?",
            arrayOf("%$q%"),
            null
        )?.use { c ->
            while (c.moveToNext()) {
                rows.add(Triple(c.getString(0).orEmpty(), c.getString(1).orEmpty(), c.getInt(2)))
            }
        }
        if (rows.isEmpty()) return Resolved(error = err("'$q' naame kono contact paini."))

        val names = rows.map { it.first }.distinct()
        val chosen = when {
            names.size == 1 -> names[0]
            else -> names.firstOrNull { it.equals(q, ignoreCase = true) }
        }
        if (chosen == null) {
            val json = JSONObject()
                .put("status", "ambiguous")
                .put("matches", JSONArray(names.take(6)))
                .put(
                    "message",
                    "Ekadhik contact mile geche. User-ke jiggesh koro kon-ta, tarpor full naam diye abar try koro."
                )
            return Resolved(error = json)
        }

        val mine = rows.filter { it.first == chosen }
        val best = mine.firstOrNull { it.third == Phone.TYPE_MOBILE } ?: mine.first()
        val number = best.second.filter { it.isDigit() || it == '+' }
        if (number.isEmpty()) return Resolved(error = err("$chosen-er number paini."))
        return Resolved(number = number, label = chosen)
    }

    // ------------------------------------------------------------------ apps, web, media

    private fun openApp(appName: String): JSONObject {
        val q = appName.trim().lowercase()
        if (q.isEmpty()) return err("Kon app? User-ke jiggesh koro.")

        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }

        val exact = apps.filter { it.first.lowercase() == q }
        val hits = if (exact.isNotEmpty()) exact else apps.filter { it.first.lowercase().contains(q) }
        if (hits.isEmpty()) return err("'$appName' naame kono app paini.")
        if (hits.size > 1) {
            return JSONObject()
                .put("status", "ambiguous")
                .put("matches", JSONArray(hits.take(6).map { it.first }))
                .put("message", "Ekadhik app mile geche. User-ke jiggesh koro kon-ta, tarpor exact naam diye abar try koro.")
        }

        val (label, pkg) = hits[0]
        val intent = pm.getLaunchIntentForPackage(pkg) ?: return err("$label khola gelo na.")
        launch(intent)
        return ok("$label khola hocche.")
    }

    private fun openUrl(url: String): JSONObject {
        val u = url.trim()
        if (u.isEmpty()) return err("Kon link?")
        val full = if (u.contains("://")) u else "https://$u"
        launch(Intent(Intent.ACTION_VIEW, Uri.parse(full)))
        return ok("Link khola hocche.")
    }

    private fun playMedia(query: String, app: String): JSONObject {
        val q = query.trim()
        if (q.isEmpty()) return err("Ki chalabo? User-ke jiggesh koro.")
        val a = app.trim().lowercase().replace(" ", "_")

        val pkg = when (a) {
            "spotify" -> "com.spotify.music"
            "youtube_music", "ytmusic" -> "com.google.android.apps.youtube.music"
            else -> null
        }
        if (pkg != null) {
            if (!isInstalled(pkg)) return err("$a phone-e install kora nei.")
            val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .setPackage(pkg)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                .putExtra(SearchManager.QUERY, q)
            launch(intent)
            return ok("$a-te '$q' chalano hocche. Chalu na hole read_screen diye dekho.")
        }

        val url = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")
        val ytPkg = "com.google.android.youtube"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        if (isInstalled(ytPkg)) intent.setPackage(ytPkg)
        launch(intent)
        return ok("YouTube-e '$q' search kholechhi. Ekhon wait(3), read_screen, tarpor prothom video-te tap koro.")
    }

    private fun isInstalled(pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    private fun waitFor(ms: Long): JSONObject {
        Thread.sleep(ms.coerceIn(100L, 8000L))
        return ok("Opekkha shesh.")
    }

    // ------------------------------------------------------------------ fast paths

    private val web by lazy {
        OkHttpClient.Builder()
            .callTimeout(5, TimeUnit.SECONDS)
            .build()
    }

    /** Looks the query up on YouTube and returns the first video's id, or null. */
    private fun firstVideoId(query: String): String? {
        val url = "https://www.youtube.com/results?search_query=" +
            URLEncoder.encode(query, "UTF-8") + "&sp=EgIQAQ%253D%253D"
        val req = Request.Builder()
            .url(url)
            .header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
            )
            .header("Accept-Language", "en-US,en;q=0.9")
            .header("Cookie", "CONSENT=YES+cb; SOCS=CAI")
            .build()
        web.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            return Regex("\"videoId\":\"([A-Za-z0-9_-]{11})\"").find(body)?.groupValues?.get(1)
        }
    }

    private fun playYoutube(query: String): JSONObject {
        val q = query.trim()
        if (q.isEmpty()) return err("Ki chalabo? User-ke jiggesh koro.")
        val id = try {
            firstVideoId(q)
        } catch (e: Exception) {
            null
        }
        if (id == null) return playMedia(q, "")
        val ytPkg = "com.google.android.youtube"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$id"))
        if (isInstalled(ytPkg)) intent.setPackage(ytPkg)
        launch(intent)
        return ok("YouTube-e '$q' chalu hoyeche. Aar kono tap lagbe na.")
    }

    /** Opens the Play Store on the app and taps Install. */
    private fun installApp(name: String, pkg: String): JSONObject {
        val svc = MishtiAccessibilityService.instance ?: return err(NEED_A11Y)
        val n = name.trim()
        val p = pkg.trim()
        if (n.isEmpty() && p.isEmpty()) return err("Kon app install korbo?")
        if (p.isNotEmpty() && isInstalled(p)) return ok("App agei install kora ache. open_app diye kholo.")
        val uri = if (p.isNotEmpty()) "market://details?id=$p"
        else "market://search?q=" + URLEncoder.encode(n, "UTF-8") + "&c=apps"
        try {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage("com.android.vending"))
        } catch (e: Exception) {
            return err("Play Store khola gelo na: ${e.message}")
        }
        Thread.sleep(500)
        return svc.playInstall()
    }

    private fun quickToggle(tile: String, on: Boolean?): JSONObject {
        if (tile.isBlank()) return err("Kon setting? wifi, bluetooth, airplane...")
        return screen { it.quickToggle(tile, on) }
    }

    private fun research(question: String): JSONObject {
        if (question.isBlank()) return err("Ki khujbo?")
        return ok(hooks.research(question.trim()))
    }

    private fun queueTask(title: String, steps: JSONArray?): JSONObject {
        if (steps == null || steps.length() == 0) return err("steps khali.")
        return ok(hooks.queueSteps(title.trim().ifEmpty { "kaj" }, steps))
    }

    private fun saveRoutine(name: String, steps: JSONArray?): JSONObject {
        if (name.isBlank()) return err("Routine-er naam dao.")
        if (steps == null || steps.length() == 0) return err("steps khali.")
        prefs.saveRoutine(name, steps)
        return ok("Routine '${name.trim()}' save hoyeche. Porer bar run_routine diye ek call-e hobe.")
    }

    private fun runRoutine(name: String): JSONObject {
        val steps = prefs.routine(name)
            ?: return err("'$name' naame routine nei. Ache: ${prefs.routineNames.joinToString()}")
        return doSteps(steps)
    }

    /** Runs a list of tool steps one after another and stops at the first problem. */
    private fun doSteps(steps: JSONArray?): JSONObject {
        if (steps == null || steps.length() == 0) return err("steps khali.")
        val results = JSONArray()
        for (i in 0 until minOf(steps.length(), 20)) {
            val step = steps.optJSONObject(i) ?: continue
            val tool = step.optString("tool")
            if (tool.isBlank() || tool == "do_steps") return err("Step ${i + 1}-e tool-er naam thik nei.")
            val r = run(tool, step)
            r.put("tool", tool)
            results.put(r)
            if (r.optString("status") != "ok") {
                return JSONObject()
                    .put("status", "error")
                    .put("failed_step", i + 1)
                    .put("message", "Step ${i + 1} ($tool) hoyni. Ekhane theke nijer moto chalao.")
                    .put("results", results)
            }
        }
        return JSONObject().put("status", "ok").put("results", results)
    }

    // ------------------------------------------------------------------ device

    private fun openSettings(page: String): JSONObject {
        val action = when (page.trim().lowercase()) {
            "wifi", "internet" ->
                if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS
            "volume" ->
                if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_VOLUME else Settings.ACTION_SOUND_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "battery_saver" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "nfc" -> Settings.ACTION_NFC_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "notification_access" -> Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "settings" -> Settings.ACTION_SETTINGS
            else -> return err("'$page' settings page-ta chini na.")
        }
        launch(Intent(action))
        return ok("$page settings khola hoyeche. Toggle korte read_screen, tarpor tap_text.")
    }

    private fun torch(on: Boolean): JSONObject {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return err("Ei phone-e flash nei.")
        cm.setTorchMode(id, on)
        return ok(if (on) "Torch jalano hoyeche." else "Torch nibhano hoyeche.")
    }

    private fun setVolume(percent: Int, stream: String): JSONObject {
        if (percent !in 0..100) return err("Volume 0 theke 100-er moddhe hote hobe.")
        val type = when (stream.trim().lowercase()) {
            "ring" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            else -> AudioManager.STREAM_MUSIC
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(type)
        val level = (max * percent / 100f).toInt().coerceIn(0, max)
        am.setStreamVolume(type, level, AudioManager.FLAG_SHOW_UI)
        return ok("Volume $percent% kora hoyeche.")
    }

    private fun setAlarm(hour: Int, minute: Int, label: String): JSONObject {
        if (hour !in 0..23 || minute !in 0..59) return err("Somoy bujhte parini. Ghonta 0-23, minute 0-59.")
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label.isNotBlank()) intent.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        launch(intent)
        return ok("Alarm set: %02d:%02d.".format(hour, minute))
    }

    private fun setTimer(seconds: Int, label: String): JSONObject {
        if (seconds <= 0) return err("Koto second-er timer?")
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label.isNotBlank()) intent.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        launch(intent)
        return ok("$seconds second-er timer set hoyeche.")
    }

    private fun deviceInfo(): JSONObject {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val now = LocalDateTime.now()
        return JSONObject()
            .put("status", "ok")
            .put("date", now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy")))
            .put("time", now.format(DateTimeFormatter.ofPattern("hh:mm a")))
            .put("timezone", ZoneId.systemDefault().id)
            .put("battery_percent", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
            .put("charging", bm.isCharging)
    }

    // ------------------------------------------------------------------ memory

    private fun remember(note: String): JSONObject {
        if (note.isBlank()) return err("Ki mone rakhbo?")
        prefs.addNote(note)
        return ok("Mone rakhlam.")
    }

    private fun forget(keyword: String): JSONObject {
        val n = prefs.removeNotes(keyword)
        return if (n > 0) ok("$n ta note mushe dilam.") else err("Ei shobdo-r kono note paini.")
    }

    // ------------------------------------------------------------------ helpers

    private fun has(permission: String) =
        ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED

    private fun ok(msg: String) = JSONObject().put("status", "ok").put("message", msg)

    private fun err(msg: String) = JSONObject().put("status", "error").put("message", msg)
}
