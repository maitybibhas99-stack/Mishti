package com.mishti.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.channels.Channel
import org.json.JSONArray
import androidx.compose.runtime.mutableFloatStateOf
import java.util.Calendar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

data class ChatMessage(val id: Long, val fromUser: Boolean, val text: String)

enum class Phase { Idle, Connecting, Listening, Speaking }

data class Ui(
    val messages: List<ChatMessage> = emptyList(),
    val phase: Phase = Phase.Idle,
    /** The full-screen orb is showing. */
    val voiceOpen: Boolean = false,
    /** Mishti is switched on: she keeps listening, even with the orb screen closed. */
    val listening: Boolean = false,
    /** Standby: mic is off so music/video does not confuse her. */
    val muted: Boolean = false,
    /** Waiting for "Hey Mishti" with the light offline listener (Mishti is off or resting). */
    val armed: Boolean = false,
    /** Resting: no internet session, only a light ear out for "Hey Mishti". */
    val asleep: Boolean = false,
    /** What she is doing right now, shown under the orb. */
    val activity: String? = null,
    val error: String? = null,
)

/**
 * The whole session. Lives as long as the app process (not the screen), so Mishti keeps
 * listening while other apps are in front. MishtiService keeps the process alive in the background.
 *
 * Two ways in: voice (orb screen, mic on, she speaks) and text (chat, mic untouched, she stays silent).
 */
class Assistant(private val app: Application) : GeminiLiveClient.Listener {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val wake = WakeWordEngine(app) { scope.launch { onWakeWord() } }
    private var downloading = false

    /** Progress text for the offline wake model, shown in Settings. */
    val wakeStatus = MutableStateFlow(if (WakeWordEngine.modelReady(app)) "Ready" else "")

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()

    /** Loudness 0..1 for the orb. Kept apart from Ui so a 30 fps change redraws only the orb. */
    val level = mutableFloatStateOf(0f)

    val prefs = Prefs(app)
    private val audio = AudioEngine(app)
    private var client: GeminiLiveClient? = null
    private var ticker: Job? = null
    private var reconnectJob: Job? = null
    private var watcherJob: Job? = null
    private var chatterJob: Job? = null
    @Volatile private var lastTalk = System.currentTimeMillis()
    private var nextId = 1L
    private val pendingText = mutableListOf<String>()

    /** Tool calls run one after another, never in parallel (taps must not overlap). */
    private val toolLock = Mutex()

    private val phone = PhoneActions(app, prefs, object : PhoneActions.Hooks {
        override fun standby() = setStandby(true)
        override fun endSession() {
            scope.launch {
                waitForSpeechToFinish()
                stopListening()
            }
        }

        override fun sleep() {
            scope.launch {
                waitForSpeechToFinish()
                sleepNow()
            }
        }

        override fun research(question: String): String {
            val key = prefs.apiKey
            busy.incrementAndGet()
            scope.launch(Dispatchers.IO) {
                val answer = try {
                    Research.ask(key, question, prefs.language)
                } catch (e: Exception) {
                    null
                }
                busy.decrementAndGet()
                announce("Khoja: $question", answer ?: "Khuje ante parlam na. Internet ba API key ektu dekho.")
            }
            return "Background-e khujchhi. Hoye gele nijei jani dibo. User-ke bolo tumi onno kaj korte paro."
        }

        override fun queueSteps(title: String, steps: JSONArray): String {
            busy.incrementAndGet()
            jobs.trySend(title to steps)
            ensureWorker()
            return "'$title' queue-te rakha holo. Ager kaj sesh hole nijei korbe, sesh hole janabe. User-ke bolo tumi onno kaj korte paro."
        }
    })

    /** Screen jobs waiting to run in the background, one after another. */
    private val jobs = Channel<Pair<String, JSONArray>>(Channel.UNLIMITED)
    private var worker: Job? = null
    @Volatile private var lastSpoke = 0L
    /** Background jobs not finished yet (research, queued screen tasks). */
    private val busy = java.util.concurrent.atomic.AtomicInteger(0)
    private var sleeperJob: Job? = null
    @Volatile private var sleeping = false
    @Volatile private var waking = false
    private var loudRun = 0
    private var floor = 0.01f
    private val preRoll = ArrayDeque<ByteArray>()
    private var gateOpenUntil = 0L

    @Volatile private var ready = false
    @Volatile private var micStarted = false
    @Volatile private var standby = false
    @Volatile private var wantListening = false

    /** True after a typed message: that answer is shown as text only, never spoken. */
    @Volatile private var silentTurn = false

    /** 0 = full setup, 1 = without the language hint, 2 = bare minimum. Steps up if the server rejects setup. */
    private var compat = 0
    private var failures = 0
    private var lastProblem: String? = null
    private var smooth = 0f

    // ---------------------------------------------------------------- public API

    /** Switch Mishti on (mic on, orb screen). Call after the mic permission is granted. */
    fun startListening(show: Boolean = true) {
        wantListening = true
        silentTurn = false
        standby = false
        failures = 0
        compat = 0
        sleeping = false
        wake.stop()
        _ui.update { it.copy(voiceOpen = show, listening = true, muted = false, asleep = false, armed = false, error = null) }
        if (!ensureSession(voice = true)) return
        if (ready) startMicIfNeeded()
        startWatcher()
        startChatter()
        startSleeper()
    }

    /** Wake-word mode only: if nothing has happened for a while, Mishti rests and waits for "Hey Mishti". */
    private fun startSleeper() {
        if (sleeperJob?.isActive == true) return
        sleeperJob = scope.launch {
            while (isActive) {
                delay(5_000)
                val wakeMode = prefs.nameOnly || sleeping
                if (!wakeMode || !wantListening || client == null || !ready || standby) continue
                val idleMs = System.currentTimeMillis() - maxOf(lastSpoke, lastTalk)
                if (idleMs > 45_000 && !toolLock.isLocked && busy.get() == 0 && audio.outstandingMs() == 0L) {
                    sleepNow()
                }
            }
        }
    }

    private suspend fun waitForSpeechToFinish() {
        delay(500)
        var waited = 0
        while (audio.outstandingMs() > 0 && waited < 60) {
            delay(100)
            waited++
        }
    }

    /** Rest: close the internet session but keep the ear open for her name. */
    fun sleepNow() {
        if (!wantListening) return
        if (canArm()) {
            // The offline ear takes over; the internet session and mic close.
            stopListening()
            return
        }
        sleeping = true
        dropClient()
        MishtiAccessibilityService.instance?.glow(false)
        _ui.update { it.copy(asleep = true, phase = Phase.Idle, activity = null) }
        if (wantListening) MishtiService.refresh(app, standby, true)
    }

    /** Heard speech while resting: open the session so she can hear her name and answer. */
    private fun wakeUp() {
        if (waking) return
        waking = true
        scope.launch {
            try {
                if (wantListening && client == null) {
                    lastTalk = System.currentTimeMillis()
                    _ui.update { it.copy(asleep = false) }
                    MishtiService.refresh(app, standby, false)
                    connect()
                }
            } finally {
                waking = false
            }
        }
    }

    /** Now and then, when it has been quiet for a while, Mishti starts talking by herself. */
    private fun startChatter() {
        if (chatterJob?.isActive == true || !prefs.spontaneous) return
        chatterJob = scope.launch {
            while (isActive) {
                delay((40..70).random() * 60_000L)
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val quietFor = System.currentTimeMillis() - lastTalk
                if (wantListening && ready && !standby && hour in 8..23 && quietFor > 35 * 60_000L) {
                    silentTurn = false
                    lastTalk = System.currentTimeMillis()
                    client?.sendText("[SPONTANEOUS] Tomar ekhon ektu kotha bolte ichchhe korchhe.")
                }
            }
        }
    }

    private fun startWatcher() {
        if (watcherJob?.isActive == true || !prefs.deviceWatch) return
        val watcher = DeviceWatcher(app) { note ->
            scope.launch {
                // Only speak up when she is switched on and connected; otherwise skip it.
                if (wantListening && ready) {
                    silentTurn = false
                    client?.sendText(note)
                }
            }
        }
        watcherJob = scope.launch(Dispatchers.Default) { watcher.run() }
    }

    /** Show the orb screen again (she is already listening). */
    fun showVoice() {
        if (wantListening) _ui.update { it.copy(voiceOpen = true) } else startListening()
    }

    /** Close the orb screen only. Mishti keeps listening in the background. */
    fun hideVoice() {
        _ui.update { it.copy(voiceOpen = false) }
    }

    /** Switch Mishti fully off. */
    fun stopListening() {
        wantListening = false
        standby = false
        reconnectJob?.cancel()
        watcherJob?.cancel()
        watcherJob = null
        chatterJob?.cancel()
        chatterJob = null
        worker?.cancel()
        worker = null
        sleeperJob?.cancel()
        sleeperJob = null
        sleeping = false
        busy.set(0)
        synchronized(preRoll) { preRoll.clear() }
        MishtiAccessibilityService.instance?.glow(false)
        dropClient()
        audio.stopMic()
        audio.stopPlayback()
        micStarted = false
        synchronized(pendingText) { pendingText.clear() }
        stopTicker()
        // In "Hey Mishti" mode she never fully switches off: she goes back to waiting for her name.
        val rearm = canArm()
        if (!rearm) MishtiService.stop(app)
        _ui.update { it.copy(voiceOpen = false, listening = false, muted = false, phase = Phase.Idle, activity = null, asleep = false) }
        if (rearm) armWake()
    }

    private fun micGranted() =
        androidx.core.content.ContextCompat.checkSelfPermission(app, android.Manifest.permission.RECORD_AUDIO) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun canArm() = prefs.nameOnly && WakeWordEngine.modelReady(app) && micGranted()

    /** Start (or stop) the "Hey Mishti" listener to match the settings. Safe to call any time. */
    fun prepareWake() {
        if (!prefs.nameOnly) {
            disarm()
            return
        }
        if (!micGranted()) {
            _ui.update { it.copy(error = "'Hey Mishti' needs microphone permission. Tap the voice button once to allow it.") }
            return
        }
        if (!WakeWordEngine.modelReady(app)) {
            if (downloading) return
            downloading = true
            wakeStatus.value = "Downloading model: 0%"
            scope.launch(Dispatchers.IO) {
                val err = WakeWordEngine.download(app) { p -> wakeStatus.value = "Downloading model: $p%" }
                downloading = false
                if (err == null) {
                    wakeStatus.value = "Ready"
                    scope.launch { armWake() }
                } else {
                    wakeStatus.value = "Model download failed ($err). Check your internet and save again."
                }
            }
            return
        }
        wakeStatus.value = "Ready"
        armWake()
    }

    private fun armWake() {
        if (wantListening || !canArm()) return
        MishtiService.start(app)
        if (wake.start()) {
            _ui.update { it.copy(armed = true, asleep = true, phase = Phase.Idle) }
            MishtiService.refresh(app, false, true)
        }
    }

    /** Stop waiting for "Hey Mishti" (the user turned it off). */
    fun disarm() {
        wake.release()
        val wasArmed = _ui.value.armed
        _ui.update { it.copy(armed = false, asleep = false) }
        if (wasArmed && !wantListening) MishtiService.stop(app)
    }

    /** The Off button: if she is only waiting for her name, stop that too. */
    fun turnOff() {
        if (_ui.value.armed && !wantListening) disarm() else stopListening()
    }

    /** She heard her name while off or resting: wake up fully, without opening any screen. */
    private fun onWakeWord() {
        if (wantListening) return
        synchronized(pendingText) {
            pendingText.add("[WOKEN] He just called your name. Answer right away with one short, sleepy-sweet line, then listen to him.")
        }
        startListening(show = false)
    }

    /** Standby = mic off + normal audio mode (so music sounds right). Turning it off makes Mishti listen again. */
    fun setStandby(on: Boolean) {
        standby = on
        _ui.update { it.copy(muted = on) }
        audio.setCallMode(!on)
        if (wantListening) MishtiService.refresh(app, on)
    }

    fun toggleMute() = setStandby(!standby)

    fun sendText(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        silentTurn = true
        lastTalk = System.currentTimeMillis()
        addOrAppend(fromUser = true, text = clean, forceNew = true)
        _ui.update { it.copy(error = null) }
        if (!ensureSession(voice = false)) return
        if (ready) client?.sendText(clean) else synchronized(pendingText) { pendingText.add(clean) }
    }

    fun newChat() {
        _ui.update { it.copy(messages = emptyList(), error = null, activity = null) }
        // Fresh conversation for the model too.
        dropClient()
        if (wantListening) {
            connect()
        } else {
            stopTicker()
            _ui.update { it.copy(phase = Phase.Idle) }
        }
    }

    fun dismissError() {
        _ui.update { it.copy(error = null) }
    }

    // ---------------------------------------------------------------- notifications

    private val notifBuf = mutableListOf<NotifInfo>()
    private var notifJob: Job? = null

    /** Called by MishtiNotificationService for each new notification. */
    fun onNotification(n: NotifInfo) {
        scope.launch {
            when (n.kind) {
                NotifKind.JUNK -> when (prefs.junkMode) {
                    "auto" -> MishtiNotificationService.instance?.dismiss(n.id)
                    "ask" -> queueNotif(n)
                    else -> Unit
                }
                NotifKind.IMPORTANT, NotifKind.MESSAGE -> if (prefs.notifyAloud) queueNotif(n)
                NotifKind.OTHER -> Unit
            }
        }
    }

    /** Collects what arrives within a moment into one short spoken heads-up. */
    private fun queueNotif(n: NotifInfo) {
        if (!wantListening || standby) return
        notifBuf.add(n)
        if (notifJob?.isActive == true) return
        notifJob = scope.launch {
            delay(1800)
            flushNotifs()
        }
    }

    private fun flushNotifs() {
        val items = notifBuf.toList()
        notifBuf.clear()
        if (items.isEmpty()) return
        val lines = items.take(4).map { n ->
            when (n.kind) {
                NotifKind.JUNK -> "[NOTIFICATION-JUNK?] id=${n.id} ${n.app}: ${n.title}"
                NotifKind.IMPORTANT ->
                    "[NOTIFICATION-IMPORTANT] id=${n.id} ${n.app} - ${n.title}" +
                        (if (n.sensitive) " (content hidden, sensitive)" else ": ${n.text.take(200)}")
                else -> "[NOTIFICATION-NEW] id=${n.id} ${n.app}: ${n.title}"
            }
        }
        val more = items.size - 4
        val note = lines.joinToString("\n") + if (more > 0) "\n(+$more aro)" else ""
        silentTurn = false
        lastTalk = System.currentTimeMillis()
        if (ready) {
            client?.sendText(note)
        } else if (wantListening) {
            synchronized(pendingText) { pendingText.add(note) }
            if (client == null) wakeUp()
        }
    }

    // ---------------------------------------------------------------- background work

    private fun ensureWorker() {
        if (worker?.isActive == true) return
        worker = scope.launch(Dispatchers.IO) {
            for ((title, steps) in jobs) {
                val result = toolLock.withLock {
                    _ui.update { it.copy(activity = "Background-e: $title") }
                    MishtiAccessibilityService.instance?.glow(true)
                    val r = phone.run("do_steps", JSONObject().put("steps", steps))
                    MishtiAccessibilityService.instance?.glow(false)
                    r
                }
                busy.decrementAndGet()
                announce(title, summarize(result))
            }
        }
    }

    /** Turns a do_steps result into a few plain words (and what was on screen, if she looked). */
    private fun summarize(r: JSONObject): String {
        if (r.optString("status") != "ok") return "Hoyni: " + r.optString("message", "kichu ekta bhul holo.")
        val results = r.optJSONArray("results") ?: return "Hoye geche."
        val sb = StringBuilder()
        for (i in 0 until results.length()) {
            val item = results.optJSONObject(i) ?: continue
            val els = item.optJSONArray("elements") ?: continue
            for (j in 0 until minOf(els.length(), 25)) {
                val t = els.optJSONObject(j)?.optString("text").orEmpty()
                if (t.isNotBlank()) sb.append(t).append(". ")
            }
        }
        return if (sb.isEmpty()) "Hoye geche." else "Hoye geche. Screen-e: " + sb.toString().take(600)
    }

    /** A background job finished: show the result, notify, and let Mishti tell him. */
    private fun announce(title: String, body: String) {
        scope.launch {
            addOrAppend(fromUser = false, text = "$title\n$body", forceNew = true)
            notifyDone(title, body)
            val note = "[TASK DONE] $title. Result: ${body.take(1500)}"
            if (ready) {
                silentTurn = !wantListening
                lastTalk = System.currentTimeMillis()
                client?.sendText(note)
            } else if (wantListening) {
                // Resting: wake up to tell him.
                silentTurn = false
                synchronized(pendingText) { pendingText.add(note) }
                if (client == null) wakeUp()
            }
        }
    }

    private fun notifyDone(title: String, body: String) {
        try {
            val nm = app.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel("mishti_done") == null) {
                nm.createNotificationChannel(
                    NotificationChannel("mishti_done", "Mishti results", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
            val open = PendingIntent.getActivity(
                app, 3, Intent(app, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(app, "mishti_done")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title.take(60))
                .setContentText(body.take(200))
                .setStyle(NotificationCompat.BigTextStyle().bigText(body.take(1000)))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify((System.currentTimeMillis() % 100000).toInt() + 100, n)
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- session

    private fun ensureSession(voice: Boolean): Boolean {
        if (voice) {
            MishtiService.start(app)
            audio.pitch = prefs.voicePitch
            audio.speed = prefs.voiceSpeed
            audio.polish = prefs.voicePolish
            audio.loudness = prefs.voiceLoud
            audio.startPlayback()
        }
        if (client != null) return true
        if (prefs.apiKey.isBlank()) {
            wantListening = false
            _ui.update {
                it.copy(
                    voiceOpen = false,
                    listening = false,
                    error = "No Gemini API key yet. Open Settings and add your key."
                )
            }
            if (voice) {
                audio.stopPlayback()
                MishtiService.stop(app)
            }
            return false
        }
        connect()
        return true
    }

    private fun connect() {
        val key = prefs.apiKey
        if (key.isBlank()) return
        ready = false
        _ui.update { it.copy(phase = Phase.Connecting) }
        val options = GeminiLiveClient.Options(
            silenceMs = prefs.silenceMs,
            webSearch = prefs.webSearch,
            lean = compat >= 2,
            langCode = if (compat == 0) langCode() else null,
            bargeIn = prefs.bargeIn,
            noisy = prefs.noisyRoom,
        )
        val prompt = Persona.prompt(prefs.userName, prefs.notes, prefs.language, prefs.nameOnly || sleeping, prefs.routineNames)
        client = GeminiLiveClient(key, prefs.model, this, options).also {
            it.connect(prompt, prefs.voice)
        }
        startTicker()
    }

    private fun langCode(): String? = when (prefs.language) {
        "bangla" -> "bn-IN"
        "hindi" -> "hi-IN"
        "english" -> "en-US"
        else -> null
    }

    private fun dropClient() {
        client?.close()
        client = null
        ready = false
    }

    private fun startMicIfNeeded() {
        if (micStarted || !wantListening) return
        val ok = audio.startMic { chunk -> routeMic(chunk) }
        if (ok) {
            micStarted = true
        } else {
            stopListening()
            _ui.update { it.copy(error = "Couldn't start the microphone. Check the permission.") }
        }
    }

    /**
     * Normal mode streams every sound to Gemini. In wake-word mode ("Hey Mishti") sound is sent only while
     * someone is talking (plus a short lead-in), or for a while after Mishti herself spoke, so she can
     * stay on all day without using much data or battery.
     */
    private fun routeMic(chunk: ByteArray) {
        if (standby) return
        val c = client
        if (!(prefs.nameOnly || sleeping)) {
            c?.sendAudio(chunk)
            return
        }
        val lvl = audio.micLevel
        floor = if (lvl < floor) maxOf(lvl, 0.004f) else floor + (lvl - floor) * 0.002f
        val now = System.currentTimeMillis()
        val loud = lvl > maxOf(0.07f, floor * 3.5f)
        if (loud) gateOpenUntil = now + 1500

        if (c == null || !ready) {
            // Resting or still connecting: keep the last couple of seconds, and wake on real speech.
            synchronized(preRoll) {
                preRoll.addLast(chunk)
                while (preRoll.size > 60) preRoll.removeFirst()
            }
            if (c == null && _ui.value.asleep && loud) {
                loudRun++
                if (loudRun >= 2) wakeUp()
            } else if (!loud) {
                loudRun = 0
            }
            return
        }
        val chatting = now - lastSpoke < 12_000
        if (now < gateOpenUntil || chatting) {
            val lead = synchronized(preRoll) { preRoll.toList().also { preRoll.clear() } }
            lead.forEach { c.sendAudio(it) }
            c.sendAudio(chunk)
        } else {
            synchronized(preRoll) {
                preRoll.addLast(chunk)
                while (preRoll.size > 10) preRoll.removeFirst()
            }
        }
    }

    private fun stopTicker() {
        ticker?.cancel()
        ticker = null
        smooth = 0f
        level.floatValue = 0f
    }

    private fun startTicker() {
        if (ticker?.isActive == true) return
        ticker = scope.launch {
            while (isActive) {
                val speaking = audio.outstandingMs() > 0
                val raw = when {
                    speaking -> audio.outLevel
                    micStarted && !standby -> audio.micLevel * 0.8f
                    else -> 0f
                }
                smooth = if (raw > smooth) smooth + (raw - smooth) * 0.6f else smooth + (raw - smooth) * 0.14f
                level.floatValue = smooth
                val phase = when {
                    _ui.value.asleep -> Phase.Idle
                    !ready -> Phase.Connecting
                    speaking -> Phase.Speaking
                    else -> Phase.Listening
                }
                if (_ui.value.phase != phase) _ui.update { it.copy(phase = phase) }
                delay(33)
            }
        }
    }

    // ---------------------------------------------------------------- transcript

    private fun addOrAppend(fromUser: Boolean, text: String, forceNew: Boolean = false) {
        _ui.update { s ->
            val last = s.messages.lastOrNull()
            if (!forceNew && last != null && last.fromUser == fromUser) {
                s.copy(messages = s.messages.dropLast(1) + last.copy(text = last.text + text))
            } else {
                s.copy(messages = s.messages + ChatMessage(nextId++, fromUser, text))
            }
        }
    }

    private fun describe(name: String, args: JSONObject): String = when (name) {
        "call_contact" -> "Calling..."
        "send_sms" -> "Sending SMS..."
        "open_app" -> "Opening ${args.optString("app_name")}..."
        "open_url" -> "Opening link..."
        "play_youtube", "play_media" -> "Playing: ${args.optString("query")}"
        "read_screen" -> "Reading the screen..."
        "tap_text", "tap_index" -> "Tapping..."
        "type_text" -> "Typing..."
        "swipe" -> "Scrolling..."
        "quick_toggle" -> "Toggling ${args.optString("tile")}..."
        "torch" -> "Flashlight..."
        "set_volume" -> "Adjusting volume..."
        "set_alarm", "set_timer" -> "Setting alarm/timer..."
        else -> "Working on it..."
    }

    // ---------------------------------------------------------------- Gemini callbacks

    override fun onReady() {
        scope.launch {
            ready = true
            failures = 0
            lastProblem = null
            _ui.update { it.copy(phase = Phase.Listening) }
            val queued = synchronized(pendingText) { pendingText.toList().also { pendingText.clear() } }
            queued.forEach { client?.sendText(it) }
            if (prefs.nameOnly || sleeping) {
                val lead = synchronized(preRoll) { preRoll.toList().also { preRoll.clear() } }
                lead.forEach { client?.sendAudio(it) }
            }
            startMicIfNeeded()
        }
    }

    override fun onAudio(pcm: ByteArray) {
        lastSpoke = System.currentTimeMillis()
        if (sleeping && !prefs.nameOnly) sleeping = false
        if (!silentTurn && wantListening) audio.play(pcm)
    }

    override fun onInputText(text: String) {
        // Heard her user talk: this turn is a spoken one.
        silentTurn = false
        lastTalk = System.currentTimeMillis()
        addOrAppend(fromUser = true, text = text)
    }

    override fun onOutputText(text: String) = addOrAppend(fromUser = false, text = text)

    override fun onInterrupted() = audio.interrupt()

    override fun onToolCall(id: String, name: String, args: JSONObject) {
        scope.launch(Dispatchers.IO) {
            toolLock.withLock {
                _ui.update { it.copy(activity = describe(name, args)) }
                MishtiAccessibilityService.instance?.glow(true)
                val result = phone.run(name, args)
                client?.sendToolResponse(id, name, result)
            }
        }
    }

    override fun onTurnComplete() {
        lastTalk = System.currentTimeMillis()
        // The whole job is finished: let the edge glow fade away.
        if (!toolLock.isLocked) MishtiAccessibilityService.instance?.glow(false)
        _ui.update { if (it.activity != null) it.copy(activity = null) else it }
    }

    override fun onClosed(reason: String?) {
        scope.launch { handleDrop(reason?.takeIf { it.isNotBlank() }, quiet = true) }
    }

    override fun onError(message: String) {
        scope.launch { handleDrop(message, quiet = false) }
    }

    /** The connection ended. Retry quietly while Mishti is switched on. */
    private fun handleDrop(problem: String?, quiet: Boolean) {
        val wasReady = ready
        dropClient()
        problem?.let { lastProblem = it }

        val wanted = wantListening || synchronized(pendingText) { pendingText.isNotEmpty() }

        // Dropped before setup finished: probably a setup field this model does not take. Retry once, minimal.
        if (!wasReady && compat < 2 && wanted) {
            compat++
            connect()
            return
        }

        if (!wantListening) {
            // Text chat only: just let the connection go. The next message reconnects.
            stopTicker()
            _ui.update {
                it.copy(
                    phase = Phase.Idle,
                    activity = null,
                    error = if (!quiet || !wasReady) "Couldn't connect: ${lastProblem ?: "please try again"}" else it.error
                )
            }
            synchronized(pendingText) { pendingText.clear() }
            return
        }

        failures = if (wasReady) 1 else failures + 1
        if (failures > 6) {
            val msg = "Can't connect (${lastProblem ?: "unknown"}). Check your key, model and internet."
            stopListening()
            _ui.update { it.copy(error = msg) }
            return
        }
        _ui.update { it.copy(phase = Phase.Connecting, activity = null) }
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(minOf(400L * failures, 6000L))
            if (wantListening && client == null) connect()
        }
    }
}
