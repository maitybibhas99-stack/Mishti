package com.mishti.assistant

import org.json.JSONArray
import org.json.JSONObject

/** Function declarations sent to Gemini Live. Names must match PhoneActions.run(). */
object Tools {

    private class Param(val name: String, val schema: JSONObject, val required: Boolean)

    private fun s(name: String, desc: String, required: Boolean = true) =
        Param(name, JSONObject().put("type", "STRING").put("description", desc), required)

    private fun i(name: String, desc: String, required: Boolean = true) =
        Param(name, JSONObject().put("type", "INTEGER").put("description", desc), required)

    private fun b(name: String, desc: String, required: Boolean = true) =
        Param(name, JSONObject().put("type", "BOOLEAN").put("description", desc), required)

    private fun fn(name: String, desc: String, blocking: Boolean, vararg params: Param): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        // Wait for each answer before the model carries on, so steps never overlap.
        if (blocking) o.put("behavior", "BLOCKING")
        if (params.isNotEmpty()) {
            val props = JSONObject()
            params.forEach { props.put(it.name, it.schema) }
            val required = JSONArray()
            params.filter { it.required }.forEach { required.put(it.name) }
            o.put(
                "parameters",
                JSONObject().put("type", "OBJECT").put("properties", props).put("required", required)
            )
        }
        return o
    }

    private fun prop(type: String, desc: String) = JSONObject().put("type", type).put("description", desc)

    /** One step of do_steps: a tool name plus whatever arguments that tool takes. */
    private fun stepsParam(): Param {
        val props = JSONObject()
            .put("tool", prop("STRING", "Tool-er naam, jemon open_app, tap_text, type_text, press_key, swipe, wait, read_screen, play_youtube"))
            .put("app_name", prop("STRING", "open_app-er jonno"))
            .put("name_or_number", prop("STRING", "call_contact-er jonno"))
            .put("to", prop("STRING", "send_sms-er jonno"))
            .put("message", prop("STRING", "send_sms-er jonno"))
            .put("url", prop("STRING", "open_url-er jonno"))
            .put("query", prop("STRING", "play_youtube / play_media-er jonno"))
            .put("app", prop("STRING", "play_media-er jonno"))
            .put("text", prop("STRING", "tap_text / type_text-er jonno"))
            .put("index", prop("INTEGER", "tap_index-er jonno"))
            .put("key", prop("STRING", "press_key-er jonno"))
            .put("direction", prop("STRING", "swipe-er jonno"))
            .put("seconds", prop("INTEGER", "wait-er jonno"))
            .put("ms", prop("INTEGER", "wait-er jonno, millisecond"))
            .put("x", prop("INTEGER", "tap_at-er jonno, percent"))
            .put("y", prop("INTEGER", "tap_at-er jonno, percent"))
            .put("hold_ms", prop("INTEGER", "tap_at-er jonno"))
            .put("page", prop("STRING", "open_settings-er jonno"))
            .put("append", prop("BOOLEAN", "type_text-er jonno"))
            .put("package", prop("STRING", "install_app-er jonno"))
            .put("name", prop("STRING", "install_app-er jonno, app-er naam"))
            .put("max", prop("INTEGER", "scroll_find-er jonno"))
            .put("tap", prop("BOOLEAN", "scroll_find-er jonno"))
            .put("tile", prop("STRING", "quick_toggle-er jonno"))
            .put("on", prop("BOOLEAN", "quick_toggle / torch-er jonno"))
            .put("percent", prop("INTEGER", "set_volume-er jonno"))
        val item = JSONObject()
            .put("type", "OBJECT")
            .put("properties", props)
            .put("required", JSONArray().put("tool"))
        return Param(
            "steps",
            JSONObject()
                .put("type", "ARRAY")
                .put("description", "Ek-er por ek chalano step-er list (max 20). Kono step fail korle thame.")
                .put("items", item),
            true
        )
    }

    fun declarations(blocking: Boolean = true): JSONArray = JSONArray()
        // ---- calls, messages, apps
        .put(fn("call_contact", "Kono contact-ke naam diye ba number diye call kore.", blocking,
            s("name_or_number", "Contact-er naam (jemon Rahul) ba phone number")))
        .put(fn("send_sms", "Kono contact ba number-e SMS pathay.", blocking,
            s("to", "Contact-er naam ba phone number"),
            s("message", "SMS-er lekha, user ja bolechhe")))
        .put(fn("open_app", "Phone-e install kora kono app kholay.", blocking,
            s("app_name", "App-er naam, jemon WhatsApp, Camera, YouTube, Spotify")))
        .put(fn("open_url", "Kono website ba link browser/app-e kholay.", blocking,
            s("url", "Puro link, jemon https://www.google.com")))
        .put(fn("play_youtube", "YouTube-e video/gaan sathe sathe chalay (search kore prothom video chalu kore dey). Gaan ba video chaile eta-i shobcheye druto, ar kono tap lage na.", blocking,
            s("query", "Gaan ba video-r naam")))
        .put(fn("play_media", "Spotify ba YouTube Music-e gaan chalay. app na dile YouTube search khole.", blocking,
            s("query", "Gaan ba video-r naam"),
            s("app", "youtube, youtube_music ba spotify. Na dile youtube", required = false)))
        // ---- screen control (needs Accessibility)
        .put(fn("read_screen", "Ekhon screen-e ki ki dekha jachhe tar numbered list dey (text, tap kora jabe kina). Kono tap/type kora-r age eta chalao.", blocking))
        .put(fn("tap_text", "Screen-e dekha jachhe emon kono text ba button-e tap kore.", blocking,
            s("text", "Je lekha ba button-er naam-e tap korbe")))
        .put(fn("tap_index", "read_screen-er list-er i number-er element-e tap kore.", blocking,
            i("index", "read_screen-er i number")))
        .put(fn("tap_at", "Screen-er kono jaygay tap kore, jaygata percent-e (read_screen-er 'at' dekho). Label-hin icon, chhobi, game ba tap_text/tap_index kaj na korle eta. hold_ms 600+ dile chepe dhore (long press).", blocking,
            i("x", "bam theke 0-100 percent"),
            i("y", "upor theke 0-100 percent"),
            i("hold_ms", "koto ms chepe dhorbe, default 70", required = false)))
        .put(fn("type_text", "Text box-e lekha boshay, lomba lekha-o (HTML, chithi, note). index dile age oi box-e tap kore, na dile ja focus kora ache. append true hole age-er lekhar pore jore.", blocking,
            s("text", "Ja likhbe"),
            i("index", "read_screen-er textbox-er i number", required = false),
            b("append", "true hole age-er lekhar pore jore, noile bodle dey", required = false)))
        .put(fn("scroll_find", "Scroll kore kono text khuje bar kore, chaile tap-o kore. Lomba list-e (Settings, app list) dorkari option khujte.", blocking,
            s("text", "Ja khujbe"),
            s("direction", "down (default) ba up", required = false),
            i("max", "koto bar scroll, default 6", required = false),
            b("tap", "true hole peye tap korbe", required = false)))
        .put(fn("wait_for_text", "Screen-e kono text na ashar age porjonto opekkha kore (max 15 second). App load howar jonno wait-er cheye bhalo.", blocking,
            s("text", "Je text ashar opekkha"),
            i("seconds", "max koto second", required = false)))
        .put(fn("install_app", "Play Store theke app install kore (Install button porjonto nijei chape). Package name jana thakle dao, tahole thik app-i install hoy.", blocking,
            s("name", "App-er naam"),
            s("package", "Package name, jemon com.whatsapp. Na jana thakle dio na", required = false)))
        .put(fn("press_key", "Phone-er button chapay. key: back, home, recents, enter (search/submit), notifications, quick_settings, lock, screenshot.", blocking,
            s("key", "back, home, recents, enter, notifications, quick_settings, lock ba screenshot")))
        .put(fn("swipe", "Screen scroll ba swipe kore. direction: down (niche-r content dekhte), up (upore-r), left (porer page), right (ager page).", blocking,
            s("direction", "down, up, left ba right")))
        .put(fn("wait", "Kichu somoy opekkha kore, jemon app load hotey.", blocking,
            i("seconds", "1 theke 8 second", required = false),
            i("ms", "millisecond, 100 theke 8000", required = false)))
        .put(fn("quick_toggle", "Quick settings theke wifi, bluetooth, airplane, data, hotspot, rotate, dnd, location, battery_saver ba dark_mode on/off kore. Ek call-eii hoye jay.", blocking,
            s("tile", "wifi, bluetooth, airplane, data, hotspot, rotate, dnd, location, battery_saver ba dark_mode"),
            b("on", "true hole on, false hole off. Na dile ulte dey", required = false)))
        .put(fn("do_steps", "Onek step ek-shathe chalay, model-er sathe ghure ashte hoy na, tai druto. Je kaj-er step gulo age theke jana (jemon app kholo, search-e tap, likho, enter), shob ek call-e dao. Screen ki dekhabe na jana thakle eta noy, read_screen dao.", blocking,
            stepsParam()))
        .put(fn("read_notifications", "Ekhon phone-e thaka notification-er list dey (id, app, kon dhoroner, lekha). User jiggesh korle 'ki ki notification ache' ba kono message porte.", blocking,
            i("limit", "koto-ta, default 8", required = false),
            s("app", "optional: sudhu ei app-er (jemon WhatsApp)", required = false)))
        .put(fn("dismiss_notification", "Notification uriye dey. id dile oi-ta, 'junk' dile shob faltu, 'all' dile shob.", blocking,
            s("id", "read_notifications ba [NOTIFICATION]-er id, 'junk' ba 'all'")))
        .put(fn("reply_notification", "WhatsApp, Telegram, SMS-er notification theke sorasori reply pathay, app khulte hoy na. User ja bolechhe tai pathao.", blocking,
            s("id", "notification-er id"),
            s("text", "Reply-er lekha")))
        .put(fn("open_notification", "Kono notification-er app/chat khole dey.", blocking,
            s("id", "notification-er id")))
        .put(fn("research", "Web-e khuje uttor ber kore BACKGROUND-e. Sathe sathe return kore, tumi tomar kaj ba gollpo cholte paro; uttor eshe gele [TASK DONE] hishebe janabe, tokhon user-ke bolo. Boro ba somoy lage emon khoja (tulona, details, report) hole eta use koro. Choto prosno hole nijei search kore bolo.", blocking,
            s("question", "Ki khujbe, sompurno prosno")))
        .put(fn("queue_task", "Screen-er kono kaj (steps-er list) BACKGROUND queue-te rekhe sathe sathe return kore. Ager kaj sesh hole nijei chalabe, sesh hole [TASK DONE] hishebe janabe. User jokhon ekshathe onek kaj bole ba tumi ekta kaj korcho ar user ar ekta chay, tokhon eta use koro.", blocking,
            s("title", "Kaj-er choto naam"),
            stepsParam()))
        .put(fn("save_routine", "Ekta kaj-er step-er list nam diye mone rekhe dey, jate porer bar ek call-e (run_routine) hoye jay. Jokhon user ekta kaj bar bar kore ba shikhiye dey, tokhon save koro.", blocking,
            s("name", "Choto naam, jemon 'morning', 'movie night', 'wifi reset'"),
            stepsParam()))
        .put(fn("run_routine", "Age save kora routine ek call-e chalay. Shobcheye druto.", blocking,
            s("name", "Routine-er naam")))
        // ---- device
        .put(fn("open_settings", "Phone-er settings page ba panel kholay. page: wifi, internet, bluetooth, display, sound, volume, location, battery_saver, airplane, nfc, accessibility, apps, date, settings.", blocking,
            s("page", "wifi, internet, bluetooth, display, sound, volume, location, battery_saver, airplane, nfc, accessibility, apps, date ba settings")))
        .put(fn("torch", "Phone-er torch/flashlight on ba off kore.", blocking,
            b("on", "true hole on, false hole off")))
        .put(fn("set_volume", "Volume theek kore. stream: media (default), ring, alarm.", blocking,
            i("percent", "0 theke 100"),
            s("stream", "media, ring ba alarm", required = false)))
        .put(fn("set_alarm", "Alarm set kore.", blocking,
            i("hour", "24 ghontar hishebe ghonta, 0-23"),
            i("minute", "minute, 0-59"),
            s("label", "Alarm-er naam", required = false)))
        .put(fn("set_timer", "Timer set kore.", blocking,
            i("seconds", "koto second-er timer"),
            s("label", "Timer-er naam", required = false)))
        .put(fn("device_info", "Ekhonkar somoy, tarikh, battery koto percent ar charge hochhe kina bole.", blocking))
        // ---- memory and session
        .put(fn("remember", "User-er kono dorkari kotha (naam, pochhondo, ma-er number-er naam ityadi) mone rakhe, porer bar-o mone thakbe.", blocking,
            s("note", "Ek line-e ja mone rakhbe")))
        .put(fn("forget", "Mone rakha kono kotha mushe dey.", blocking,
            s("keyword", "Je note-e ei shobdo ache seta mushbe")))
        .put(fn("standby", "Mic bondho kore chup kore thake. User bolle 'chup thako', 'standby' ba onno app-e gaan/video-r jonno mic bondho korte chaile. User notification-er Listen button tipe abar dakbe.", blocking))
        .put(fn("sleep", "Mishti-ke bishram-e pathay: internet bondho, kintu 'Hey Mishti' bolle abar nijei jege uthbe, app-e giye kichu korte hobe na. User jokhon bole 'Mishti ekhon tumi rakhte paro', 'thak', 'bishram nao', 'ghumao', 'ar lagbe na', 'thanks bye' ityadi. Age ekta chhoto mishti bidai bolo, tarpor eta chalao, tarpor ar kichu bolbe na.", blocking))
        .put(fn("end_session", "Mishti-ke EKDOM off kore (mic-o bondho, 'Hey Mishti' bolleo jagbe na). Shudhu tokhon, jokhon user sposhto bole 'ekdom bondho koro', 'power off', 'puro off kore dao'. Age bidai bolo.", blocking))
}
