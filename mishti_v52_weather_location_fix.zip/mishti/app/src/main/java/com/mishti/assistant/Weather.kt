package com.mishti.assistant

import android.content.Context
import org.json.JSONObject
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** Live current conditions and forecasts from Open-Meteo. No API key is required. */
object Weather {
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(18, TimeUnit.SECONDS)
        .build()

    fun current(ctx: Context, place: String): JSONObject {
        return try {
        val query = place.trim()
        val coordinates: Pair<Double, Double>
        val label: String
        if (query.isNotEmpty()) {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val geo = get("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=en&format=json")
            val first = geo.optJSONArray("results")?.optJSONObject(0)
                ?: return error("I couldn't find $query. Please give me a nearby city or town name.")
            coordinates = first.optDouble("latitude") to first.optDouble("longitude")
            label = listOf(first.optString("name"), first.optString("admin1"), first.optString("country"))
                .filter { it.isNotBlank() }.distinct().joinToString(", ")
        } else {
            val loc = Locator.current(ctx)
            if (loc.optString("status") != "ok") {
                return error("I need your phone's location to get local weather. ${loc.optString("message", "Please enable location permission and Location services.")}")
            }
            coordinates = loc.optDouble("latitude") to loc.optDouble("longitude")
            label = loc.optString("address").ifBlank { "Your current location" }
        }

        val url = "https://api.open-meteo.com/v1/forecast?latitude=${coordinates.first}&longitude=${coordinates.second}" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset" +
            "&forecast_days=2&timezone=auto"
        val root = get(url)
        val now = root.optJSONObject("current") ?: return error("The weather service returned no current conditions.")
        val daily = root.optJSONObject("daily")
        val code = now.optInt("weather_code", -1)
        val out = JSONObject()
            .put("status", "ok")
            .put("location", label)
            .put("temperature_c", now.optDouble("temperature_2m"))
            .put("feels_like_c", now.optDouble("apparent_temperature"))
            .put("condition", condition(code))
            .put("humidity_percent", now.optInt("relative_humidity_2m"))
            .put("precipitation_mm", now.optDouble("precipitation"))
            .put("wind_speed_kmh", now.optDouble("wind_speed_10m"))
            .put("timezone", root.optString("timezone"))
        if ((daily?.optJSONArray("time")?.length() ?: 0) > 0) {
            out.put("today_high_c", daily.optJSONArray("temperature_2m_max")?.optDouble(0))
            out.put("today_low_c", daily.optJSONArray("temperature_2m_min")?.optDouble(0))
            out.put("rain_chance_percent", daily.optJSONArray("precipitation_probability_max")?.optInt(0))
            out.put("sunrise", daily.optJSONArray("sunrise")?.optString(0))
            out.put("sunset", daily.optJSONArray("sunset")?.optString(0))
            if ((daily.optJSONArray("time")?.length() ?: 0) > 1) {
                out.put("tomorrow_date", daily.optJSONArray("time")?.optString(1))
                out.put("tomorrow_high_c", daily.optJSONArray("temperature_2m_max")?.optDouble(1))
                out.put("tomorrow_low_c", daily.optJSONArray("temperature_2m_min")?.optDouble(1))
                out.put("tomorrow_rain_chance_percent", daily.optJSONArray("precipitation_probability_max")?.optInt(1))
            }
        }
        out
        } catch (e: Exception) {
            error("Weather lookup failed: ${e.message ?: "network unavailable"}")
        }
    }

    private fun get(url: String): JSONObject {
        val request = Request.Builder().url(url).header("Accept", "application/json").build()
        http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}")
            return JSONObject(body)
        }
    }

    private fun condition(code: Int): String = when (code) {
        0 -> "Clear sky"
        1 -> "Mainly clear"
        2 -> "Partly cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        51, 53, 55 -> "Drizzle"
        56, 57 -> "Freezing drizzle"
        61, 63, 65 -> "Rain"
        66, 67 -> "Freezing rain"
        71, 73, 75, 77 -> "Snow"
        80, 81, 82 -> "Rain showers"
        85, 86 -> "Snow showers"
        95, 96, 99 -> "Thunderstorm"
        else -> "Weather conditions unavailable"
    }

    private fun error(message: String) = JSONObject().put("status", "error").put("message", message)
}
