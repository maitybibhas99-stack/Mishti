package com.mishti.assistant

import org.json.JSONArray
import org.json.JSONObject

/** Function declarations sent to Gemini Live. Names must match PhoneActions.run(). */
object Tools {

    private class Param(val name: String, val schema: JSONObject, val required: Boolean)

    private fun s(name: String, desc: String, required: Boolean = true) =
        Param(name, JSONObject().put("type", "STRING").put("description", desc), required)

    private fun i(name: String, desc: String, required: Boolean = true) =
        Param(name, JSONObject().put("type", "INTEGER").put("description", desc), required)

    private fun b(name: String, desc: String, required: Boolean = true) =
        Param(name, JSONObject().put("type", "BOOLEAN").put("description", desc), required)

    private fun fn(name: String, desc: String, vararg params: Param): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (params.isNotEmpty()) {
            val props = JSONObject()
            params.forEach { props.put(it.name, it.schema) }
            val required = JSONArray()
            params.filter { it.required }.forEach { required.put(it.name) }
            o.put(
                "parameters",
                JSONObject().put("type", "OBJECT").put("properties", props).put("required", required)
            )
        }
        return o
    }

    fun declarations(): JSONArray = JSONArray()
        // ---- calls, messages, apps
        .put(fn("call_contact", "Kono contact-ke naam diye ba number diye call kore.",
            s("name_or_number", "Contact-er naam (jemon Rahul) ba phone number")))
        .put(fn("send_sms", "Kono contact ba number-e SMS pathay.",
            s("to", "Contact-er naam ba phone number"),
            s("message", "SMS-er lekha, user ja bolechhe")))
        .put(fn("open_app", "Phone-e install kora kono app kholay.",
            s("app_name", "App-er naam, jemon WhatsApp, Camera, YouTube, Spotify")))
        .put(fn("open_url", "Kono website ba link browser/app-e kholay.",
            s("url", "Puro link, jemon https://www.google.com")))
        .put(fn("play_media", "Gaan ba video khuje chalay. app na dile YouTube-e search khule, tarpor read_screen diye prothom result-e tap korte hobe. spotify ba youtube_music dile sorasori gaan chalu hoy.",
            s("query", "Gaan ba video-r naam"),
            s("app", "youtube, youtube_music ba spotify. Na dile youtube", required = false)))
        // ---- screen control (needs Accessibility)
        .put(fn("read_screen", "Ekhon screen-e ki ki dekha jachhe tar numbered list dey (text, tap kora jabe kina). Kono tap/type kora-r age eta chalao."))
        .put(fn("tap_text", "Screen-e dekha jachhe emon kono text ba button-e tap kore.",
            s("text", "Je lekha ba button-er naam-e tap korbe")))
        .put(fn("tap_index", "read_screen-er list-er i number-er element-e tap kore.",
            i("index", "read_screen-er i number")))
        .put(fn("type_text", "Ekhon focus kora text box-e lekha boshay (search box-o).",
            s("text", "Ja likhbe")))
        .put(fn("press_key", "Phone-er button chapay. key: back, home, recents, enter (search/submit), notifications, quick_settings, lock, screenshot.",
            s("key", "back, home, recents, enter, notifications, quick_settings, lock ba screenshot")))
        .put(fn("swipe", "Screen scroll ba swipe kore. direction: down (niche-r content dekhte), up (upore-r), left (porer page), right (ager page).",
            s("direction", "down, up, left ba right")))
        .put(fn("wait", "Kichu second opekkha kore, jemon app load hotey.",
            i("seconds", "1 theke 8 second")))
        // ---- device
        .put(fn("open_settings", "Phone-er settings page ba panel kholay. page: wifi, internet, bluetooth, display, sound, volume, location, battery_saver, airplane, nfc, accessibility, apps, date, settings.",
            s("page", "wifi, internet, bluetooth, display, sound, volume, location, battery_saver, airplane, nfc, accessibility, apps, date ba settings")))
        .put(fn("torch", "Phone-er torch/flashlight on ba off kore.",
            b("on", "true hole on, false hole off")))
        .put(fn("set_volume", "Volume theek kore. stream: media (default), ring, alarm.",
            i("percent", "0 theke 100"),
            s("stream", "media, ring ba alarm", required = false)))
        .put(fn("set_alarm", "Alarm set kore.",
            i("hour", "24 ghontar hishebe ghonta, 0-23"),
            i("minute", "minute, 0-59"),
            s("label", "Alarm-er naam", required = false)))
        .put(fn("set_timer", "Timer set kore.",
            i("seconds", "koto second-er timer"),
            s("label", "Timer-er naam", required = false)))
        .put(fn("device_info", "Ekhonkar somoy, tarikh, battery koto percent ar charge hochhe kina bole."))
        // ---- memory and session
        .put(fn("remember", "User-er kono dorkari kotha (naam, pochhondo, ma-er number-er naam ityadi) mone rakhe, porer bar-o mone thakbe.",
            s("note", "Ek line-e ja mone rakhbe")))
        .put(fn("forget", "Mone rakha kono kotha mushe dey.",
            s("keyword", "Je note-e ei shobdo ache seta mushbe")))
        .put(fn("standby", "Gaan/video chalar mato shomoy mic bondho kore chup kore thake, jate gaan-er sathe tomar mic-e gondogol na hoy. User notification-er Listen button tipe abar dakbe."))
        .put(fn("end_session", "Voice session sompurno bondho kore, user jokhon bole 'ekhon thamo' ba 'bondho koro'."))
}
