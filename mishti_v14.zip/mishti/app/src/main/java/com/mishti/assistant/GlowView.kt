package com.mishti.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min
import kotlin.math.sin

/**
 * A soft, breathing, colour-shifting glow around the edges of the whole screen.
 * Shown by the accessibility service while Mishti is busy with a task; it fades out when she is done.
 */
class GlowView(context: Context) : View(context) {

    private val palette = intArrayOf(
        Color.parseColor("#FF3D8B"),
        Color.parseColor("#A16BFF"),
        Color.parseColor("#5B7BFF"),
        Color.parseColor("#39F2E0"),
        Color.parseColor("#FFB86B"),
    )

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var fade = 0f

    private val loop = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 4200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }
    private var fader: ValueAnimator? = null

    fun start() {
        if (!loop.isStarted) loop.start()
    }

    fun fadeTo(target: Float, onDone: (() -> Unit)? = null) {
        fader?.cancel()
        fader = ValueAnimator.ofFloat(fade, target).apply {
            duration = if (target > fade) 350 else 600
            addUpdateListener {
                fade = it.animatedValue as Float
                invalidate()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false

                override fun onAnimationCancel(animation: android.animation.Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: android.animation.Animator) {
                    if (!cancelled && target == 0f) {
                        loop.cancel()
                        onDone?.invoke()
                    }
                }
            })
            start()
        }
    }

    private val cornerPx = 44f * context.resources.displayMetrics.density
    private val rect = RectF()
    private val matrix = Matrix()
    private var sweep: SweepGradient? = null

    init {
        paint.style = Paint.Style.STROKE
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val colors = IntArray(palette.size + 1) { palette[it % palette.size] }
        sweep = SweepGradient(w / 2f, h / 2f, colors, null)
    }

    override fun onDraw(canvas: Canvas) {
        val shader = sweep ?: return
        if (fade <= 0f) return
        val w = width.toFloat()
        val h = height.toFloat()
        val breath = 0.5f + 0.5f * sin(phase * 2f * Math.PI.toFloat())

        // A thin, soft band hugging the screen edge, with the rounded corners of the display.
        val depth = min(w, h) * (0.030f + 0.018f * breath)
        val layers = 10
        val step = depth / layers
        val peak = fade * (0.22f + 0.16f * breath)

        matrix.setRotate(phase * 360f, w / 2f, h / 2f)
        shader.setLocalMatrix(matrix)
        paint.shader = shader
        paint.strokeWidth = step + 1f

        for (i in 0 until layers) {
            val t = 1f - i / layers.toFloat()
            paint.alpha = (255f * peak * t * t).toInt().coerceIn(0, 255)
            val inset = step * (i + 0.5f)
            rect.set(inset, inset, w - inset, h - inset)
            val r = (cornerPx - inset).coerceAtLeast(6f)
            canvas.drawRoundRect(rect, r, r, paint)
        }
        paint.shader = null
    }
}
