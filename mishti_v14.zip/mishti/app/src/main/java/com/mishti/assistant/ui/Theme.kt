package com.mishti.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.random.Random

object MishtiColors {
    val Bg = Color(0xFF0B0B10)
    val Surface = Color(0xFF1A1A22)
    val SurfaceHigh = Color(0xFF2E2E3A)
    val Coral = Color(0xFFD97757)
    val Text = Color(0xFFF2F0EB)
    val TextDim = Color(0xFF9A9892)
    val Danger = Color(0xFFE5484D)
}

@Composable
fun MishtiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = MishtiColors.Bg,
            surface = MishtiColors.Surface,
            primary = MishtiColors.Coral,
            onBackground = MishtiColors.Text,
            onSurface = MishtiColors.Text,
        ),
        content = content
    )
}

/**
 * Deep night background with a few faint coloured glows and a fine film grain,
 * so flat black becomes something with depth and texture.
 */
fun Modifier.auroraBackground(): Modifier = this
    .drawBehind {
        drawRect(MishtiColors.Bg)
        val w = size.width
        val h = size.height
        fun glow(color: Color, cx: Float, cy: Float, r: Float, a: Float) {
            drawCircle(
                brush = Brush.radialGradient(
                    0f to color.copy(alpha = a),
                    1f to Color.Transparent,
                    center = Offset(cx, cy),
                    radius = r
                ),
                radius = r,
                center = Offset(cx, cy)
            )
        }
        glow(Color(0xFFA16BFF), w * 0.10f, h * 0.02f, w * 0.95f, 0.17f)
        glow(Color(0xFF39F2E0), w * 1.00f, h * 0.38f, w * 0.75f, 0.09f)
        glow(Color(0xFFFF3D8B), w * 0.25f, h * 1.02f, w * 1.00f, 0.10f)
        val rnd = Random(11)
        repeat(900) {
            drawCircle(
                color = Color.White.copy(alpha = 0.025f + 0.035f * rnd.nextFloat()),
                radius = 0.7f,
                center = Offset(rnd.nextFloat() * w, rnd.nextFloat() * h)
            )
        }
    }
