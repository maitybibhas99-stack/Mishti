package com.mishti.assistant.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mishti.assistant.ChatMessage
import com.mishti.assistant.Phase
import com.mishti.assistant.Ui
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun HomeScreen(
    ui: Ui,
    level: () -> Float,
    onSend: (String) -> Unit,
    onVoice: () -> Unit,
    onOff: () -> Unit,
    onNewChat: () -> Unit,
    onSettings: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .auroraBackground()
            .systemBarsPadding()
            .imePadding()
    ) {
        TopBar(onNewChat = onNewChat, showNewChat = ui.messages.isNotEmpty(), onSettings = onSettings)

        if (ui.listening) ListeningBar(ui = ui, level = level, onOpen = onVoice, onOff = onOff)

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (ui.messages.isEmpty()) {
                EmptyState(ui = ui, level = level, onSend = onSend)
            } else {
                ChatList(ui.messages)
            }
        }

        if (ui.error != null) {
            Text(
                ui.error,
                color = MishtiColors.Coral,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
            )
        }

        InputBar(onSend = onSend, onVoice = onVoice)
    }
}

@Composable
private fun TopBar(onNewChat: () -> Unit, showNewChat: Boolean, onSettings: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            "Mishti",
            color = MishtiColors.Text,
            fontFamily = FontFamily.Serif,
            fontSize = 22.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (showNewChat) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .clickable(onClick = onNewChat),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Notun chat", tint = MishtiColors.TextDim)
                }
            }
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onSettings),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = MishtiColors.TextDim)
            }
        }
    }
}

@Composable
private fun ListeningBar(ui: Ui, level: () -> Float, onOpen: () -> Unit, onOff: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(MishtiColors.Surface.copy(alpha = 0.9f))
            .border(1.dp, Color(0x2EFFFFFF), RoundedCornerShape(24.dp))
            .clickable(onClick = onOpen)
            .padding(start = 8.dp, end = 14.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Orb(Modifier.size(40.dp), level = level, energy = if (ui.muted || ui.asleep) 0.2f else 0.7f, rays = false)
        Spacer(Modifier.size(8.dp))
        Text(
            when {
                ui.muted -> "Standby: mic bondho"
                ui.asleep -> "Ghumiye achhi, 'Hey Mishti' bolo"
                else -> "Mishti shunchhe"
            },
            color = MishtiColors.Text,
            fontSize = 14.sp,
            modifier = Modifier.weight(1f)
        )
        Text(
            "Off",
            color = MishtiColors.Coral,
            fontSize = 14.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .clickable(onClick = onOff)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun EmptyState(ui: Ui, level: () -> Float, onSend: (String) -> Unit) {
    val ideas = listOf(
        "YouTube-e ekta gaan chalao",
        "Torch jalao",
        "WiFi off koro",
        "Ekta alarm set koro",
    )
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Orb(
            Modifier.size(190.dp),
            level = level,
            energy = if (ui.phase == Phase.Speaking) 1f else 0.5f,
            rays = true
        )
        Spacer(Modifier.height(6.dp))
        Text(
            greeting(),
            color = MishtiColors.Text,
            fontFamily = FontFamily.Serif,
            fontSize = 28.sp
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Likhe bolo, ba niche-r button-e voice chalu koro",
            color = MishtiColors.TextDim,
            fontSize = 14.sp
        )
        Spacer(Modifier.height(22.dp))
        ideas.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                row.forEach { idea ->
                    Text(
                        idea,
                        color = MishtiColors.Text,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(MishtiColors.Surface)
                            .clickable { onSend(idea) }
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                    )
                }
            }
        }
    }
}

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when (h) {
        in 5..11 -> "Shubho sokal"
        in 12..16 -> "Shubho dupur"
        in 17..20 -> "Shubho sondhya"
        else -> "Raat jege achho?"
    }
}

@Composable
fun Starburst(modifier: Modifier = Modifier, spinning: Boolean = false) {
    val t = rememberInfiniteTransition(label = "spin")
    val angle by t.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart),
        label = "angle"
    )
    Canvas(modifier.graphicsLayer { rotationZ = if (spinning) angle else 0f }) {
        val c = Offset(size.width / 2, size.height / 2)
        val r1 = size.minDimension * 0.14f
        val r2 = size.minDimension * 0.5f
        for (k in 0 until 12) {
            val a = Math.toRadians(k * 30.0 - 90.0)
            val long = if (k % 2 == 0) r2 else r2 * 0.82f
            drawLine(
                MishtiColors.Coral,
                Offset(c.x + (r1 * cos(a)).toFloat(), c.y + (r1 * sin(a)).toFloat()),
                Offset(c.x + (long * cos(a)).toFloat(), c.y + (long * sin(a)).toFloat()),
                strokeWidth = size.minDimension * 0.07f,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
private fun ChatList(messages: List<ChatMessage>) {
    val state = rememberLazyListState()
    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
        if (messages.isNotEmpty()) state.animateScrollToItem(messages.lastIndex)
    }
    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        items(messages, key = { it.id }) { m ->
            if (m.fromUser) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Text(
                        m.text,
                        color = MishtiColors.Text,
                        fontSize = 16.sp,
                        modifier = Modifier
                            .widthIn(max = 300.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(MishtiColors.Surface.copy(alpha = 0.9f))
                            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(20.dp))
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            } else {
                Text(
                    m.text,
                    color = MishtiColors.Text,
                    fontFamily = FontFamily.Serif,
                    fontSize = 17.sp,
                    lineHeight = 25.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun InputBar(onSend: (String) -> Unit, onVoice: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val hasText = text.isNotBlank()

    fun submit() {
        if (text.isBlank()) return
        onSend(text)
        text = ""
    }

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(MishtiColors.Surface.copy(alpha = 0.85f))
            .border(1.dp, Color(0x2EFFFFFF), RoundedCornerShape(32.dp))
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f)) {
            if (text.isEmpty()) {
                Text("Mishti-ke bolo", color = MishtiColors.TextDim, fontSize = 17.sp)
            }
            BasicTextField(
                value = text,
                onValueChange = { text = it },
                textStyle = TextStyle(color = MishtiColors.Text, fontSize = 17.sp),
                cursorBrush = SolidColor(MishtiColors.Coral),
                maxLines = 5,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { submit() }),
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.size(8.dp))
        Box(
            Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(Color.White)
                .clickable { if (hasText) submit() else onVoice() },
            contentAlignment = Alignment.Center
        ) {
            if (hasText) {
                Icon(Icons.Default.ArrowUpward, contentDescription = "Pathao", tint = Color.Black)
            } else {
                MiniWaveIcon()
            }
        }
    }
}

@Composable
private fun MiniWaveIcon() {
    Canvas(Modifier.size(24.dp)) {
        val heights = floatArrayOf(0.25f, 0.55f, 0.95f, 0.55f, 0.25f)
        val gap = size.width / 5f
        heights.forEachIndexed { i, h ->
            val x = gap * (i + 0.5f)
            val half = size.height * h / 2f
            drawLine(
                Color.Black,
                Offset(x, size.height / 2 - half),
                Offset(x, size.height / 2 + half),
                strokeWidth = size.width * 0.1f,
                cap = StrokeCap.Round
            )
        }
    }
}
