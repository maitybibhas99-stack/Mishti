package com.mishti.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Lets Mishti see the screen and tap / type / scroll for the user.
 * Turned on by the user in Settings > Accessibility. Nothing here runs by itself:
 * every action is triggered by a tool call from the voice session.
 */
class MishtiAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MishtiAccessibilityService? = null
            private set

        private const val MAX_ELEMENTS = 90
    }

    private class El(
        val text: String,
        val desc: String,
        val cx: Int,
        val cy: Int,
        val clickable: Boolean,
        val editable: Boolean,
        val scrollable: Boolean,
        val id: String = "",
        /** -1 = not a switch/checkbox, 0 = off, 1 = on */
        val checked: Int = -1,
    )

    @Volatile
    private var last: List<El> = emptyList()

    private val main = Handler(Looper.getMainLooper())
    private var glowView: GlowView? = null
    private val glowTimeout = Runnable { hideGlowNow() }

    /** Breathing glow around the screen edges while Mishti works. */
    fun glow(on: Boolean) {
        main.post { if (on) showGlowNow() else hideGlowNow() }
    }

    private fun showGlowNow() {
        main.removeCallbacks(glowTimeout)
        main.postDelayed(glowTimeout, 90_000)
        glowView?.let {
            it.fadeTo(1f)
            return
        }
        val v = GlowView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
            glowView = v
            v.start()
            v.fadeTo(1f)
        } catch (_: Exception) {
        }
    }

    private fun hideGlowNow() {
        main.removeCallbacks(glowTimeout)
        val v = glowView ?: return
        v.fadeTo(0f) {
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)
            } catch (_: Exception) {
            }
            if (glowView === v) glowView = null
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        main.post { hideGlowNow() }
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    // ------------------------------------------------------------------ read

    fun snapshot(): JSONObject {
        var root = rootInActiveWindow
        var tries = 0
        while (root == null && tries < 4) {
            Thread.sleep(200)
            root = rootInActiveWindow
            tries++
        }
        if (root == null) return fail("Screen padha jachhe na. Screen lock ba app-ta block korche.")
        val out = ArrayList<El>()
        collect(root, out, 0, true)
        if (out.size <= 1) {
            out.clear()
            collect(root, out, 0, false)
        }
        if (out.size <= 1) {
            // The active window may be a keyboard or overlay: look through every window.
            for (w in windows) {
                val r = w.root ?: continue
                collect(r, out, 0, false)
                if (out.size > 1) break
            }
        }
        last = out

        val m = resources.displayMetrics
        val arr = JSONArray()
        out.forEachIndexed { index, e ->
            val o = JSONObject().put("i", index)
            if (e.text.isNotEmpty()) o.put("text", e.text)
            if (e.desc.isNotEmpty()) o.put("desc", e.desc)
            if (e.id.isNotEmpty()) o.put("id", e.id)
            if (e.clickable) o.put("clickable", true)
            if (e.editable) o.put("textbox", true)
            if (e.scrollable) o.put("scrollable", true)
            if (e.checked >= 0) o.put("on", e.checked == 1)
            // position as percent of the screen, usable with tap_at
            o.put("at", "${e.cx * 100 / m.widthPixels},${e.cy * 100 / m.heightPixels}")
            arr.put(o)
        }
        return JSONObject()
            .put("status", "ok")
            .put("app", root.packageName?.toString().orEmpty())
            .put("elements", arr)
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<El>, depth: Int, strict: Boolean) {
        if (depth > 35 || out.size >= MAX_ELEMENTS) return
        if (strict && !node.isVisibleToUser) return

        val text = node.text?.toString().orEmpty().trim().take(80)
        val desc = node.contentDescription?.toString().orEmpty().trim().take(80)
        val hint = if (Build.VERSION.SDK_INT >= 26) node.hintText?.toString().orEmpty().trim().take(80) else ""
        val editable = node.isEditable
        val idName = node.viewIdResourceName?.substringAfter(":id/").orEmpty().take(40)
        // Icons with no label still matter: keep clickable ones that have an id, and switches.
        val unlabeled = text.isEmpty() && desc.isEmpty() && !editable &&
            ((node.isClickable && idName.isNotEmpty()) || node.isCheckable)

        if (text.isNotEmpty() || desc.isNotEmpty() || editable || unlabeled) {
            val r = Rect()
            node.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) {
                out.add(
                    El(
                        text = if (text.isEmpty() && editable) hint else text,
                        desc = desc,
                        cx = r.centerX(),
                        cy = r.centerY(),
                        clickable = node.isClickable,
                        editable = editable,
                        scrollable = node.isScrollable,
                        id = idName,
                        checked = if (node.isCheckable) (if (node.isChecked) 1 else 0) else -1
                    )
                )
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collect(child, out, depth + 1, strict)
            if (out.size >= MAX_ELEMENTS) return
        }
    }

    /** Taps (or presses and holds) a spot given as percent of the screen. For things with no label. */
    fun tapPercent(xp: Int, yp: Int, holdMs: Long): JSONObject {
        val m = resources.displayMetrics
        val x = m.widthPixels * xp.coerceIn(0, 100) / 100f
        val y = m.heightPixels * yp.coerceIn(0, 100) / 100f
        val path = Path().apply { moveTo(x, y) }
        return if (dispatch(path, holdMs.coerceIn(50L, 2000L))) {
            Thread.sleep(150)
            ok("Screen-er $xp%,$yp% jaygay tap kora hoyeche.")
        } else {
            fail("Tap hoyni.")
        }
    }

    // ------------------------------------------------------------------ act

    fun tapText(query: String): JSONObject {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return fail("Kon text-e tap korbo?")
        var hit: El? = null
        // Look at the live screen; if the text is not there yet, give the app a moment and look once more.
        for (attempt in 0 until 2) {
            val snap = snapshot()
            if (snap.optString("status") != "ok") return snap
            hit = last.firstOrNull { it.text.lowercase() == q || it.desc.lowercase() == q }
                ?: last.firstOrNull { it.text.lowercase().contains(q) || it.desc.lowercase().contains(q) }
            if (hit != null) break
            if (attempt == 0) Thread.sleep(450)
        }
        val found = hit ?: return fail("'$query' screen-e paini. read_screen chalie dekho ki ache.")
        return if (clickAt(found.cx, found.cy)) ok("'$query'-e tap kora hoyeche.")
        else fail("Tap hoyni.")
    }

    fun tapIndex(index: Int): JSONObject {
        val e = last.getOrNull(index)
            ?: return fail("$index number element nei. Age read_screen chalao.")
        return if (clickAt(e.cx, e.cy)) ok("$index number-e tap kora hoyeche.")
        else fail("Tap hoyni.")
    }

    /**
     * Taps the way a user would: first a real click on the view under that point (or the nearest
     * clickable parent), which works even when the app ignores raw touches; if that is not possible,
     * a touch gesture at the point.
     */
    private fun clickAt(x: Int, y: Int): Boolean {
        val root = rootInActiveWindow
        if (root != null) {
            var node: AccessibilityNodeInfo? = deepestAt(root, x, y, 0)
            var hops = 0
            while (node != null && hops < 7) {
                if (node.isClickable && node.isEnabled && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    Thread.sleep(60)
                    return true
                }
                node = node.parent
                hops++
            }
        }
        val ok = gestureTap(x, y)
        if (ok) Thread.sleep(60)
        return ok
    }

    private fun deepestAt(node: AccessibilityNodeInfo, x: Int, y: Int, depth: Int): AccessibilityNodeInfo? {
        if (depth > 40 || !node.isVisibleToUser) return null
        val r = Rect()
        node.getBoundsInScreen(r)
        if (!r.contains(x, y)) return null
        for (i in node.childCount - 1 downTo 0) {
            val child = node.getChild(i) ?: continue
            deepestAt(child, x, y, depth + 1)?.let { return it }
        }
        return node
    }

    private fun biggestScrollable(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 30 || !node.isVisibleToUser) return null
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0L
        if (node.isScrollable) {
            val r = Rect()
            node.getBoundsInScreen(r)
            best = node
            bestArea = r.width().toLong() * r.height()
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val cand = biggestScrollable(child, depth + 1) ?: continue
            val r = Rect()
            cand.getBoundsInScreen(r)
            val area = r.width().toLong() * r.height()
            if (area > bestArea) {
                best = cand
                bestArea = area
            }
        }
        return best
    }

    /** Opens quick settings and taps one tile (wifi, bluetooth...). want = null toggles whatever it is now. */
    fun quickToggle(tile: String, want: Boolean?): JSONObject {
        val t = tile.trim().lowercase()
        val names = when (t) {
            "wifi", "wi-fi", "internet" -> listOf("internet", "wi-fi", "wifi")
            "bluetooth" -> listOf("bluetooth")
            "airplane", "flight", "flight_mode" -> listOf("airplane", "flight mode", "aeroplane")
            "flashlight", "torch" -> listOf("flashlight", "torch")
            "data", "mobile_data" -> listOf("mobile data", "data")
            "hotspot" -> listOf("hotspot")
            "rotate", "auto_rotate" -> listOf("auto-rotate", "auto rotate", "rotate")
            "dnd", "silent" -> listOf("do not disturb", "dnd")
            "location" -> listOf("location")
            "battery_saver" -> listOf("battery saver", "power saving")
            "dark_mode" -> listOf("dark theme", "dark mode")
            else -> listOf(t)
        }
        if (!performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)) return fail("Quick settings khola gelo na.")
        Thread.sleep(420)

        var found: El? = null
        for (attempt in 0 until 3) {
            snapshot()
            found = last.firstOrNull { e ->
                names.any { n -> e.text.lowercase().contains(n) || e.desc.lowercase().contains(n) }
            }
            if (found != null) break
            Thread.sleep(200)
        }
        val tileEl = found
        if (tileEl == null) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            return fail("'$tile' tile quick settings-e paini. open_settings diye try koro.")
        }

        val label = (tileEl.desc + " , " + tileEl.text).lowercase()
        val isOn = when {
            Regex("(^|[ ,])on($|[ ,])").containsMatchIn(label) -> true
            Regex("(^|[ ,])off($|[ ,])").containsMatchIn(label) -> false
            else -> null
        }
        if (want != null && isOn == want) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            return ok("$tile already ${if (want) "on" else "off"} chhilo.")
        }
        val clicked = clickAt(tileEl.cx, tileEl.cy)
        Thread.sleep(250)
        // On some phones tapping the tile opens a small panel instead; leave it open so read_screen can see it.
        val after = snapshot()
        val stillQuick = after.optString("app").contains("systemui")
        if (stillQuick) performGlobalAction(GLOBAL_ACTION_BACK)
        return if (clicked) {
            ok("$tile tile-e tap kora hoyeche. Jodi screen-e notun panel/dialog thake, read_screen diye toggle-e tap koro.")
        } else {
            fail("Tile-e tap hoyni.")
        }
    }

    fun typeText(text: String, index: Int = -1, append: Boolean = false): JSONObject {
        if (index >= 0) {
            val e = last.getOrNull(index) ?: return fail("$index number element nei. Age read_screen chalao.")
            clickAt(e.cx, e.cy)
            Thread.sleep(300)
        }
        val root = rootInActiveWindow ?: return fail("Screen padha jachhe na.")
        val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
            ?: findEditable(root, 0)
            ?: return fail("Kono text box paini. Age text box-e tap koro.")
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        var finalText = text
        if (append) {
            val showingHint = Build.VERSION.SDK_INT >= 26 && target.isShowingHintText
            val current = if (showingHint) "" else target.text?.toString().orEmpty()
            finalText = current + text
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, finalText)
        }
        return if (target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            ok("Lekha hoyeche (${text.length} akkhor).")
        } else {
            fail("Ei text box-e lekha gelo na.")
        }
    }

    private fun matches(e: El, q: String) =
        e.text.lowercase().contains(q) || e.desc.lowercase().contains(q)

    /** Scrolls until some text shows up (or gives up). Optionally taps it. */
    fun scrollFind(text: String, direction: String, max: Int, tap: Boolean): JSONObject {
        val q = text.trim().lowercase()
        if (q.isEmpty()) return fail("Ki khujbo?")
        val dir = direction.ifBlank { "down" }
        val rounds = max.coerceIn(1, 12)
        for (i in 0..rounds) {
            val snap = snapshot()
            if (snap.optString("status") != "ok") return snap
            val hit = last.firstOrNull { matches(it, q) }
            if (hit != null) {
                if (tap && !clickAt(hit.cx, hit.cy)) return fail("'$text' pawa gelo kintu tap hoyni.")
                return ok(if (tap) "'$text' peye tap korlam." else "'$text' screen-e ache.")
            }
            if (i < rounds) swipe(dir)
        }
        return fail("'$text' scroll kore-o paini.")
    }

    /** Waits until any of the texts is on screen. */
    fun waitForText(texts: List<String>, seconds: Int): JSONObject {
        val wanted = texts.map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (wanted.isEmpty()) return fail("Kon text-er jonno opekkha?")
        val deadline = System.currentTimeMillis() + seconds.coerceIn(1, 15) * 1000L
        while (System.currentTimeMillis() < deadline) {
            val snap = snapshot()
            if (snap.optString("status") == "ok" && last.any { e -> wanted.any { matches(e, it) } }) {
                return ok("Text screen-e eshe geche.")
            }
            Thread.sleep(350)
        }
        return fail("Text ashe ni. read_screen diye dekho.")
    }

    /** On a Play Store page (search results or app page): taps Install and checks that it started. */
    fun playInstall(): JSONObject {
        val deadline = System.currentTimeMillis() + 14000
        var tapped = false
        while (System.currentTimeMillis() < deadline) {
            snapshot()
            fun has(vararg names: String) = last.any { e ->
                names.any { n -> e.text.equals(n, true) || e.desc.equals(n, true) }
            }
            if (!tapped) {
                val btn = last.firstOrNull { e ->
                    e.text.equals("Install", true) || e.desc.equals("Install", true) ||
                        e.text.equals("Get", true) || e.text.equals("Update", true)
                }
                if (btn != null) {
                    clickAt(btn.cx, btn.cy)
                    tapped = true
                    Thread.sleep(1200)
                    continue
                }
                if (has("Open")) return ok("App agei install kora chhilo. open_app diye kholo.")
            } else {
                if (has("Cancel", "Open", "Installing", "Downloading", "Pending", "Installing…")) {
                    return ok("Install shuru hoyeche. Download hote kichu somoy lagbe.")
                }
                if (has("Sign in")) return fail("Play Store-e sign in kora nei.")
            }
            Thread.sleep(350)
        }
        return if (tapped) ok("Install-e tap korechhi, kintu confirm hote parini. Ektu por read_screen diye dekho.")
        else fail("Install button paini. read_screen diye dekho ki ache.")
    }

    private fun findEditable(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 30 || !node.isVisibleToUser) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findEditable(child, depth + 1)?.let { return it }
        }
        return null
    }

    fun pressKey(key: String): JSONObject {
        val k = key.trim().lowercase()
        val action = when (k) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "lock" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return fail("Ei phone-e lock hobe na.")
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return fail("Ei phone-e screenshot hobe na.")
            "enter" -> return pressEnter()
            else -> return fail("'$key' key-ta chini na.")
        }
        return if (performGlobalAction(action)) ok("$k chapa hoyeche.") else fail("$k hoyni.")
    }

    private fun pressEnter(): JSONObject {
        if (Build.VERSION.SDK_INT >= 30) {
            val focused = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null &&
                focused.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            ) {
                return ok("Enter chapa hoyeche.")
            }
        }
        return fail("Enter hoyni. Keyboard-er search button ba screen-er search button-e tap koro (read_screen).")
    }

    fun swipe(direction: String): JSONObject {
        val d = direction.trim().lowercase()

        // Vertical scroll: ask the biggest scrollable view to scroll itself. Far more reliable than a touch swipe.
        if (d == "down" || d == "up") {
            val root = rootInActiveWindow
            val target = root?.let { biggestScrollable(it, 0) }
            if (target != null) {
                val action = if (d == "down") AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                if (target.performAction(action)) {
                    Thread.sleep(150)
                    return ok("Scroll kora hoyeche.")
                }
            }
        }

        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val path = Path()
        when (d) {
            "down" -> { path.moveTo(w * 0.5f, h * 0.74f); path.lineTo(w * 0.5f, h * 0.28f) }
            "up" -> { path.moveTo(w * 0.5f, h * 0.28f); path.lineTo(w * 0.5f, h * 0.74f) }
            "left" -> { path.moveTo(w * 0.85f, h * 0.5f); path.lineTo(w * 0.15f, h * 0.5f) }
            "right" -> { path.moveTo(w * 0.15f, h * 0.5f); path.lineTo(w * 0.85f, h * 0.5f) }
            else -> return fail("direction hobe down, up, left ba right.")
        }
        return if (dispatch(path, 220)) {
            Thread.sleep(120)
            ok("Swipe kora hoyeche.")
        } else {
            fail("Swipe hoyni.")
        }
    }

    // ------------------------------------------------------------------ gestures

    private fun gestureTap(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return dispatch(path, 70)
    }

    private fun dispatch(path: Path, durationMs: Long): Boolean {
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        val latch = CountDownLatch(1)
        val done = AtomicBoolean(false)
        val accepted = dispatchGesture(
            gesture,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    done.set(true)
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            },
            null
        )
        if (!accepted) return false
        latch.await(3, TimeUnit.SECONDS)
        return done.get()
    }

    private fun ok(msg: String) = JSONObject().put("status", "ok").put("message", msg)

    private fun fail(msg: String) = JSONObject().put("status", "error").put("message", msg)
}
