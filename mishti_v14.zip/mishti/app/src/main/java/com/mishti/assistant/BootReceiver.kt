package com.mishti.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

/**
 * After a restart Android does not let a microphone service start by itself, so for people who use the
 * wake word Mishti leaves one tap-to-wake note. One tap and she listens again.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!Prefs(context).nameOnly) return
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel("mishti_wake") == null) {
                nm.createNotificationChannel(
                    NotificationChannel("mishti_wake", "Mishti wake", NotificationManager.IMPORTANCE_LOW)
                )
            }
            val open = PendingIntent.getActivity(
                context, 4,
                Intent(context, MainActivity::class.java).putExtra("wake", true),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(context, "mishti_wake")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Mishti ghumiye ache")
                .setContentText("Tap koro, ar 'Hey Mishti' bolle shunbe")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(77, n)
        } catch (_: Exception) {
        }
    }
}
