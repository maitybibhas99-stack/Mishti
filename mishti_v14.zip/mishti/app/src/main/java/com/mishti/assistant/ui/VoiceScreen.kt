package com.mishti.assistant.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mishti.assistant.Phase
import com.mishti.assistant.Ui

/**
 * The voice screen: just the orb. Back / the arrow hides it and Mishti keeps listening;
 * the power button switches her off.
 */
@Composable
fun VoiceScreen(
    ui: Ui,
    level: () -> Float,
    onHide: () -> Unit,
    onToggleMute: () -> Unit,
    onOff: () -> Unit,
) {
    BackHandler(onBack = onHide)

    val status = when {
        ui.muted -> "Standby, mic bondho"
        ui.asleep -> "Ghumiye achhi... 'Hey Mishti' bolo"
        ui.phase == Phase.Connecting -> "Connect hochhe..."
        ui.phase == Phase.Speaking -> "Mishti bolchhe"
        else -> "Shunchhi..."
    }
    val energy = when {
        ui.muted || ui.asleep -> 0.25f
        ui.phase == Phase.Connecting -> 0.35f
        ui.phase == Phase.Speaking -> 1f
        else -> 0.7f
    }
    val line = ui.activity ?: ui.messages.lastOrNull()?.text.orEmpty()

    Box(Modifier.fillMaxSize().background(Color.Black)) {
    BottomGlow(
        Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .fillMaxHeight(0.62f),
        level = level,
        energy = energy
    )
    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundButton(size = 44, background = Color.Transparent, onClick = onHide) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Lukao", tint = MishtiColors.Text)
            }
            Spacer(Modifier.weight(1f))
            Text(
                "Mishti",
                color = MishtiColors.TextDim,
                fontFamily = FontFamily.Serif,
                fontSize = 18.sp
            )
            Spacer(Modifier.weight(1f))
            Spacer(Modifier.size(44.dp))
        }

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Orb(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp),
                level = level,
                energy = energy
            )
        }

        Text(
            status,
            color = MishtiColors.TextDim,
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 10.dp)
        )
        Text(
            line,
            color = MishtiColors.Text,
            fontFamily = FontFamily.Serif,
            fontSize = 16.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .height(78.dp)
                .padding(horizontal = 32.dp)
        )

        Row(
            Modifier
                .fillMaxWidth()
                .padding(bottom = 34.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundButton(size = 60, background = MishtiColors.Surface, onClick = onToggleMute) {
                Icon(
                    if (ui.muted) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Standby",
                    tint = if (ui.muted) MishtiColors.Coral else MishtiColors.Text
                )
            }
            Spacer(Modifier.size(28.dp))
            RoundButton(size = 60, background = MishtiColors.Danger, onClick = onOff) {
                Icon(Icons.Default.PowerSettingsNew, contentDescription = "Off", tint = Color.White)
            }
        }
    }
    }
}

@Composable
private fun RoundButton(size: Int, background: Color, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}
