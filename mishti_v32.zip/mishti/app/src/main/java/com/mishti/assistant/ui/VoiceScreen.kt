package com.mishti.assistant.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mishti.assistant.Phase
import com.mishti.assistant.Ui

/**
 * The voice section: only the orb, a mute button and a stop button.
 * Back hides it and Mishti keeps listening; stop ends the listening.
 */
@Composable
fun VoiceScreen(
    ui: Ui,
    level: () -> Float,
    onHide: () -> Unit,
    onToggleMute: () -> Unit,
    onOff: () -> Unit,
) {
    BackHandler(onBack = onHide)

    val energy = when {
        ui.muted || ui.asleep -> 0.3f
        ui.phase == Phase.Connecting -> 0.4f
        ui.phase == Phase.Speaking -> 1f
        else -> 0.6f
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF02040C))) {
        LiquidBackground(Modifier.fillMaxSize(), level = level)
        BlueGlow(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(0.45f),
            level = level,
            energy = energy
        )
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                GlassOrb(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f),
                    level = level,
                    energy = energy
                )
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 48.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassButton(
                    tint = if (ui.muted) Color(0x66FF6B6B) else Color(0x33FFFFFF),
                    onClick = onToggleMute
                ) {
                    Icon(
                        if (ui.muted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute",
                        tint = Color.White
                    )
                }
                Spacer(Modifier.size(36.dp))
                GlassButton(tint = Color(0x80E5484D), onClick = onOff) {
                    // stop square
                    Box(
                        Modifier
                            .size(20.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Color.White)
                    )
                }
            }
        }
    }
}

@Composable
private fun GlassButton(tint: Color, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .pressable(onClick)
            .size(68.dp)
            .clip(CircleShape)
            .background(Brush.verticalGradient(0f to Color(0x14FFFFFF), 1f to tint))
            .liquid(CircleShape, strength = 1.4f),
        contentAlignment = Alignment.Center
    ) { content() }
}
