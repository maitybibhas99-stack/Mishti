package com.mishti.assistant.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mishti.assistant.MishtiNotificationService
import com.mishti.assistant.NotifInfo
import com.mishti.assistant.NotifKind
import kotlinx.coroutines.delay

/** Everything in the notification shade, with quick actions. Mishti can also read these out loud. */
@Composable
fun NotificationsScreen(onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    var rows by remember { mutableStateOf<List<NotifInfo>>(emptyList()) }
    var connected by remember { mutableStateOf(MishtiNotificationService.instance != null) }
    var replyingTo by remember { mutableStateOf<String?>(null) }
    var replyText by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        var n = 0
        while (true) {
            val svc = MishtiNotificationService.instance
            connected = svc != null
            rows = svc?.rows().orEmpty()
            if (svc == null && n % 4 == 0) MishtiNotificationService.rebind(context)
            n++
            delay(1500)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .auroraBackground()
            .systemBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(64.dp)
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(42.dp)
                    .glass(CircleShape)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Column(Modifier.padding(start = 14.dp).weight(1f)) {
                Text("Notifications", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    if (!connected) "Not connected" else "${rows.size} in your shade",
                    color = MishtiColors.TextDim,
                    fontSize = 12.sp
                )
            }
        }

        if (!connected) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .glass(RoundedCornerShape(26.dp))
                    .padding(18.dp)
            ) {
                Text("Notification access is needed", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    if (MishtiNotificationService.enabled(context))
                        "It is switched on but Android has not connected it yet. Mishti is reconnecting. If this stays, switch it off and on once."
                    else
                        "Switch Mishti on in Notification access so she can read, announce and reply to your messages.",
                    color = MishtiColors.TextDim,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
                Spacer(Modifier.height(12.dp))
                ActionPill("Open settings", true) {
                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
            }
        } else {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ActionPill("Clear junk", false) { MishtiNotificationService.instance?.dismiss("junk") }
                ActionPill("Clear all", false) { MishtiNotificationService.instance?.dismiss("all") }
            }
            if (rows.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("All clear. Nothing waiting.", color = MishtiColors.TextDim, fontSize = 15.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(rows, key = { it.id }) { n ->
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .glass(RoundedCornerShape(22.dp))
                                .padding(16.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(n.app, color = MishtiColors.Accent, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                KindTag(n.kind)
                                Spacer(Modifier.size(8.dp))
                                Text(ago(n.whenMs), color = MishtiColors.TextDim, fontSize = 12.sp)
                            }
                            if (n.title.isNotBlank()) {
                                Spacer(Modifier.height(6.dp))
                                Text(n.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            }
                            if (n.text.isNotBlank()) {
                                Spacer(Modifier.height(4.dp))
                                Text(n.text, color = Color(0xFFD5DEF0), fontSize = 14.sp, lineHeight = 20.sp, maxLines = 6)
                            }
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ActionPill("Open", false) { MishtiNotificationService.instance?.openIt(n.id) }
                                if (n.canReply) {
                                    ActionPill("Reply", false) { replyingTo = if (replyingTo == n.id) null else n.id }
                                }
                                ActionPill("Dismiss", false) { MishtiNotificationService.instance?.dismiss(n.id) }
                            }
                            if (replyingTo == n.id) {
                                Spacer(Modifier.height(10.dp))
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(24.dp))
                                        .background(Color(0x33000000))
                                        .border(1.dp, Color(0x2EFFFFFF), RoundedCornerShape(24.dp))
                                        .padding(start = 16.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.weight(1f)) {
                                        if (replyText.isEmpty()) Text("Type a reply...", color = MishtiColors.TextDim, fontSize = 15.sp)
                                        BasicTextField(
                                            value = replyText,
                                            onValueChange = { replyText = it },
                                            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                                            cursorBrush = SolidColor(Color.White),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                    ActionPill("Send", true) {
                                        if (replyText.isNotBlank()) {
                                            MishtiNotificationService.instance?.reply(n.id, replyText)
                                            replyText = ""
                                            replyingTo = null
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun ago(whenMs: Long): String {
    val m = ((System.currentTimeMillis() - whenMs) / 60000L).coerceAtLeast(0L)
    return when {
        m < 1 -> "now"
        m < 60 -> "${m}m"
        m < 1440 -> "${m / 60}h"
        else -> "${m / 1440}d"
    }
}

@Composable
private fun KindTag(kind: NotifKind) {
    val (label, color) = when (kind) {
        NotifKind.IMPORTANT -> "Important" to Color(0xFF4ADE9A)
        NotifKind.MESSAGE -> "Message" to Color(0xFF58B8FF)
        NotifKind.JUNK -> "Junk" to Color(0xFFFFC857)
        NotifKind.OTHER -> "" to Color.Transparent
    }
    if (label.isNotEmpty()) {
        Text(
            label,
            color = color,
            fontSize = 11.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(color.copy(alpha = 0.15f))
                .padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
private fun ActionPill(text: String, strong: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .pressable(onClick)
            .clip(shape)
            .background(
                if (strong) Brush.verticalGradient(0f to Color(0xFF6FBFFF), 1f to Color(0xFF2F7BFF))
                else Brush.verticalGradient(0f to Color(0x2EFFFFFF), 1f to Color(0x1AFFFFFF))
            )
            .border(1.dp, Color(0x33FFFFFF), shape)
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}
