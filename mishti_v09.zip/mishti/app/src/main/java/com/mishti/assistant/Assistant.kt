package com.mishti.assistant

import android.app.Application
import androidx.compose.runtime.mutableFloatStateOf
import java.util.Calendar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

data class ChatMessage(val id: Long, val fromUser: Boolean, val text: String)

enum class Phase { Idle, Connecting, Listening, Speaking }

data class Ui(
    val messages: List<ChatMessage> = emptyList(),
    val phase: Phase = Phase.Idle,
    /** The full-screen orb is showing. */
    val voiceOpen: Boolean = false,
    /** Mishti is switched on: she keeps listening, even with the orb screen closed. */
    val listening: Boolean = false,
    /** Standby: mic is off so music/video does not confuse her. */
    val muted: Boolean = false,
    /** What she is doing right now, shown under the orb. */
    val activity: String? = null,
    val error: String? = null,
)

/**
 * The whole session. Lives as long as the app process (not the screen), so Mishti keeps
 * listening while other apps are in front. MishtiService keeps the process alive in the background.
 *
 * Two ways in: voice (orb screen, mic on, she speaks) and text (chat, mic untouched, she stays silent).
 */
class Assistant(private val app: Application) : GeminiLiveClient.Listener {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()

    /** Loudness 0..1 for the orb. Kept apart from Ui so a 30 fps change redraws only the orb. */
    val level = mutableFloatStateOf(0f)

    val prefs = Prefs(app)
    private val audio = AudioEngine(app)
    private var client: GeminiLiveClient? = null
    private var ticker: Job? = null
    private var reconnectJob: Job? = null
    private var watcherJob: Job? = null
    private var chatterJob: Job? = null
    @Volatile private var lastTalk = System.currentTimeMillis()
    private var nextId = 1L
    private val pendingText = mutableListOf<String>()

    /** Tool calls run one after another, never in parallel (taps must not overlap). */
    private val toolLock = Mutex()

    private val phone = PhoneActions(app, prefs, object : PhoneActions.Hooks {
        override fun standby() = setStandby(true)
        override fun endSession() {
            scope.launch { stopListening() }
        }
    })

    @Volatile private var ready = false
    @Volatile private var micStarted = false
    @Volatile private var standby = false
    @Volatile private var wantListening = false

    /** True after a typed message: that answer is shown as text only, never spoken. */
    @Volatile private var silentTurn = false

    /** 0 = full setup, 1 = without the language hint, 2 = bare minimum. Steps up if the server rejects setup. */
    private var compat = 0
    private var failures = 0
    private var lastProblem: String? = null
    private var smooth = 0f

    // ---------------------------------------------------------------- public API

    /** Switch Mishti on (mic on, orb screen). Call after the mic permission is granted. */
    fun startListening() {
        wantListening = true
        silentTurn = false
        standby = false
        failures = 0
        compat = 0
        _ui.update { it.copy(voiceOpen = true, listening = true, muted = false, error = null) }
        if (!ensureSession(voice = true)) return
        if (ready) startMicIfNeeded()
        startWatcher()
        startChatter()
    }

    /** Now and then, when it has been quiet for a while, Mishti starts talking by herself. */
    private fun startChatter() {
        if (chatterJob?.isActive == true || !prefs.spontaneous) return
        chatterJob = scope.launch {
            while (isActive) {
                delay((40..70).random() * 60_000L)
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val quietFor = System.currentTimeMillis() - lastTalk
                if (wantListening && ready && !standby && hour in 8..23 && quietFor > 35 * 60_000L) {
                    silentTurn = false
                    lastTalk = System.currentTimeMillis()
                    client?.sendText("[SPONTANEOUS] Tomar ekhon ektu kotha bolte ichchhe korchhe.")
                }
            }
        }
    }

    private fun startWatcher() {
        if (watcherJob?.isActive == true || !prefs.deviceWatch) return
        val watcher = DeviceWatcher(app) { note ->
            scope.launch {
                // Only speak up when she is switched on and connected; otherwise skip it.
                if (wantListening && ready) {
                    silentTurn = false
                    client?.sendText(note)
                }
            }
        }
        watcherJob = scope.launch(Dispatchers.Default) { watcher.run() }
    }

    /** Show the orb screen again (she is already listening). */
    fun showVoice() {
        if (wantListening) _ui.update { it.copy(voiceOpen = true) } else startListening()
    }

    /** Close the orb screen only. Mishti keeps listening in the background. */
    fun hideVoice() {
        _ui.update { it.copy(voiceOpen = false) }
    }

    /** Switch Mishti fully off. */
    fun stopListening() {
        wantListening = false
        standby = false
        reconnectJob?.cancel()
        watcherJob?.cancel()
        watcherJob = null
        chatterJob?.cancel()
        chatterJob = null
        MishtiAccessibilityService.instance?.glow(false)
        dropClient()
        audio.stopMic()
        audio.stopPlayback()
        micStarted = false
        MishtiService.stop(app)
        synchronized(pendingText) { pendingText.clear() }
        stopTicker()
        _ui.update { it.copy(voiceOpen = false, listening = false, muted = false, phase = Phase.Idle, activity = null) }
    }

    /** Standby = mic off + normal audio mode (so music sounds right). Turning it off makes Mishti listen again. */
    fun setStandby(on: Boolean) {
        standby = on
        _ui.update { it.copy(muted = on) }
        audio.setCallMode(!on)
        if (wantListening) MishtiService.refresh(app, on)
    }

    fun toggleMute() = setStandby(!standby)

    fun sendText(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        silentTurn = true
        lastTalk = System.currentTimeMillis()
        addOrAppend(fromUser = true, text = clean, forceNew = true)
        _ui.update { it.copy(error = null) }
        if (!ensureSession(voice = false)) return
        if (ready) client?.sendText(clean) else synchronized(pendingText) { pendingText.add(clean) }
    }

    fun newChat() {
        _ui.update { it.copy(messages = emptyList(), error = null, activity = null) }
        // Fresh conversation for the model too.
        dropClient()
        if (wantListening) {
            connect()
        } else {
            stopTicker()
            _ui.update { it.copy(phase = Phase.Idle) }
        }
    }

    fun dismissError() {
        _ui.update { it.copy(error = null) }
    }

    // ---------------------------------------------------------------- session

    private fun ensureSession(voice: Boolean): Boolean {
        if (voice) {
            MishtiService.start(app)
            audio.startPlayback()
        }
        if (client != null) return true
        if (prefs.apiKey.isBlank()) {
            wantListening = false
            _ui.update {
                it.copy(
                    voiceOpen = false,
                    listening = false,
                    error = "Gemini API key nei. Upore Settings-e giye key dao."
                )
            }
            if (voice) {
                audio.stopPlayback()
                MishtiService.stop(app)
            }
            return false
        }
        connect()
        return true
    }

    private fun connect() {
        val key = prefs.apiKey
        if (key.isBlank()) return
        ready = false
        _ui.update { it.copy(phase = Phase.Connecting) }
        val options = GeminiLiveClient.Options(
            silenceMs = prefs.silenceMs,
            webSearch = prefs.webSearch,
            lean = compat >= 2,
            langCode = if (compat == 0) langCode() else null,
            bargeIn = prefs.bargeIn,
            noisy = prefs.noisyRoom,
        )
        val prompt = Persona.prompt(prefs.userName, prefs.notes, prefs.language, prefs.nameOnly, prefs.routineNames)
        client = GeminiLiveClient(key, prefs.model, this, options).also {
            it.connect(prompt, prefs.voice)
        }
        startTicker()
    }

    private fun langCode(): String? = when (prefs.language) {
        "bangla" -> "bn-IN"
        "hindi" -> "hi-IN"
        "english" -> "en-US"
        else -> null
    }

    private fun dropClient() {
        client?.close()
        client = null
        ready = false
    }

    private fun startMicIfNeeded() {
        if (micStarted || !wantListening) return
        val ok = audio.startMic { chunk ->
            if (!standby) client?.sendAudio(chunk)
        }
        if (ok) {
            micStarted = true
        } else {
            stopListening()
            _ui.update { it.copy(error = "Mic chalu korte parlam na. Permission dekho.") }
        }
    }

    private fun stopTicker() {
        ticker?.cancel()
        ticker = null
        smooth = 0f
        level.floatValue = 0f
    }

    private fun startTicker() {
        if (ticker?.isActive == true) return
        ticker = scope.launch {
            while (isActive) {
                val speaking = audio.outstandingMs() > 0
                val raw = when {
                    speaking -> audio.outLevel
                    micStarted && !standby -> audio.micLevel * 0.8f
                    else -> 0f
                }
                smooth = if (raw > smooth) smooth + (raw - smooth) * 0.6f else smooth + (raw - smooth) * 0.14f
                level.floatValue = smooth
                val phase = when {
                    !ready -> Phase.Connecting
                    speaking -> Phase.Speaking
                    else -> Phase.Listening
                }
                if (_ui.value.phase != phase) _ui.update { it.copy(phase = phase) }
                delay(33)
            }
        }
    }

    // ---------------------------------------------------------------- transcript

    private fun addOrAppend(fromUser: Boolean, text: String, forceNew: Boolean = false) {
        _ui.update { s ->
            val last = s.messages.lastOrNull()
            if (!forceNew && last != null && last.fromUser == fromUser) {
                s.copy(messages = s.messages.dropLast(1) + last.copy(text = last.text + text))
            } else {
                s.copy(messages = s.messages + ChatMessage(nextId++, fromUser, text))
            }
        }
    }

    private fun describe(name: String, args: JSONObject): String = when (name) {
        "call_contact" -> "Call korchhi..."
        "send_sms" -> "SMS pathachhi..."
        "open_app" -> "${args.optString("app_name")} khulchhi..."
        "open_url" -> "Link khulchhi..."
        "play_youtube", "play_media" -> "Chalachhi: ${args.optString("query")}"
        "read_screen" -> "Screen dekhchhi..."
        "tap_text", "tap_index" -> "Tap korchhi..."
        "type_text" -> "Likhchhi..."
        "swipe" -> "Scroll korchhi..."
        "quick_toggle" -> "${args.optString("tile")} toggle korchhi..."
        "torch" -> "Torch..."
        "set_volume" -> "Volume thik korchhi..."
        "set_alarm", "set_timer" -> "Alarm/timer set korchhi..."
        else -> "Kaj korchhi..."
    }

    // ---------------------------------------------------------------- Gemini callbacks

    override fun onReady() {
        scope.launch {
            ready = true
            failures = 0
            lastProblem = null
            _ui.update { it.copy(phase = Phase.Listening) }
            val queued = synchronized(pendingText) { pendingText.toList().also { pendingText.clear() } }
            queued.forEach { client?.sendText(it) }
            startMicIfNeeded()
        }
    }

    override fun onAudio(pcm: ByteArray) {
        if (!silentTurn && wantListening) audio.play(pcm)
    }

    override fun onInputText(text: String) {
        // Heard her user talk: this turn is a spoken one.
        silentTurn = false
        lastTalk = System.currentTimeMillis()
        addOrAppend(fromUser = true, text = text)
    }

    override fun onOutputText(text: String) = addOrAppend(fromUser = false, text = text)

    override fun onInterrupted() = audio.interrupt()

    override fun onToolCall(id: String, name: String, args: JSONObject) {
        scope.launch(Dispatchers.IO) {
            toolLock.withLock {
                _ui.update { it.copy(activity = describe(name, args)) }
                MishtiAccessibilityService.instance?.glow(true)
                val result = phone.run(name, args)
                client?.sendToolResponse(id, name, result)
            }
        }
    }

    override fun onTurnComplete() {
        lastTalk = System.currentTimeMillis()
        // The whole job is finished: let the edge glow fade away.
        if (!toolLock.isLocked) MishtiAccessibilityService.instance?.glow(false)
        _ui.update { if (it.activity != null) it.copy(activity = null) else it }
    }

    override fun onClosed(reason: String?) {
        scope.launch { handleDrop(reason?.takeIf { it.isNotBlank() }, quiet = true) }
    }

    override fun onError(message: String) {
        scope.launch { handleDrop(message, quiet = false) }
    }

    /** The connection ended. Retry quietly while Mishti is switched on. */
    private fun handleDrop(problem: String?, quiet: Boolean) {
        val wasReady = ready
        dropClient()
        problem?.let { lastProblem = it }

        val wanted = wantListening || synchronized(pendingText) { pendingText.isNotEmpty() }

        // Dropped before setup finished: probably a setup field this model does not take. Retry once, minimal.
        if (!wasReady && compat < 2 && wanted) {
            compat++
            connect()
            return
        }

        if (!wantListening) {
            // Text chat only: just let the connection go. The next message reconnects.
            stopTicker()
            _ui.update {
                it.copy(
                    phase = Phase.Idle,
                    activity = null,
                    error = if (!quiet || !wasReady) "Connection hoyni: ${lastProblem ?: "abar try koro"}" else it.error
                )
            }
            synchronized(pendingText) { pendingText.clear() }
            return
        }

        failures = if (wasReady) 1 else failures + 1
        if (failures > 6) {
            val msg = "Connection hochhe na (${lastProblem ?: "unknown"}). Key, model ar internet dekho."
            stopListening()
            _ui.update { it.copy(error = msg) }
            return
        }
        _ui.update { it.copy(phase = Phase.Connecting, activity = null) }
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(minOf(400L * failures, 6000L))
            if (wantListening && client == null) connect()
        }
    }
}
