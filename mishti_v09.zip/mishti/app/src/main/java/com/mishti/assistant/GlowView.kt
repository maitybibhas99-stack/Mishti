package com.mishti.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.graphics.ColorUtils
import kotlin.math.min
import kotlin.math.sin

/**
 * A soft, breathing, colour-shifting glow around the edges of the whole screen.
 * Shown by the accessibility service while Mishti is busy with a task; it fades out when she is done.
 */
class GlowView(context: Context) : View(context) {

    private val palette = intArrayOf(
        Color.parseColor("#FF3D8B"),
        Color.parseColor("#A16BFF"),
        Color.parseColor("#5B7BFF"),
        Color.parseColor("#39F2E0"),
        Color.parseColor("#FFB86B"),
    )

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var fade = 0f

    private val loop = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 4200
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }
    private var fader: ValueAnimator? = null

    fun start() {
        if (!loop.isStarted) loop.start()
    }

    fun fadeTo(target: Float, onDone: (() -> Unit)? = null) {
        fader?.cancel()
        fader = ValueAnimator.ofFloat(fade, target).apply {
            duration = if (target > fade) 350 else 600
            addUpdateListener {
                fade = it.animatedValue as Float
                invalidate()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false

                override fun onAnimationCancel(animation: android.animation.Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: android.animation.Animator) {
                    if (!cancelled && target == 0f) {
                        loop.cancel()
                        onDone?.invoke()
                    }
                }
            })
            start()
        }
    }

    private fun colorAt(t: Float): Int {
        val x = ((t % 1f) + 1f) % 1f * palette.size
        val i = x.toInt() % palette.size
        val j = (i + 1) % palette.size
        return ColorUtils.blendARGB(palette[i], palette[j], x - x.toInt())
    }

    override fun onDraw(canvas: Canvas) {
        if (fade <= 0f) return
        val w = width.toFloat()
        val h = height.toFloat()
        val breath = 0.5f + 0.5f * sin(phase * 2f * Math.PI.toFloat())
        val depth = min(w, h) * (0.10f + 0.06f * breath)
        val a = fade * (0.55f + 0.35f * breath)

        fun edge(color: Int, x0: Float, y0: Float, x1: Float, y1: Float, l: Float, t: Float, r: Float, b: Float) {
            val strong = ColorUtils.setAlphaComponent(color, (255 * a).toInt().coerceIn(0, 255))
            val clear = ColorUtils.setAlphaComponent(color, 0)
            paint.shader = LinearGradient(x0, y0, x1, y1, strong, clear, Shader.TileMode.CLAMP)
            canvas.drawRect(l, t, r, b, paint)
        }

        edge(colorAt(phase), 0f, 0f, 0f, depth, 0f, 0f, w, depth)
        edge(colorAt(phase + 0.25f), w, 0f, w - depth, 0f, w - depth, 0f, w, h)
        edge(colorAt(phase + 0.5f), 0f, h, 0f, h - depth, 0f, h - depth, w, h)
        edge(colorAt(phase + 0.75f), 0f, 0f, depth, 0f, 0f, 0f, depth, h)
        paint.shader = null
    }
}
