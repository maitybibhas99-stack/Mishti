package com.mishti.assistant

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * "Only my voice". Everything runs on the phone, instantly, with no download:
 * each 40 ms of speech is turned into a pitch (F0) and 12 voice-colour numbers (mel cepstrum).
 * Your voice is learned once ([enroll]); afterwards a new burst of speech is only passed on to Gemini when its
 * pitch and colour match yours. It also tells male from female by pitch.
 */
class VoiceGate(private val ctx: Context) {

    class Print(val mean: FloatArray, val std: FloatArray, val f0: Float, val f0Std: Float)

    class Frame(val cep: FloatArray, val f0: Float)

    companion object {
        private const val RATE = 16000
        private const val N = 640        // 40 ms
        private const val FFT = 512
        private const val BANDS = 24
        private const val CEPS = 12

        fun format(p: Print): String =
            "v1;" + p.mean.joinToString(",") + ";" + p.std.joinToString(",") + ";" + p.f0 + ";" + p.f0Std

        fun parse(s: String): Print? {
            if (!s.startsWith("v1;")) return null
            return try {
                val t = s.split(";")
                val m = t[1].split(",").map { it.toFloat() }.toFloatArray()
                val sd = t[2].split(",").map { it.toFloat() }.toFloatArray()
                if (m.size != CEPS || sd.size != CEPS) null else Print(m, sd, t[3].toFloat(), t[4].toFloat())
            } catch (_: Exception) {
                null
            }
        }

        fun gender(f0: Float): String = when {
            f0 <= 0f -> "unknown"
            f0 < 165f -> "male"
            else -> "female"
        }

        private fun semis(a: Float, b: Float): Float =
            if (a <= 0f || b <= 0f) 0f else (12.0 * ln((a / b).toDouble()) / ln(2.0)).toFloat()
    }

    // ------------------------------------------------------------------ features

    private val window = FloatArray(FFT) { (0.54 - 0.46 * cos(2.0 * PI * it / (FFT - 1))).toFloat() }
    private val filters: Array<FloatArray> = run {
        fun mel(f: Double) = 2595.0 * log10(1.0 + f / 700.0)
        fun inv(m: Double) = 700.0 * (10.0.pow(m / 2595.0) - 1.0)
        val lo = mel(100.0)
        val hi = mel(5600.0)
        val pts = DoubleArray(BANDS + 2) { inv(lo + (hi - lo) * it / (BANDS + 1)) * FFT / RATE }
        Array(BANDS) { b ->
            val w = FloatArray(FFT / 2 + 1)
            val l = pts[b]; val c = pts[b + 1]; val r = pts[b + 2]
            for (k in w.indices) {
                val x = k.toDouble()
                w[k] = when {
                    x <= l || x >= r -> 0f
                    x < c -> ((x - l) / (c - l)).toFloat()
                    else -> ((r - x) / (r - c)).toFloat()
                }
            }
            w
        }
    }
    private val dct = Array(CEPS) { k -> FloatArray(BANDS) { m -> cos(PI * (k + 1) * (m + 0.5) / BANDS).toFloat() } }
    private val re = FloatArray(FFT)
    private val im = FloatArray(FFT)

    private fun fft() {
        val n = FFT
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var cr = 1f
                var ci = 0f
                for (k in 0 until len / 2) {
                    val a = i + k
                    val b = i + k + len / 2
                    val xr = re[b] * cr - im[b] * ci
                    val xi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - xr; im[b] = im[a] - xi
                    re[a] += xr; im[a] += xi
                    val nr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = nr
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** One 40 ms frame of 16 kHz samples; null when it is not clearly voiced speech. */
    private fun analyze(x: FloatArray): Frame? {
        var mean = 0f
        for (v in x) mean += v
        mean /= x.size
        var r0 = 0f
        for (i in x.indices) { x[i] -= mean; r0 += x[i] * x[i] }
        val rms = sqrt(r0 / x.size)
        if (rms < 0.012f) return null
        // pitch by autocorrelation, 70 to 320 Hz
        val minLag = RATE / 320
        val maxLag = RATE / 70
        var best = 0f
        var bestLag = 0
        val corr = FloatArray(maxLag + 1)
        for (lag in minLag..maxLag) {
            var s = 0f
            for (i in 0 until x.size - lag) s += x[i] * x[i + lag]
            val v = s / r0 * x.size / (x.size - lag)
            corr[lag] = v
            if (v > best) { best = v; bestLag = lag }
        }
        if (best < 0.38f || bestLag == 0) return null
        // prefer the shortest lag that is nearly as strong (avoids octave-down mistakes)
        for (lag in minLag until bestLag) {
            if (corr[lag] >= 0.88f * best && corr[lag] >= corr[lag - 1] && corr[lag] >= corr[lag + 1]) {
                bestLag = lag
                break
            }
        }
        val f0 = RATE.toFloat() / bestLag
        // spectrum of the last 512 samples
        val off = x.size - FFT
        for (i in 0 until FFT) {
            val pre = if (i + off > 0) x[i + off] - 0.97f * x[i + off - 1] else x[i + off]
            re[i] = pre * window[i]
            im[i] = 0f
        }
        fft()
        val power = FloatArray(FFT / 2 + 1) { re[it] * re[it] + im[it] * im[it] }
        val logMel = FloatArray(BANDS)
        for (b in 0 until BANDS) {
            var e = 0f
            val w = filters[b]
            for (k in power.indices) if (w[k] != 0f) e += power[k] * w[k]
            logMel[b] = ln(e + 1e-6f)
        }
        val cep = FloatArray(CEPS)
        for (k in 0 until CEPS) {
            var s = 0f
            for (m in 0 until BANDS) s += logMel[m] * dct[k][m]
            cep[k] = s / BANDS * 2f
        }
        return Frame(cep, f0)
    }

    private fun toFloats(pcm: ByteArray, from: Int, count: Int): FloatArray {
        val out = FloatArray(count)
        for (i in 0 until count) {
            val p = from + i * 2
            out[i] = ((pcm[p + 1].toInt() shl 8) or (pcm[p].toInt() and 0xFF)).toShort() / 32768f
        }
        return out
    }

    private fun median(v: List<Float>): Float {
        if (v.isEmpty()) return 0f
        val s = v.sorted()
        return s[s.size / 2]
    }

    // ------------------------------------------------------------------ enrol

    /** Records the owner for [seconds] and learns the voice. Returns null, or an error text. */
    @SuppressLint("MissingPermission")
    fun enroll(seconds: Int, onTick: (Int) -> Unit): String? {
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return "Microphone not available."
        val mic = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, RATE)
            )
        } catch (e: Exception) {
            return "Microphone not available."
        }
        if (mic.state != AudioRecord.STATE_INITIALIZED) {
            mic.release()
            return "Microphone is busy. Close other apps using it and try again."
        }
        val frames = ArrayList<Frame>()
        val buf = ByteArray(N * 2)
        val endAt = SystemClock.elapsedRealtime() + seconds * 1000L
        var lastTick = -1
        mic.startRecording()
        try {
            while (SystemClock.elapsedRealtime() < endAt) {
                var got = 0
                while (got < buf.size) {
                    val n = mic.read(buf, got, buf.size - got)
                    if (n <= 0) return "Microphone stopped. Try again."
                    got += n
                }
                analyze(toFloats(buf, 0, N))?.let { frames.add(it) }
                val left = ((endAt - SystemClock.elapsedRealtime()) / 1000L).toInt() + 1
                if (left != lastTick) { lastTick = left; onTick(left) }
            }
        } finally {
            try { mic.stop() } catch (_: Exception) {}
            mic.release()
        }
        if (frames.size < 50) return "I heard too little clear speech (${frames.size} parts). Speak louder and keep talking, then try again."
        val mean = FloatArray(CEPS)
        for (f in frames) for (i in 0 until CEPS) mean[i] += f.cep[i]
        for (i in 0 until CEPS) mean[i] /= frames.size
        val std = FloatArray(CEPS)
        for (f in frames) for (i in 0 until CEPS) std[i] += (f.cep[i] - mean[i]).let { it * it }
        for (i in 0 until CEPS) std[i] = max(sqrt(std[i] / frames.size), 0.15f)
        val f0m = median(frames.map { it.f0 })
        var sv = 0f
        for (f in frames) sv += semis(f.f0, f0m).let { it * it }
        val print = Print(mean, std, f0m, max(sqrt(sv / frames.size), 0.8f))
        this.print = print
        return null
    }

    // ------------------------------------------------------------------ check

    @Volatile var enabled = false
    @Volatile var print: Print? = null
    /** Lower = stricter. About 0.95 strict, 1.2 normal, 1.5 relaxed. */
    @Volatile var threshold = 1.2f
    /** Shown in Settings: who it heard last. */
    @Volatile var onInfo: ((String) -> Unit)? = null
    /** Called now and then with the slowly adapted voice print, so it can be saved. */
    @Volatile var onAdapted: ((Print) -> Unit)? = null

    private class Verdict(val score: Float, val f0: Float, val frames: Int)

    private fun judge(frames: List<Frame>): Verdict? {
        val p = print ?: return null
        if (frames.isEmpty()) return null
        val f0 = median(frames.map { it.f0 })
        val m = FloatArray(CEPS)
        for (f in frames) for (i in 0 until CEPS) m[i] += f.cep[i]
        for (i in 0 until CEPS) m[i] /= frames.size
        var z = 0f
        for (i in 0 until CEPS) {
            val d = (m[i] - p.mean[i]) / p.std[i]
            z += d * d
        }
        val rms = sqrt(z / CEPS)
        val pitch = abs(semis(f0, p.f0))
        return Verdict(rms + 0.12f * pitch, f0, frames.size)
    }

    private fun describe(v: Verdict, ok: Boolean): String =
        "${gender(v.f0).replaceFirstChar { it.uppercase() }} voice, ${v.f0.toInt()} Hz, match ${"%.2f".format(v.score)} (limit ${"%.2f".format(threshold)}): " +
            if (ok) "it is you" else "not you, ignored"

    private enum class S { IDLE, VERIFY, OPEN, REJECT }

    private var state = S.IDLE
    private val lead = ArrayDeque<ByteArray>()
    private val held = ArrayList<ByteArray>()
    private val frames = ArrayList<Frame>()
    private var quiet = 0
    private var floor = 0.01f
    private var lastOk = 0L
    private var adapts = 0

    private fun frameOf(chunk: ByteArray): Frame? =
        if (chunk.size >= N * 2) analyze(toFloats(chunk, chunk.size - N * 2, N)) else null

    /** Gets one mic chunk (16 kHz, 16-bit mono, about 40 ms) and passes it on only when it is the owner. */
    fun feed(chunk: ByteArray, level: Float, out: (ByteArray) -> Unit) {
        floor = if (level < floor) max(level, 0.003f) else floor + (level - floor) * 0.002f
        val loud = level > max(0.02f, floor * 2.8f)
        if (loud) quiet = 0 else quiet++

        when (state) {
            S.IDLE -> {
                lead.addLast(chunk)
                while (lead.size > 6) lead.removeFirst()
                if (loud) {
                    state = S.VERIFY
                    held.clear(); held.addAll(lead); lead.clear()
                    frames.clear()
                    frameOf(chunk)?.let { frames.add(it) }
                }
            }
            S.VERIFY -> {
                held.add(chunk)
                frameOf(chunk)?.let { frames.add(it) }
                val n = frames.size
                val p = print
                if (p == null) { open(out); return }
                // fast no: pitch is far from yours (another gender, a child...)
                if (n >= 4) {
                    val f0 = median(frames.map { it.f0 })
                    if (abs(semis(f0, p.f0)) > 7f) { decide(false, out); return }
                }
                if (n >= 5) {
                    val v = judge(frames)
                    if (v != null && v.score < threshold * 0.7f) { decide(true, out); return }
                }
                if (n >= 9 || held.size >= 40) { decide(null, out); return }
                if (quiet >= 10) {
                    if (n >= 3) decide(null, out)
                    else {
                        // a very short word ("haan", "ruko"): fine only right after you spoke
                        val near = SystemClock.elapsedRealtime() - lastOk < 4000L
                        if (near) open(out) else { state = S.IDLE; held.clear(); frames.clear() }
                    }
                }
            }
            S.OPEN -> {
                out(chunk)
                if (quiet >= 40) state = S.IDLE
            }
            S.REJECT -> {
                if (quiet >= 10) { state = S.IDLE; lead.clear() }
            }
        }
    }

    private fun open(out: (ByteArray) -> Unit) {
        state = S.OPEN
        held.forEach { out(it) }
        held.clear()
        quiet = 0
    }

    private fun decide(forced: Boolean?, out: (ByteArray) -> Unit) {
        val v = judge(frames)
        val ok = forced ?: (v != null && v.score < threshold)
        if (v != null) onInfo?.invoke(describe(v, ok))
        else if (!ok) onInfo?.invoke("Too short to tell, ignored")
        if (ok) {
            lastOk = SystemClock.elapsedRealtime()
            if (v != null) adapt(v)
            open(out)
        } else {
            state = S.REJECT
            held.clear()
        }
        frames.clear()
    }

    /** When it is clearly you, nudge your saved voice a little toward today's sound. */
    private fun adapt(v: Verdict) {
        val p = print ?: return
        if (v.score > threshold * 0.6f || frames.size < 8) return
        val m = FloatArray(CEPS)
        for (f in frames) for (i in 0 until CEPS) m[i] += f.cep[i]
        for (i in 0 until CEPS) m[i] /= frames.size
        for (i in 0 until CEPS) p.mean[i] = p.mean[i] * 0.97f + m[i] * 0.03f
        adapts++
        if (adapts % 15 == 0) onAdapted?.invoke(p)
    }

    fun reset() {
        state = S.IDLE
        held.clear(); lead.clear(); frames.clear()
        quiet = 0
    }
}
