package com.mishti.assistant

import org.json.JSONArray
import org.json.JSONObject

/** Function declarations sent to Gemini Live. Names must match PhoneActions.run(). */
object Tools {

    private class Param(val name: String, val schema: JSONObject, val required: Boolean)

    private fun s(name: String, desc: String, required: Boolean = true) =
        Param(name, JSONObject().put("type", "STRING").put("description", desc), required)

    private fun i(name: String, desc: String, required: Boolean = true) =
        Param(name, JSONObject().put("type", "INTEGER").put("description", desc), required)

    private fun n(name: String, desc: String, required: Boolean = true) =
        Param(name, JSONObject().put("type", "NUMBER").put("description", desc), required)

    private fun b(name: String, desc: String, required: Boolean = true) =
        Param(name, JSONObject().put("type", "BOOLEAN").put("description", desc), required)

    private fun fn(name: String, desc: String, blocking: Boolean, vararg params: Param): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        // Wait for each answer before the model carries on, so steps never overlap.
        if (blocking) o.put("behavior", "BLOCKING")
        if (params.isNotEmpty()) {
            val props = JSONObject()
            params.forEach { props.put(it.name, it.schema) }
            val required = JSONArray()
            params.filter { it.required }.forEach { required.put(it.name) }
            o.put(
                "parameters",
                JSONObject().put("type", "OBJECT").put("properties", props).put("required", required)
            )
        }
        return o
    }

    private fun prop(type: String, desc: String) = JSONObject().put("type", type).put("description", desc)

    /** One step of do_steps: a tool name plus whatever arguments that tool takes. */
    private fun stepsParam(): Param {
        val props = JSONObject()
            .put("tool", prop("STRING", "Tool-er naam, jemon open_app, tap_text, type_text, press_key, swipe, wait, read_screen, preview_tap, play_youtube"))
            .put("app_name", prop("STRING", "open_app-er jonno"))
            .put("name_or_number", prop("STRING", "call_contact-er jonno"))
            .put("to", prop("STRING", "send_sms-er jonno"))
            .put("message", prop("STRING", "send_sms-er jonno"))
            .put("url", prop("STRING", "open_url-er jonno"))
            .put("query", prop("STRING", "play_youtube / play_media-er jonno"))
            .put("app", prop("STRING", "play_media-er jonno"))
            .put("text", prop("STRING", "tap_text / type_text-er jonno"))
            .put("index", prop("INTEGER", "tap_index-er jonno"))
            .put("key", prop("STRING", "press_key-er jonno"))
            .put("direction", prop("STRING", "swipe-er jonno"))
            .put("seconds", prop("INTEGER", "wait-er jonno"))
            .put("ms", prop("INTEGER", "wait-er jonno, millisecond"))
            .put("x", prop("INTEGER", "tap_at-er jonno, percent"))
            .put("y", prop("INTEGER", "tap_at-er jonno, percent"))
            .put("hold_ms", prop("INTEGER", "tap_at-er jonno"))
            .put("target", prop("STRING", "preview_tap-er jonno target-er naam"))
            .put("corner", prop("STRING", "tap_corner-er jonno"))
            .put("page", prop("STRING", "open_settings-er jonno"))
            .put("append", prop("BOOLEAN", "type_text-er jonno"))
            .put("package", prop("STRING", "install_app-er jonno"))
            .put("name", prop("STRING", "install_app-er jonno, app-er naam"))
            .put("max", prop("INTEGER", "scroll_find-er jonno"))
            .put("tap", prop("BOOLEAN", "scroll_find-er jonno"))
            .put("tile", prop("STRING", "quick_toggle-er jonno"))
            .put("on", prop("BOOLEAN", "quick_toggle / torch-er jonno"))
            .put("percent", prop("INTEGER", "set_volume-er jonno"))
        val item = JSONObject()
            .put("type", "OBJECT")
            .put("properties", props)
            .put("required", JSONArray().put("tool"))
        return Param(
            "steps",
            JSONObject()
                .put("type", "ARRAY")
                .put("description", "Ek-er por ek chalano step-er list (max 20). Kono step fail korle thame.")
                .put("items", item),
            true
        )
    }

    fun declarations(blocking: Boolean = true): JSONArray = JSONArray()
        // ---- calls, messages, apps
        .put(fn("call_contact", "Kono contact-ke naam diye ba number diye call kore.", blocking,
            s("name_or_number", "Contact-er naam (jemon Rahul) ba phone number")))
        .put(fn("send_sms", "Kono contact ba number-e SMS pathay.", blocking,
            s("to", "Contact-er naam ba phone number"),
            s("message", "SMS-er lekha, user ja bolechhe")))
        .put(fn("open_app", "Phone-e install kora kono app kholay.", blocking,
            s("app_name", "App-er naam, jemon WhatsApp, Camera, YouTube, Spotify")))
        .put(fn("list_apps", "Phone-e launch kora jay emon installed app-er exact naam o package list kore. App-er naam niye uncertainty thakle use koro; query optional.", blocking,
            s("query", "Naam ba package-er angsho diye filter; khali hole shob launchable app", required = false)))
        .put(fn("open_url", "Kono website ba link browser/app-e kholay.", blocking,
            s("url", "Puro link, jemon https://www.google.com")))
        .put(fn("play_youtube", "YouTube-e video/gaan sathe sathe chalay (search kore prothom video chalu kore dey). Gaan ba video chaile eta-i shobcheye druto, ar kono tap lage na.", blocking,
            s("query", "Gaan ba video-r naam")))
        .put(fn("play_media", "Spotify ba YouTube Music-e gaan chalay. app na dile YouTube search khole.", blocking,
            s("query", "Gaan ba video-r naam"),
            s("app", "youtube, youtube_music ba spotify. Na dile youtube", required = false)))
        // ---- screen control (needs Accessibility)
        .put(fn("read_screen", "Ekhon screen-e ki ki dekha jachhe tar numbered list dey (text, tap kora jabe kina). Kono tap/type kora-r age eta chalao.", blocking))
        .put(fn("look_screen", "Screen-er asol chhobi dekhe (screenshot). Game, chhobi, icon, label-hin button, kono kichu read_screen-e na pele ba bujhte na parle AGE eta chalao. Uncertain chhoto target-e preview_tap diye marker dekhiye approval nao.", blocking))
        .put(fn("game_mode", "Game ba onno je app-e screen-er text pawa jay na (game, canvas) sekhane CHALU koro: prottek second-e screen-er chhobi tomar kache ashbe, tumi live dekhte parbe. Game-e dhukle ba user game-e kichu korte bolle SOBAR AGE eta chalao. Game sesh hole on=false.", blocking,
            b("on", "true chalu, false bondho"),
            s("game", "Game-er naam, jemon 'FC Mobile'. Control save kora thake ei naam-e", required = false)))
        .put(fn("save_control", "Game-er stick ba button-er jaygay mone rakhe (percent, screen-er chhobi theke). Prothombar dekhe save koro, porer bar nijei paabe. Naam: stick, pass, through, shoot, lob, sprint, skill, tackle, switch ityadi.", blocking,
            s("name", "Control-er naam"),
            n("x", "bam theke 0-100 percent"),
            n("y", "upor theke 0-100 percent"),
            s("kind", "stick (joystick) ba button", required = false)))
        .put(fn("game_act", "Ekshathe ekadhik angul diye game/screen-e kaj kore, ekta call-e: stick chhere rekhe button chapa, druto porpor tap, swipe. Prottek action-e: control (save kora naam) ba x,y percent; dir (stick-er jonno: up, down, left, right, up_left, up_right, down_left, down_right); hold_ms; at_ms (kokhon shuru, 0 theke); to_x,to_y (swipe). Max 10 ta action.", blocking,
            Param("actions", JSONObject().put("type", "ARRAY").put("description", "Action-er list").put("items", JSONObject().put("type", "OBJECT").put("properties", JSONObject()
                .put("control", prop("STRING", "Save kora control-er naam, jemon stick, pass, shoot"))
                .put("x", prop("NUMBER", "bam theke percent, control na dile"))
                .put("y", prop("NUMBER", "upor theke percent, control na dile"))
                .put("dir", prop("STRING", "stick-er dik"))
                .put("hold_ms", prop("INTEGER", "koto ms chepe thakbe"))
                .put("at_ms", prop("INTEGER", "kokhon shuru hobe, ms"))
                .put("to_x", prop("NUMBER", "swipe-er shesh x percent"))
                .put("to_y", prop("NUMBER", "swipe-er shesh y percent")))), true)))
        .put(fn("wait_until", "User bolle 'ei kaj-ta cholche, ota hoye gele/ashle bolo', 'nojor rakho', 'jotokkhon na hoy opekkha koro': screen-e kono text ashle (ba chole gele) tokhon porjonto background-e nojor rakhe, tarpor nijei janay. Tumi sathe sathe onno kaj korte paro.", blocking,
            s("text", "Je lekha screen-e ashar ba chole jawar opekkhay (jemon 'Download complete', 'Done', 'Connected')"),
            b("gone", "true hole oi lekha chole gele janabe, noile ashle", required = false),
            i("minutes", "Koto minute porjonto nojor rakhbe, default 10, max 120", required = false)))
        .put(fn("watch_visual", "Screen-e kichu hobe ki na chhobi dekhe nojor rakhe (jeta lekha na, jemon game-e goal, video sesh, loading sesh). Prottek kichu second-e chhobi dekhe, hole janabe. Text ashle wait_until beshi bhalo.", blocking,
            s("what", "Ki hole janabe, sposhto kore"),
            i("minutes", "Koto minute, default 10, max 30", required = false)))
        .put(fn("stop_watch", "Chalu nojor rakha shob bondho kore.", blocking))
        .put(fn("copy_text", "Kono lekha clipboard-e copy kore rakhe (nijer lekha ba bola kotha).", blocking,
            s("text", "Ja copy korbe")))
        .put(fn("copy_from_screen", "Screen theke lekha copy kore. query dile oi lekha-wala jinis-er puro text, na dile selected ba text box-er lekha.", blocking,
            s("query", "Screen-e je lekha khujbe (khali rakhle selected/focus-kora box)", required = false)))
        .put(fn("paste_clip", "Copy kora lekha ekhon jei text box-e focus ache sekhane boshay. index dile age oi box-e tap kore.", blocking,
            i("index", "read_screen-er textbox-er i number", required = false),
            b("append", "true hole age-er lekhar pore jore", required = false)))
        .put(fn("get_clip", "Clipboard-e ki copy kora ache ta pore.", blocking))
        .put(fn("tap_text", "Screen-e dekha jachhe emon kono text ba button-e tap kore.", blocking,
            s("text", "Je lekha ba button-er naam-e tap korbe")))
        .put(fn("tap_index", "read_screen-er list-er i number-er element-e tap kore.", blocking,
            i("index", "read_screen-er i number")))
        .put(fn("tap_at", "Screen-er kono jaygay tap kore, jaygata percent-e (read_screen-er 'at' dekho). Label-hin icon, chhobi, game ba tap_text/tap_index kaj na korle eta. hold_ms 600+ dile chepe dhore (long press).", blocking,
            n("x", "bam theke 0-100 percent, dashomik dite paro (jemon 63.5), look_screen-er chhobi-te jetuku dekhcho sheta thik"),
            n("y", "upor theke 0-100 percent, dashomik dite paro (jemon 41.2)"),
            i("hold_ms", "koto ms chepe dhorbe, default 70", required = false)))
        .put(fn("preview_tap", "look_screen-er latest screenshot dekhe target-er x,y percent ber koro. Tap-er age full-screen marker + Approve/Cancel overlay dekhabe. User Approve korlei tap hobe; Cancel/timeout hole kono tap noy. Destructive, send, payment ba privacy-sensitive action-e confirmation chara kokhono tap koro na.", blocking,
            n("x", "screenshot-er bam theke 0-100 percent"),
            n("y", "screenshot-er upor theke 0-100 percent"),
            s("target", "Kon visible control-e tap korte chao")))
        .put(fn("tap_send", "Chat composer-er send/submit button khuje tap kore. Message age type/paste kora thakte hobe. Tap-er por screen state verify kore; message sent hoyeche bole dhore ney na.", blocking))
        .put(fn("tap_corner", "Screen-er corner-er chhoto unlabeled icon tap kore. corner: top_left, top_right, bottom_left, bottom_right. Age look_screen/read_screen diye thik corner confirm koro.", blocking,
            s("corner", "top_left, top_right, bottom_left ba bottom_right")))
        .put(fn("type_text", "Text box-e lekha boshay, lomba lekha-o (HTML, chithi, note). index dile age oi box-e tap kore, na dile ja focus kora ache. append true hole age-er lekhar pore jore.", blocking,
            s("text", "Ja likhbe"),
            i("index", "read_screen-er textbox-er i number", required = false),
            b("append", "true hole age-er lekhar pore jore, noile bodle dey", required = false)))
        .put(fn("scroll_find", "Scroll kore kono text khuje bar kore, chaile tap-o kore. Lomba list-e (Settings, app list) dorkari option khujte.", blocking,
            s("text", "Ja khujbe"),
            s("direction", "down (default) ba up", required = false),
            i("max", "koto bar scroll, default 6", required = false),
            b("tap", "true hole peye tap korbe", required = false)))
        .put(fn("wait_for_text", "Screen-e kono text na ashar age porjonto opekkha kore (max 15 second). App load howar jonno wait-er cheye bhalo.", blocking,
            s("text", "Je text ashar opekkha"),
            i("seconds", "max koto second", required = false)))
        .put(fn("install_app", "Play Store theke app install kore (Install button porjonto nijei chape). Package name jana thakle dao, tahole thik app-i install hoy.", blocking,
            s("name", "App-er naam"),
            s("package", "Package name, jemon com.whatsapp. Na jana thakle dio na", required = false)))
        .put(fn("press_key", "Phone-er button chapay. key: back, home, recents, enter (search/submit), notifications, quick_settings, lock, screenshot.", blocking,
            s("key", "back, home, recents, enter, notifications, quick_settings, lock ba screenshot")))
        .put(fn("swipe", "Screen scroll ba swipe kore. direction: down (niche-r content dekhte), up (upore-r), left (porer page), right (ager page).", blocking,
            s("direction", "down, up, left ba right")))
        .put(fn("drag", "Ek jaygar theke arek jaygay angul tene ney (percent-e): slider, jinish soranor jonno. duration_ms default 400.", blocking,
            i("x1", "shuru: bam theke 0-100"),
            i("y1", "shuru: upor theke 0-100"),
            i("x2", "shesh: bam theke 0-100"),
            i("y2", "shesh: upor theke 0-100"),
            i("duration_ms", "koto ms, default 400", required = false)))
        .put(fn("pinch", "Duto angul diye zoom kore (map, chhobi, page). direction: in (boro korbe) ba out (chhoto korbe).", blocking,
            s("direction", "in ba out")))
        .put(fn("text_edit", "Jei text box-e focus ache tate select_all, copy, cut, paste ba clear kore.", blocking,
            s("action", "select_all, copy, cut, paste ba clear")))
        .put(fn("long_press", "Screen-e likha kono jinish chepe dhore (menu, text select, icon tola).", blocking,
            s("text", "jar upor chepe dhorbe tar text ba description")))
        .put(fn("wait", "Kichu somoy opekkha kore, jemon app load hotey.", blocking,
            i("seconds", "1 theke 8 second", required = false),
            i("ms", "millisecond, 100 theke 8000", required = false)))
        .put(fn("quick_toggle", "Quick settings theke wifi, bluetooth, airplane, data, hotspot, rotate, dnd, location, battery_saver ba dark_mode on/off kore. Ek call-eii hoye jay.", blocking,
            s("tile", "wifi, bluetooth, airplane, data, hotspot, rotate, dnd, location, battery_saver ba dark_mode"),
            b("on", "true hole on, false hole off. Na dile ulte dey", required = false)))
        .put(fn("do_steps", "Onek step ek-shathe chalay, model-er sathe ghure ashte hoy na, tai druto. Je kaj-er step gulo age theke jana (jemon app kholo, search-e tap, likho, enter), shob ek call-e dao. Screen ki dekhabe na jana thakle eta noy, read_screen dao.", blocking,
            stepsParam()))
        .put(fn("read_notifications", "Ekhon phone-e thaka notification-er list dey (id, app, kon dhoroner, lekha). User jiggesh korle 'ki ki notification ache' ba kono message porte.", blocking,
            i("limit", "koto-ta, default 8", required = false),
            s("app", "optional: sudhu ei app-er (jemon WhatsApp)", required = false)))
        .put(fn("dismiss_notification", "Notification uriye dey. id dile oi-ta, 'junk' dile shob faltu, 'all' dile shob.", blocking,
            s("id", "read_notifications ba [NOTIFICATION]-er id, 'junk' ba 'all'")))
        .put(fn("reply_notification", "WhatsApp, Telegram, SMS-er notification theke sorasori reply pathay, app khulte hoy na. User ja bolechhe tai pathao.", blocking,
            s("id", "notification-er id"),
            s("text", "Reply-er lekha")))
        .put(fn("open_notification", "Kono notification-er app/chat khole dey.", blocking,
            s("id", "notification-er id")))
        .put(fn("research", "Web-e khuje uttor ber kore BACKGROUND-e. Sathe sathe return kore, tumi tomar kaj ba gollpo cholte paro; uttor eshe gele [TASK DONE] hishebe janabe, tokhon user-ke bolo. Boro ba somoy lage emon khoja (tulona, details, report) hole eta use koro. Choto prosno hole nijei search kore bolo.", blocking,
            s("question", "Ki khujbe, sompurno prosno")))
        .put(fn("make_plan", "User ekshathe ekadhik kaj bolle (ba boro kaj hole) SOBAR AGE eta chalao: shob kaj-er ordered list banay ar mone rakhe. Prottek tool-er result-e 'PLAN LEFT' dekhabe, tai kono kaj bhulbe na. Kaj shuru kora-r age chalao.", blocking,
            Param("tasks", JSONObject().put("type", "ARRAY").put("description", "Kaj-er list, ordered, prottek ta ek line-e, spasto bhabe")
                .put("items", JSONObject().put("type", "STRING")), true)))
        .put(fn("finish_step", "Plan-er ekta kaj sesh hole chinhito kore. number dao (1 theke) ba kaj-er naam-er ekta ongsho. Prottek kaj ses hole chalao, tahole bakigulo mone thakbe.", blocking,
            i("number", "Plan-er kaj-er number, 1 theke", required = false),
            s("text", "Naam-er ongsho (number na dile)", required = false)))
        .put(fn("show_plan", "Ekhon plan-e ki ki baki ache ar ki hoye geche dekhay.", blocking))
        .put(fn("queue_task", "Screen-er kono kaj (steps-er list) BACKGROUND queue-te rekhe sathe sathe return kore. Ager kaj sesh hole nijei chalabe, sesh hole [TASK DONE] hishebe janabe. User jokhon ekshathe onek kaj bole ba tumi ekta kaj korcho ar user ar ekta chay, tokhon eta use koro.", blocking,
            s("title", "Kaj-er choto naam"),
            stepsParam()))
        .put(fn("save_routine", "Ekta kaj-er step-er list nam diye mone rekhe dey, jate porer bar ek call-e (run_routine) hoye jay. Jokhon user ekta kaj bar bar kore ba shikhiye dey, tokhon save koro.", blocking,
            s("name", "Choto naam, jemon 'morning', 'movie night', 'wifi reset'"),
            stepsParam()))
        .put(fn("run_routine", "Age save kora routine ek call-e chalay. Shobcheye druto.", blocking,
            s("name", "Routine-er naam")))
        // ---- device
        .put(fn("open_settings", "Phone-er settings page ba panel kholay. page: wifi, internet, bluetooth, display, sound, volume, location, battery_saver, airplane, nfc, accessibility, apps, date, settings.", blocking,
            s("page", "wifi, internet, bluetooth, display, sound, volume, location, battery_saver, airplane, nfc, accessibility, apps, date ba settings")))
        .put(fn("torch", "Phone-er torch/flashlight on ba off kore.", blocking,
            b("on", "true hole on, false hole off")))
        .put(fn("set_volume", "Volume theek kore. stream: media (default), ring, alarm.", blocking,
            i("percent", "0 theke 100"),
            s("stream", "media, ring ba alarm", required = false)))
        .put(fn("set_alarm", "Alarm set kore.", blocking,
            i("hour", "24 ghontar hishebe ghonta, 0-23"),
            i("minute", "minute, 0-59"),
            s("label", "Alarm-er naam", required = false)))
        .put(fn("set_timer", "Timer set kore.", blocking,
            i("seconds", "koto second-er timer"),
            s("label", "Timer-er naam", required = false)))
        .put(fn("device_info", "Ekhonkar somoy, tarikh, battery koto percent ar charge hochhe kina bole.", blocking))
        .put(fn("get_location", "Phone ekhon kothay: thikana, map link, koto-ta thik, chalche kina. User 'ami kothay', 'kache ki ache', 'location pathao' bolle.", blocking))
        .put(fn("location_status", "Location on kina, Mishti-r permission, ar kon kon app tomar location shob shomoy ba shudhu khola thakle dekhte pare. 'Keu track korche?' 'kon app location nichhe' bolle.", blocking))
        .put(fn("stop_task", "User 'ruko', 'stop', 'thamo', 'cancel' bolle: queue-te thaka ar cholte thaka background kaj gulo bondho kore.", blocking))
        // ---- memory and session
        .put(fn("remember", "User-er kono dorkari kotha (naam, pochhondo, ma-er number-er naam ityadi) mone rakhe, porer bar-o mone thakbe.", blocking,
            s("note", "Ek line-e ja mone rakhbe")))
        .put(fn("learn_habit", "User-er abhyash/ruti mone rakhe (kokhon ki kore, ki pochhondo, kemon bhabe kaj chay). Nijei dhore felle ba o bolle chalao, jemon 'raate gaan shune ghumay', 'shokale news dekhe'.", blocking,
            s("habit", "Ek line-e abhyash")))
        .put(fn("teach_lesson", "User tomake kichu shikhale ba bhul sodhale ('ei kajta emon kore koro', 'ar eta korbe na', 'amake agey jiggesh koro') ei niyom ta sthayi bhabe shikhe rakhe, porer bar theke mane cholbe.", blocking,
            s("rule", "Niyom, ek line-e, 'jokhon X tokhon Y koro' dhoroner")))
        .put(fn("recall", "Tomar mone rakha shob (fact, abhyash, niyom, ki beshi use kore) khuje dey. User 'amar kotha ki mone ache', 'ami ki pochhondo kori' bolle ba kono kaj-er age dekhte.", blocking,
            s("query", "Ki khujbe, khali rakhle shob", required = false)))
        .put(fn("forget", "Mone rakha kono kotha mushe dey.", blocking,
            s("keyword", "Je note-e ei shobdo ache seta mushbe")))
        .put(fn("standby", "Mic bondho kore chup kore thake. User bolle 'chup thako', 'standby' ba onno app-e gaan/video-r jonno mic bondho korte chaile. User notification-er Listen button tipe abar dakbe.", blocking))
        .put(fn("sleep", "Mishti-ke bishram-e pathay: internet bondho, kintu 'Hey Mishti' bolle abar nijei jege uthbe, app-e giye kichu korte hobe na. User jokhon bole 'Mishti ekhon tumi rakhte paro', 'thak', 'bishram nao', 'ghumao', 'ar lagbe na', 'thanks bye' ityadi. Age ekta chhoto mishti bidai bolo (raat 8-12-r moddhe hole 'Shubho ratri' bole), tarpor eta chalao, tarpor ar kichu bolbe na.", blocking))
        .put(fn("end_session", "Mishti-ke EKDOM off kore (mic-o bondho, 'Hey Mishti' bolleo jagbe na). Shudhu tokhon, jokhon user sposhto bole 'ekdom bondho koro', 'power off', 'puro off kore dao'. Age bidai bolo.", blocking))
}
