# Mishti

Android voice assistant. Kotlin + Jetpack Compose, Gemini Live voice-to-voice.
Package: com.mishti.assistant

## Build on GitHub (no Android Studio needed)
1. Make a new GitHub repo and upload everything in this folder, including the hidden `.github` folder.
2. Push to `main`. Open the **Actions** tab. If the run has not started, open **Build Mishti APK** and press **Run workflow**.
3. When it turns green, open the run, download the **Mishti-debug-apk** artifact, unzip it and install `app-debug.apk`.

## First run
1. Open the app, tap the gear icon (top right) -> paste your Gemini API key (aistudio.google.com) -> Save.
2. Tap the white waveform button and talk. Allow the microphone when asked.

The key is stored only on the phone. If the connection fails with a model error, put the current Live model
name from AI Studio into Settings -> Model.

## Android Studio (optional)
Open the folder, let Gradle sync, run. You can also put `GEMINI_API_KEY=...` in `local.properties` as a fallback.

## Steps
1. Voice chat, Claude-style UI, Settings
2. Phone control: call, SMS, open apps
3. Background service, Accessibility screen control, play media, torch, volume, alarm, timer, memory, Google search
4. v05: gemini-3.8-live default, orb voice screen, always-on listening (auto reconnect, wake lock), text chat is silent,
   fast tools (play_youtube, quick_toggle, do_steps), click/scroll through real accessibility actions,
   language / listening / battery options in Settings 

## Updating
Upload the new `mishti_vNN.zip` to the repo. The workflow unzips the newest one and builds it.
Builds are signed with the fixed `debug.keystore`, so a new APK installs over the old one and keeps your settings.
5. v06: one steady sweet persona and voice, Bangla/Hindi never mixed, device watcher (battery, heat, storage, RAM, internet), install_app, scroll_find, wait_for_text, long text into notes (this version)
6. v07: persona rewritten in English with Bangla/Hindi script examples, language hint, new default voice Sulafat (this version)
7. v08: voice back to Aoede, bottom glow on voice screen, tap_at + richer read_screen (ids, switch state, positions) (this version)
8. v09: screen-edge breathing glow while working, routines (save_routine/run_routine), latest-info search on by default, spontaneous chat, premium textured UI, faster taps (this version)
9. v10: softer, lower, slower voice (playback pitch and speed in Settings), deeper girlfriend role-play (this version)
10. v11: realistic human-female speech style in the persona (this version)
11. v12: thinner, softer rounded-corner edge glow (this version)
12. v13: Hey Mishti wake mode (voice-gated, boot note), background research and queued tasks with results, softer thinner voice (this version)
13. v14: Mishti rests by voice and wakes by herself on Hey Mishti, session closes when idle (this version)
14. v15: notification access (announce messages, read important ones, clear junk, reply from notification) (this version)
15. v16: offline "Hey Mishti" listener (Vosk) wakes her fully from off, resting or lockscreen; off/rest returns to waiting (this version)
- v17: notun UI (3D glass orb, liquid glass typing bar, voice section only orb+mute+stop)
- v18: English UI, Bangla/Hindi only, glass settings, orb like reference
- v19: notification fixes (rebind, richer read, fallback by sight), in-app Notifications inbox
- v20: voice polish (EQ, loudness, limiter), tone and loudness settings
- v21: liquid glass (no blur) surfaces
- v22: liquid animations (press spring, sliding thumb, ripples, entrances, drifting liquid background)
- v23: speed pass (VAD 200ms, shorter UI waits, smaller playback buffer, quick pace, SPEED persona rules)
- v24: fix compile error (drawOutline)
- v25: brighter voice + never male voice, new screen tools (drag, pinch, long_press, text_edit)
- v26: minimal settings (key, language, voice), respectful boss/aap persona, location tools + permission
- v27: Voice ID (only owner voice, on/off + enroll in Settings), stop_task live control
- v28: Voice ID removed; look_screen (live screenshot to Gemini), copy/paste tools, careful control rules, faster turn-taking
- v29: brain (habits, lessons, usage learning, recall), situation rulebook in persona, faster turn-taking
- v30: make_plan checklist (multi-task never forgotten, PLAN_LEFT in every result)
- v31: faster screen actions (shorter waits), conversation-intelligence rules
- v32: softer sweet tone and human feel (persona only)
- v33: borderless flowing orb, status line under orb, Settings cards restored, daily greetings + good night, respect rules
- v34: crystal-clear animated liquid inside glass (waves, bubbles, glint), no blur
- v35: whole UI liquid glass (one shared clock), no blur
- v36: own app icon (glass orb) instead of orange sunburst
- v37: app icon from the user's picture
- v38: removed wave lines and bubbles from glass; clean drifting light only
- v39: accurate taps (real screen size, decimals, safe tap_index), faster (no hidden thinking), silent work, no unasked instructions, sharper icon
- v40: icon fills the whole rounded-square (full bleed)
- v41: floating orb over all apps (tap: Stop, Mute, Hide), stronger bottom glow
- v42: game mode (live frames each second), game_act multi-finger gamepad, save_control, FC Mobile knowledge
- v43: task nudge ([CONTINUE]) so no task is dropped, wait_until/watch_visual, auto-save remember
- v44: richer voice delivery details, human response style
- v45: (Voice ID gate, removed again in v46)
- v46: FINAL: Voice ID removed, glow always switches off, tap tells if the screen reacted, never-say-cannot rules


## v47 upgrade blueprint and changes
- Screen interaction: added `tap_send` for a best-effort semantic send/submit control lookup, with a conservative lower-right fallback. It does not type or send content by itself. Mishti must verify the resulting chat state before reporting success.
- Corner controls: added `tap_corner` for small unlabeled controls in top-left, top-right, bottom-left, or bottom-right. Use only after visually confirming the target corner; ambiguous layouts still require `look_screen` plus `tap_at`.
- Emotional intelligence: persona now adapts conversational pacing and phrasing to clear mood cues, avoids claiming certainty about feelings, listens before advising, and avoids guilt or pressure.
- Proactive assistance: limited to useful, low-frequency, permission-aware alerts and reminders. Sensitive or consequential actions require confirmation.
- Voice modulation: existing Gemini voice selection plus local pitch/speed/EQ/gain controls remain in place. v47 improves prosody instructions (pauses, emphasis, melody) rather than pretending post-processing can create genuine emotional expression. Actual voice quality and expressive range depend on the selected Gemini Live voice/model.
- Reliability: screen actions are snapshot-driven; after taps, verify visible state. Do not blindly retry send/post/delete actions.

### Suggested next-stage roadmap
1. Add an in-app voice profile panel with natural / warm / calm / energetic presets and safe pitch/speed bounds.
2. Add explicit mood/context state with user-correctable preferences and a clear reset control.
3. Add a quiet-hours and proactive-alert schedule with per-category opt-in.
4. Add screenshot-assisted target selection overlay so the user can confirm a button before a tap.
5. Add device/app compatibility tests for chat composer, send icons, overflow menus, back buttons, and floating controls across common Android apps.

Build remains the same: upload this project to GitHub and download the `Mishti-debug-apk` artifact from Actions. Version 0.47 uses the existing debug signing key and package ID.


## v0.48 improvements

- Added `list_apps` tool to discover launchable installed apps by label or package-name fragment.
- Expanded the Mishti persona instructions for contextual continuity, cautious preference learning, empathetic uncertainty handling, permission-aware proactive help, and verified device actions.
- Clarified Android app-automation boundaries: accessibility and intents can automate supported visible flows, but cannot guarantee unrestricted control of every third-party app or protected screen.
- Version bumped to 0.48 (versionCode 48).


## v0.49 Visual Intelligence
- Added `preview_tap(x, y, target)`: displays a dimmed full-screen overlay with a crosshair at the proposed target and explicit Approve / Cancel buttons. The tap is dispatched only after the user approves. Cancel and timeout perform no action.
- Added tool-schema and `do_steps` support for `preview_tap`.
- Updated the screen-control persona to prefer approval previews for uncertain, small, unlabeled controls after a fresh `look_screen` snapshot.
- Bumped Android version to 0.49 (versionCode 49).
- This is coordinate-assisted visual interaction, not autonomous object detection: Gemini must inspect `look_screen` and supply the target coordinates. Protected screens and apps that block screenshots/accessibility remain unsupported.
