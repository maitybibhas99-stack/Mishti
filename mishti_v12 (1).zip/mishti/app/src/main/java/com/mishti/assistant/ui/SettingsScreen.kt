package com.mishti.assistant.ui

import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mishti.assistant.BuildConfig
import com.mishti.assistant.MishtiAccessibilityService
import com.mishti.assistant.Prefs
import kotlinx.coroutines.delay

// Female-sounding voices first. The Live model decides which ones it really supports.
private val VOICES = listOf(
    "Aoede", "Sulafat", "Vindemiatrix", "Achernar", "Leda", "Kore",
    "Zephyr", "Callirhoe", "Autonoe", "Despina", "Erinome", "Laomedeia"
)

@Composable
fun SettingsScreen(prefs: Prefs, onSaved: () -> Unit, onBack: () -> Unit) {
    var key by remember { mutableStateOf(prefs.typed("api_key")) }
    var showKey by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(prefs.typed("model")) }
    var voice by remember { mutableStateOf(prefs.voice) }
    var name by remember { mutableStateOf(prefs.userName) }
    var silence by remember { mutableStateOf(prefs.silenceMs) }
    var webSearch by remember { mutableStateOf(prefs.webSearch) }
    var language by remember { mutableStateOf(prefs.language) }
    var nameOnly by remember { mutableStateOf(prefs.nameOnly) }
    var bargeIn by remember { mutableStateOf(prefs.bargeIn) }
    var noisy by remember { mutableStateOf(prefs.noisyRoom) }
    var watch by remember { mutableStateOf(prefs.deviceWatch) }
    var pitch by remember { mutableStateOf(prefs.voicePitch) }
    var pace by remember { mutableStateOf(prefs.voiceSpeed) }
    var chatter by remember { mutableStateOf(prefs.spontaneous) }
    var noteCount by remember { mutableStateOf(prefs.notes.size) }
    val context = LocalContext.current
    var accOn by remember { mutableStateOf(MishtiAccessibilityService.instance != null) }
    var overlayOn by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    val power = remember { context.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager }
    var batteryFree by remember { mutableStateOf(power.isIgnoringBatteryOptimizations(context.packageName)) }
    LaunchedEffect(Unit) {
        while (true) {
            accOn = MishtiAccessibilityService.instance != null
            overlayOn = Settings.canDrawOverlays(context)
            batteryFree = power.isIgnoringBatteryOptimizations(context.packageName)
            delay(1000)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .auroraBackground()
            .systemBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MishtiColors.Text)
            }
            Text(
                "Settings",
                color = MishtiColors.Text,
                fontFamily = FontFamily.Serif,
                fontSize = 22.sp,
                modifier = Modifier.padding(start = 6.dp)
            )
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Label("Tomar naam (optional)")
            Field(name, { name = it }, "Jemon: Bibhas")

            Label("Gemini API key")
            Field(
                key,
                { key = it },
                "AIza...",
                visual = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardType = KeyboardType.Password
            )
            Text(
                if (showKey) "Lukao" else "Dekhao",
                color = MishtiColors.Coral,
                fontSize = 14.sp,
                modifier = Modifier
                    .padding(top = 8.dp)
                    .clickable { showKey = !showKey }
            )
            Hint("aistudio.google.com theke free key nao. Key shudhu ei phone-e thake, Google chhara kothao jay na.")

            Label("Model (khali rakhle default)")
            Field(model, { model = it }, BuildConfig.GEMINI_MODEL)
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VoiceChip("3.8 live (notun, fast)", model.isBlank() || model == "gemini-3.8-live", Modifier.weight(1f)) {
                    model = ""
                }
                VoiceChip("3.1 flash live", model == "gemini-3.1-flash-live-preview", Modifier.weight(1f)) {
                    model = "gemini-3.1-flash-live-preview"
                }
            }
            Hint("Default: gemini-3.8-live, shobcheye notun ar fast. Connection-e model error ashle AI Studio-te Live model-er notun naam dekhe ekhane boshao.")

            Label("Bhasha")
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Auto" to "auto", "Bangla" to "bangla", "Hindi" to "hindi", "English" to "english").forEach { (label, code) ->
                    VoiceChip(label, language == code, Modifier.weight(1f)) { language = code }
                }
            }
            Hint("Bangla ba Hindi beche nile Mishti shudhu oi bhashay bolbe, mishabe na. Auto-te tumi jei bhashay bolbe oi bhashay uttor dey.")

            Label("Voice")
            VOICES.chunked(3).forEach { row ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { v ->
                        VoiceChip(v, v == voice, Modifier.weight(1f)) { voice = v }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }

            Label("Gola-r sur (pitch)")
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Normal" to 1.0f, "Komol" to 0.93f, "Aro komol" to 0.87f).forEach { (label, v) ->
                    VoiceChip(label, kotlin.math.abs(pitch - v) < 0.01f, Modifier.weight(1f)) { pitch = v }
                }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Normal" to 1.0f, "Dhire" to 0.96f, "Aro dhire" to 0.90f).forEach { (label, v) ->
                    VoiceChip(label, kotlin.math.abs(pace - v) < 0.01f, Modifier.weight(1f)) { pace = v }
                }
            }
            Hint("Komol + Dhire: ghum theke ota norom, soru gola. Save-er por Mishti off kore abar on korle kaj korbe.")

            Label("Reply speed")
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Fast" to 300, "Normal" to 500, "Relaxed" to 800).forEach { (label, ms) ->
                    VoiceChip(label, silence == ms, Modifier.weight(1f)) { silence = ms }
                }
            }
            Hint("Fast: tumi thamle sathe sathe uttor ashe. Beshi fast hole majhe majhe tomar kotha kete jete pare.")

            Label("Shona")
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VoiceChip("Shobshomoy", !nameOnly, Modifier.weight(1f)) { nameOnly = false }
                VoiceChip("'Mishti' bolle", nameOnly, Modifier.weight(1f)) { nameOnly = true }
            }
            Hint("'Mishti' bolle: naam dhore dakle tobei uttor dey. Pichoner gaan ba onno manusher kotha-y chup thake.")
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VoiceChip("Normal mic", !noisy, Modifier.weight(1f)) { noisy = false }
                VoiceChip("Gondogol jaygay", noisy, Modifier.weight(1f)) { noisy = true }
            }
            Hint("Gondogol jaygay: spasto gola chhara shuru hobe na, tai pichoner shobdo-e kom bhul hoy.")
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VoiceChip("Kotha kete bolte pari", bargeIn, Modifier.weight(1f)) { bargeIn = true }
                VoiceChip("Shesh hole bolbo", !bargeIn, Modifier.weight(1f)) { bargeIn = false }
            }
            Hint("Prothom option: Mishti bolar majhe tumi bolle se thame. Echo hole dwitiyo option-ta try koro.")

            Label("Phone-er khobor rakha")
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VoiceChip("Off", !watch, Modifier.weight(1f)) { watch = false }
                VoiceChip("On", watch, Modifier.weight(1f)) { watch = true }
            }
            Hint("On thakle battery kom, phone gorom, storage bhora, RAM kom ba internet gele Mishti nijei bole dey ar ki korbe jiggesh kore.")

            Label("Mishti nijei kotha bole")
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VoiceChip("Off", !chatter, Modifier.weight(1f)) { chatter = false }
                VoiceChip("On", chatter, Modifier.weight(1f)) { chatter = true }
            }
            Hint("On thakle tumi onek khon chup thakle Mishti nijei duto mishti kotha bole (shokal 8 theke raat 12-r moddhe).")

            Label("Google search (latest khobor, weather, score)")
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VoiceChip("Off", !webSearch, Modifier.weight(1f)) { webSearch = false }
                VoiceChip("On", webSearch, Modifier.weight(1f)) { webSearch = true }
            }
            Hint("On thakle Mishti latest khobor ar jankari nijei khuje ane. Connection-e error ashle Off kore dekho.")

            Label("Accessibility (screen control)")
            StatusLine(accOn, "Chalu ache", "Bondho")
            PillButton("Accessibility settings kholo") {
                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            Hint("Okhane Mishti-te giye On koro. Android 13+-e on korar option grey thakle: App info kholo, upore-r ⋮ menu theke 'Allow restricted settings' dao, tarpor abar On koro.")
            PillButton("App info kholo") {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                )
            }

            Label("Display over other apps")
            StatusLine(overlayOn, "Chalu ache", "Bondho")
            PillButton("Ei permission dao") {
                context.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                )
            }
            Hint("Onno app khola thakle Mishti-ke notun app kholar jonno ei permission lage.")

            Label("Background-e shobshomoy chalu")
            StatusLine(batteryFree, "Battery restriction nei", "Battery restriction ache")
            PillButton("Battery restriction bondho koro") {
                try {
                    context.startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${context.packageName}"))
                    )
                } catch (e: Exception) {
                    context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
            Hint("Na dile kichu phone (Xiaomi, Oppo, Vivo, Samsung) onek khon por Mishti-ke bondho kore dey. Dile background-e shunte thakbe.")

            Label("Mishti ja mone rekhechhe")
            Text(
                if (noteCount == 0) "Kichu na" else "$noteCount ta kotha",
                color = MishtiColors.TextDim,
                fontSize = 14.sp
            )
            if (noteCount > 0) {
                Spacer(Modifier.height(8.dp))
                PillButton("Sob bhule jao") {
                    prefs.clearNotes()
                    noteCount = 0
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Color.White)
                .clickable {
                    prefs.apiKey = key
                    prefs.model = model
                    prefs.voice = voice
                    prefs.userName = name
                    prefs.silenceMs = silence
                    prefs.webSearch = webSearch
                    prefs.language = language
                    prefs.nameOnly = nameOnly
                    prefs.bargeIn = bargeIn
                    prefs.noisyRoom = noisy
                    prefs.deviceWatch = watch
                    prefs.spontaneous = chatter
                    prefs.voicePitch = pitch
                    prefs.voiceSpeed = pace
                    onSaved()
                }
                .padding(vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Save", color = Color.Black, fontSize = 16.sp)
        }
    }
}

@Composable
private fun Label(t: String) {
    Text(t, color = MishtiColors.Text, fontSize = 15.sp, modifier = Modifier.padding(top = 22.dp, bottom = 8.dp))
}

@Composable
private fun Hint(t: String) {
    Text(t, color = MishtiColors.TextDim, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    visual: VisualTransformation = VisualTransformation.None,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    val shape = RoundedCornerShape(16.dp)
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        visualTransformation = visual,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        textStyle = TextStyle(color = MishtiColors.Text, fontSize = 16.sp),
        cursorBrush = SolidColor(MishtiColors.Coral),
        modifier = Modifier.fillMaxWidth(),
        decorationBox = { inner ->
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(MishtiColors.Surface, shape)
                    .border(1.dp, MishtiColors.SurfaceHigh, shape)
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                if (value.isEmpty()) Text(placeholder, color = MishtiColors.TextDim, fontSize = 16.sp, maxLines = 1)
                inner()
            }
        }
    )
}

@Composable
private fun VoiceChip(name: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .clip(shape)
            .background(if (selected) MishtiColors.Coral.copy(alpha = 0.18f) else MishtiColors.Surface)
            .border(1.dp, if (selected) MishtiColors.Coral else MishtiColors.SurfaceHigh, shape)
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name,
            color = if (selected) MishtiColors.Coral else MishtiColors.Text,
            fontSize = 13.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun StatusLine(on: Boolean, onText: String, offText: String) {
    Text(
        if (on) onText else offText,
        color = if (on) MishtiColors.Coral else MishtiColors.TextDim,
        fontSize = 14.sp,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun PillButton(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .padding(top = 4.dp, bottom = 4.dp)
            .clip(shape)
            .background(MishtiColors.Surface)
            .border(1.dp, MishtiColors.SurfaceHigh, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 11.dp)
    ) {
        Text(text, color = MishtiColors.Text, fontSize = 14.sp)
    }
}
