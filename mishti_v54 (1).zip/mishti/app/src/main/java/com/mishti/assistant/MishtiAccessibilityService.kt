package com.mishti.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.graphics.Rect
import android.graphics.Bitmap
import android.graphics.ColorSpace
import java.io.ByteArrayOutputStream
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Lets Mishti see the screen and tap / type / scroll for the user.
 * Turned on by the user in Settings > Accessibility. Nothing here runs by itself:
 * every action is triggered by a tool call from the voice session.
 */
class MishtiAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MishtiAccessibilityService? = null
            private set

        private const val MAX_ELEMENTS = 60
    }

    private class El(
        val text: String,
        val desc: String,
        val cx: Int,
        val cy: Int,
        val clickable: Boolean,
        val editable: Boolean,
        val scrollable: Boolean,
        val id: String = "",
        /** -1 = not a switch/checkbox, 0 = off, 1 = on */
        val checked: Int = -1,
    )

    @Volatile
    private var last: List<El> = emptyList()

    private val main = Handler(Looper.getMainLooper())
    private var glowView: GlowView? = null
    private val glowTimeout = Runnable { hideGlowNow() }

    /** Breathing glow around the screen edges while Mishti works. */
    fun glow(on: Boolean) {
        main.post { if (on) showGlowNow() else hideGlowNow() }
    }

    private fun showGlowNow() {
        main.removeCallbacks(glowTimeout)
        main.postDelayed(glowTimeout, 14_000) // re-armed by every action; it can never stay on after work stops
        glowView?.let {
            it.fadeTo(1f)
            return
        }
        val v = GlowView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
            glowView = v
            v.start()
            v.fadeTo(1f)
        } catch (_: Exception) {
        }
    }

    private fun hideGlowNow() {
        main.removeCallbacks(glowTimeout)
        val v = glowView ?: return
        v.fadeTo(0f) {
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)
            } catch (_: Exception) {
            }
            if (glowView === v) glowView = null
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        main.post { hideGlowNow() }
        instance = null
        super.onDestroy()
    }

    @Volatile
    private var lastEventAt = 0L

    /** Remember when the screen last changed (our own glow overlay does not count). */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName?.toString() == packageName) return
        lastEventAt = System.currentTimeMillis()
    }

    /** Waits until the screen has stopped changing (or maxMs passes). Faster and safer than a fixed sleep. */
    fun waitSettled(maxMs: Long, quietMs: Long = 150L) {
        val start = System.currentTimeMillis()
        val deadline = start + maxMs
        val minWait = minOf(maxMs, 250L)
        while (true) {
            val now = System.currentTimeMillis()
            if (now >= deadline) return
            if (now - start >= minWait && now - lastEventAt >= quietMs) return
            try { Thread.sleep(40) } catch (_: InterruptedException) { return }
        }
    }

    // ------------------------------------------------------------------ automation intelligence

    /** Exact button labels that only ever say "not now": safe to press by themselves to clear the way. */
    private val blockerLabels = setOf(
        "not now", "no thanks", "no, thanks", "no thank you", "maybe later", "remind me later", "ask me later",
        "skip", "skip for now", "got it", "dismiss", "later", "not interested", "close ad",
        "এখন নয়", "পরে", "স্কিপ", "ঠিক আছে, বুঝেছি",
        "अभी नहीं", "बाद में", "छोड़ें", "स्किप",
    )

    /** Pressed a popup or banner button that was in the way? Returns its label, or null when nothing was there. */
    fun dismissBlocker(): String? {
        snapshot()
        val hit = last.firstOrNull { e ->
            val t = e.text.trim().lowercase()
            val d = e.desc.trim().lowercase()
            (t in blockerLabels || d in blockerLabels) && (e.clickable || e.text.isNotEmpty() || e.desc.isNotEmpty())
        } ?: return null
        val before = sig()
        if (!clickAt(hit.cx, hit.cy)) return null
        Thread.sleep(150)
        snapshot()
        return if (sig() != before) hit.text.ifBlank { hit.desc } else null
    }

    /** One line about what is on screen now: the app and the first things written on it. */
    fun brief(): String {
        val snap = snapshot()
        if (snap.optString("status") != "ok") return ""
        val seen = last.map { it.text.ifBlank { it.desc } }.filter { it.isNotBlank() }.distinct().take(10).joinToString(" | ")
        return snap.optString("app") + ": " + seen
    }

    /** Every window on screen, top one first (dialogs and the keyboard included). */
    private fun allRoots(): List<AccessibilityNodeInfo> {
        val roots = ArrayList<AccessibilityNodeInfo>()
        try { windows?.forEach { w -> w.root?.let { roots.add(it) } } } catch (_: Throwable) {}
        if (roots.isEmpty()) rootInActiveWindow?.let { roots.add(it) }
        return roots
    }

    /** Clicks the first visible view whose text matches, even when it is beyond the short read_screen list. */
    private fun clickNodeByText(q: String): Boolean {
        for (root in allRoots()) {
            val nodes = try { root.findAccessibilityNodeInfosByText(q) } catch (_: Throwable) { null } ?: continue
            for (n in nodes) {
                if (!n.isVisibleToUser) continue
                var node: AccessibilityNodeInfo? = n
                var hops = 0
                while (node != null && hops < 5) {
                    if (node.isClickable && node.isEnabled && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    node = node.parent
                    hops++
                }
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.width() > 0 && gestureTap(r.centerX(), r.centerY())) return true
            }
        }
        return false
    }

    override fun onInterrupt() {}

    // ------------------------------------------------------------------ read


    /** A small JPEG of what is on screen right now (Android 11+). Null when it can't be captured. */
    fun screenshotJpeg(maxSide: Int = 800, quality: Int = 65): ByteArray? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var out: ByteArray? = null
        try {
            takeScreenshot(
                android.view.Display.DEFAULT_DISPLAY,
                java.util.concurrent.Executors.newSingleThreadExecutor(),
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        try {
                            val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                            val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            r.hardwareBuffer.close()
                            if (soft != null) {
                                val scale = maxSide.toFloat() / maxOf(soft.width, soft.height).toFloat()
                                val small = if (scale < 1f)
                                    Bitmap.createScaledBitmap(soft, (soft.width * scale).toInt(), (soft.height * scale).toInt(), true)
                                else soft
                                val bo = ByteArrayOutputStream()
                                small.compress(Bitmap.CompressFormat.JPEG, quality, bo)
                                out = bo.toByteArray()
                            }
                        } catch (_: Throwable) {
                        }
                        latch.countDown()
                    }

                    override fun onFailure(code: Int) {
                        latch.countDown()
                    }
                }
            )
        } catch (_: Throwable) {
            return null
        }
        latch.await(3, TimeUnit.SECONDS)
        return out
    }

    /** Is this text on the screen right now? (cheap check for "wait until ... appears") */
    fun screenHas(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        return try {
            allRoots().any { root -> root.findAccessibilityNodeInfosByText(t).any { it.isVisibleToUser } }
        } catch (_: Exception) {
            false
        }
    }

    /** Full text of the first on-screen element that contains [query] (from the last read_screen / fresh read). */
    fun textOf(query: String): String? {
        snapshot()
        val q = query.trim().lowercase()
        val e = last.firstOrNull { (it.text + " " + it.desc).lowercase().contains(q) } ?: return null
        return (e.text.ifBlank { e.desc })
    }

    /** Text of the focused / first text box. */
    fun focusedText(): String? {
        val root = rootInActiveWindow ?: return null
        val t = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable } ?: findEditable(root, 0)
        return t?.text?.toString()
    }

    fun selectedText(): String? {
        val root = rootInActiveWindow ?: return null
        val t = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return null
        val full = t.text?.toString() ?: return null
        val a = t.textSelectionStart; val b = t.textSelectionEnd
        return if (a >= 0 && b > a && b <= full.length) full.substring(a, b) else null
    }

    fun snapshot(): JSONObject {
        var root = rootInActiveWindow
        var tries = 0
        while (root == null && tries < 7) {
            Thread.sleep(100)
            root = rootInActiveWindow
            tries++
        }
        if (root == null) return fail("Screen padha jachhe na. Screen lock ba app-ta block korche.")
        val out = ArrayList<El>()
        collect(root, out, 0, true)
        if (out.size <= 1) {
            out.clear()
            collect(root, out, 0, false)
        }
        if (out.size <= 1) {
            // The active window may be a keyboard or overlay: look through every window.
            for (w in windows) {
                val r = w.root ?: continue
                collect(r, out, 0, false)
                if (out.size > 1) break
            }
        }
        last = out

        val m = realMetrics()
        val arr = JSONArray()
        out.forEachIndexed { index, e ->
            val o = JSONObject().put("i", index)
            if (e.text.isNotEmpty()) o.put("text", e.text)
            if (e.desc.isNotEmpty()) o.put("desc", e.desc)
            if (e.id.isNotEmpty()) o.put("id", e.id)
            if (e.clickable) o.put("clickable", true)
            if (e.editable) o.put("textbox", true)
            if (e.scrollable) o.put("scrollable", true)
            if (e.checked >= 0) o.put("on", e.checked == 1)
            // position as percent of the screen, usable with tap_at
            o.put("at", "${e.cx * 100 / m.widthPixels},${e.cy * 100 / m.heightPixels}")
            arr.put(o)
        }
        return JSONObject()
            .put("status", "ok")
            .put("app", root.packageName?.toString().orEmpty())
            .put("elements", arr)
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<El>, depth: Int, strict: Boolean) {
        if (depth > 35 || out.size >= MAX_ELEMENTS) return
        if (strict && !node.isVisibleToUser) return

        val text = node.text?.toString().orEmpty().trim().take(80)
        val desc = node.contentDescription?.toString().orEmpty().trim().take(80)
        val hint = if (Build.VERSION.SDK_INT >= 26) node.hintText?.toString().orEmpty().trim().take(80) else ""
        val editable = node.isEditable
        val idName = node.viewIdResourceName?.substringAfter(":id/").orEmpty().take(40)
        // Icons with no label still matter: keep clickable ones that have an id, and switches.
        val unlabeled = text.isEmpty() && desc.isEmpty() && !editable &&
            ((node.isClickable && idName.isNotEmpty()) || node.isCheckable)

        if (text.isNotEmpty() || desc.isNotEmpty() || editable || unlabeled) {
            val r = Rect()
            node.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) {
                out.add(
                    El(
                        text = if (text.isEmpty() && editable) hint else text,
                        desc = desc,
                        cx = r.centerX(),
                        cy = r.centerY(),
                        clickable = node.isClickable,
                        editable = editable,
                        scrollable = node.isScrollable,
                        id = idName,
                        checked = if (node.isCheckable) (if (node.isChecked) 1 else 0) else -1
                    )
                )
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collect(child, out, depth + 1, strict)
            if (out.size >= MAX_ELEMENTS) return
        }
    }

    /** Taps (or presses and holds) a spot given as percent of the screen. For things with no label. */
    /** The true full screen size (status bar and navigation bar included), the same space screenshots and taps use. */
    @Suppress("DEPRECATION")
    private fun realMetrics(): android.util.DisplayMetrics {
        val dm = android.util.DisplayMetrics()
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        } catch (_: Throwable) {
            return resources.displayMetrics
        }
        return dm
    }

    fun tapPercent(xp: Double, yp: Double, holdMs: Long): JSONObject {
        val m = realMetrics()
        // Keep taps 12dp inside the screen edge so corner icons are not lost in cutout / gesture zones.
        val edge = 12f * m.density
        val x = (m.widthPixels * xp.coerceIn(0.0, 100.0) / 100.0).toFloat().coerceIn(edge, m.widthPixels - edge)
        val y = (m.heightPixels * yp.coerceIn(0.0, 100.0) / 100.0).toFloat().coerceIn(edge, m.heightPixels - edge)
        snapshot()
        val before = sig()
        val path = Path().apply { moveTo(x, y) }
        return if (dispatch(path, holdMs.coerceIn(50L, 2000L))) {
            Thread.sleep(170)
            snapshot()
            if (sig() != before) ok("Screen-er $xp%,$yp% jaygay tap kora hoyeche, screen bodleche.")
            else ok("Screen-er $xp%,$yp% jaygay tap kora hoyeche kintu screen bodlayni. look_screen diye dekho thik jaygay legechhe kina; na hole jaygata ektu sarie abar tap_at koro.")
        } else {
            fail("Tap hoyni.")
        }
    }

    /**
     * Sends the message in the focused chat box. Waits for a Send button to become enabled
     * (any window, keyboard included); falls back to the keyboard's own Enter/Send action.
     */
    fun tapSend(): JSONObject {
        val words = listOf("send", "submit", "post", "reply", "pathao", "পাঠান", "সেন্ড")
        val deadline = System.currentTimeMillis() + 1800
        while (System.currentTimeMillis() < deadline) {
            val hit = findSendNode(words)
            if (hit != null) {
                if (hit.isEnabled) {
                    val r = Rect(); hit.getBoundsInScreen(r)
                    if (r.width() > 0 && hit.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return ok("Send button-e tap kora hoyeche. look_screen diye dekho message gechhe kina (box khali hobe).")
                    }
                    if (r.width() > 0 && clickAt(r.centerX(), r.centerY())) {
                        return ok("Send button-e tap kora hoyeche. look_screen diye dekho message gechhe kina.")
                    }
                }
            }
            Thread.sleep(150)
        }
        val e = pressEnter()
        return if (e.optString("status") == "ok")
            ok("Send button paini, keyboard-er send action chapa hoyeche. look_screen diye dekho message gechhe kina.")
        else fail("Send button paini ar keyboard action-o hoyni. look_screen diye icon-ta dekho, tarpor tap_at.")
    }

    private fun findSendNode(words: List<String>): AccessibilityNodeInfo? {
        val roots = ArrayList<AccessibilityNodeInfo>()
        try { windows?.forEach { w -> w.root?.let { roots.add(it) } } } catch (_: Throwable) {}
        if (roots.isEmpty()) rootInActiveWindow?.let { roots.add(it) }
        for (root in roots) {
            val q = ArrayDeque<AccessibilityNodeInfo>()
            q.add(root)
            var n = 0
            while (q.isNotEmpty() && n < 600) {
                val node = q.removeFirst(); n++
                val label = ((node.contentDescription?.toString() ?: "") + " " + (node.text?.toString() ?: "")).lowercase().trim()
                val vid = (node.viewIdResourceName ?: "").lowercase()
                if (node.isVisibleToUser &&
                    (words.any { label == it || label.startsWith("$it ") || label.endsWith(" $it") } ||
                        vid.endsWith("send") || vid.contains("send_button") || vid.contains("send_btn"))
                ) return node
                for (i in 0 until node.childCount) node.getChild(i)?.let { q.add(it) }
            }
        }
        return null
    }

    // ------------------------------------------------------------------ act

    /** A quick fingerprint of what is on screen (texts, descriptions, switch states). */
    private fun sig(): Int {
        var h = 17
        for (e in last) {
            h = h * 31 + e.text.hashCode()
            h = h * 31 + e.desc.hashCode()
            h = h * 31 + e.checked
        }
        return h * 31 + last.size
    }

    /** After a tap: did the screen react? Tells the model so it can verify instead of assuming. */
    private fun reaction(before: Int, what: String): JSONObject {
        // Look again and again for a short while: instant screens answer at once, slow ones still get caught.
        val deadline = System.currentTimeMillis() + 700
        Thread.sleep(60)
        var changed = false
        while (true) {
            snapshot()
            if (sig() != before) { changed = true; break }
            if (System.currentTimeMillis() >= deadline) break
            Thread.sleep(80)
        }
        return if (changed) ok("$what-e tap kora hoyeche, screen bodleche.")
        else ok("$what-e tap kora hoyeche kintu screen bodlayni. Kaj hoyeche kina look_screen ba read_screen diye dekho; na hole tap_at diye abar tap koro.")
    }

    fun tapText(query: String): JSONObject {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return fail("Kon text-e tap korbo?")
        var hit: El? = null
        // Look at the live screen; if the text is not there yet (app still loading), keep looking for a couple of seconds.
        val deadline = System.currentTimeMillis() + 2000
        while (true) {
            val snap = snapshot()
            if (snap.optString("status") != "ok") return snap
            // best match first: exact, then starts-with, then contains; a clickable one beats a plain label
            hit = last.filter { rank(it, q) < 9 }
                .sortedWith(compareBy<El>({ rank(it, q) }, { if (it.clickable) 0 else 1 }))
                .firstOrNull()
            if (hit != null) break
            // The short list holds only 60 things: ask Android directly for the rest of the screen.
            val before0 = sig()
            if (clickNodeByText(q)) return reaction(before0, "'$query'")
            if (System.currentTimeMillis() >= deadline) break
            Thread.sleep(100)
        }
        val found = hit ?: run {
            val seen = last.map { it.text.ifBlank { it.desc } }.filter { it.isNotBlank() }.distinct().take(10).joinToString(" | ")
            return fail("'$query' screen-e paini. Ekhon screen-e ache: $seen. Ei naam-gulor kono ta chalao, na hole scroll_find ba look_screen.")
        }
        val before = sig()
        return if (clickAt(found.cx, found.cy)) reaction(before, "'$query'")
        else fail("Tap hoyni.")
    }

    private fun rank(e: El, q: String): Int {
        val t = e.text.lowercase()
        val d = e.desc.lowercase()
        return when {
            t == q || d == q -> 0
            t.startsWith(q) || d.startsWith(q) -> 1
            t.contains(q) || d.contains(q) -> 2
            else -> 9
        }
    }

    fun tapIndex(index: Int): JSONObject {
        val old = last.getOrNull(index)
            ?: return fail("$index number element nei. Age read_screen chalao.")
        // The screen may have changed since the list was made: find the same element again before tapping.
        snapshot()
        val fresh = last.firstOrNull {
            it.text == old.text && it.desc == old.desc && it.id == old.id &&
                Math.abs(it.cy - old.cy) < 400 && Math.abs(it.cx - old.cx) < 400
        } ?: last.firstOrNull { it.text.isNotBlank() && it.text == old.text && it.desc == old.desc }
        val e = fresh ?: return fail("Screen bodle geche, oi jinish ar nei. Notun read_screen chalao.")
        val before = sig()
        return if (clickAt(e.cx, e.cy)) reaction(before, "$index number")
        else fail("Tap hoyni.")
    }

    /**
     * Taps the way a user would: first a real click on the view under that point (or the nearest
     * clickable parent), which works even when the app ignores raw touches; if that is not possible,
     * a touch gesture at the point.
     */
    private fun clickAt(x: Int, y: Int): Boolean {
        val root = rootInActiveWindow
        if (root != null) {
            var node: AccessibilityNodeInfo? = deepestAt(root, x, y, 0)
            var hops = 0
            while (node != null && hops < 4) {
                if (node.isClickable && node.isEnabled && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    Thread.sleep(60)
                    return true
                }
                node = node.parent
                hops++
            }
        }
        val ok = gestureTap(x, y)
        if (ok) Thread.sleep(60)
        return ok
    }

    private fun deepestAt(node: AccessibilityNodeInfo, x: Int, y: Int, depth: Int): AccessibilityNodeInfo? {
        if (depth > 40 || !node.isVisibleToUser) return null
        val r = Rect()
        node.getBoundsInScreen(r)
        if (!r.contains(x, y)) return null
        for (i in node.childCount - 1 downTo 0) {
            val child = node.getChild(i) ?: continue
            deepestAt(child, x, y, depth + 1)?.let { return it }
        }
        return node
    }

    private fun biggestScrollable(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 30 || !node.isVisibleToUser) return null
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0L
        if (node.isScrollable) {
            val r = Rect()
            node.getBoundsInScreen(r)
            best = node
            bestArea = r.width().toLong() * r.height()
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val cand = biggestScrollable(child, depth + 1) ?: continue
            val r = Rect()
            cand.getBoundsInScreen(r)
            val area = r.width().toLong() * r.height()
            if (area > bestArea) {
                best = cand
                bestArea = area
            }
        }
        return best
    }

    /** Opens quick settings and taps one tile (wifi, bluetooth...). want = null toggles whatever it is now. */
    fun quickToggle(tile: String, want: Boolean?): JSONObject {
        val t = tile.trim().lowercase()
        val names = when (t) {
            "wifi", "wi-fi", "internet" -> listOf("internet", "wi-fi", "wifi")
            "bluetooth" -> listOf("bluetooth")
            "airplane", "flight", "flight_mode" -> listOf("airplane", "flight mode", "aeroplane")
            "flashlight", "torch" -> listOf("flashlight", "torch")
            "data", "mobile_data" -> listOf("mobile data", "data")
            "hotspot" -> listOf("hotspot")
            "rotate", "auto_rotate" -> listOf("auto-rotate", "auto rotate", "rotate")
            "dnd", "silent" -> listOf("do not disturb", "dnd")
            "location" -> listOf("location")
            "battery_saver" -> listOf("battery saver", "power saving")
            "dark_mode" -> listOf("dark theme", "dark mode")
            else -> listOf(t)
        }
        if (!performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)) return fail("Quick settings khola gelo na.")
        Thread.sleep(170)

        var found: El? = null
        for (attempt in 0 until 3) {
            snapshot()
            found = last.firstOrNull { e ->
                names.any { n -> e.text.lowercase().contains(n) || e.desc.lowercase().contains(n) }
            }
            if (found != null) break
            Thread.sleep(120)
        }
        val tileEl = found
        if (tileEl == null) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            return fail("'$tile' tile quick settings-e paini. open_settings diye try koro.")
        }

        val label = (tileEl.desc + " , " + tileEl.text).lowercase()
        val isOn = when {
            Regex("(^|[ ,])on($|[ ,])").containsMatchIn(label) -> true
            Regex("(^|[ ,])off($|[ ,])").containsMatchIn(label) -> false
            else -> null
        }
        if (want != null && isOn == want) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            return ok("$tile already ${if (want) "on" else "off"} chhilo.")
        }
        val clicked = clickAt(tileEl.cx, tileEl.cy)
        Thread.sleep(90)
        // On some phones tapping the tile opens a small panel instead; leave it open so read_screen can see it.
        val after = snapshot()
        val stillQuick = after.optString("app").contains("systemui")
        if (stillQuick) performGlobalAction(GLOBAL_ACTION_BACK)
        return if (clicked) {
            ok("$tile tile-e tap kora hoyeche. Jodi screen-e notun panel/dialog thake, read_screen diye toggle-e tap koro.")
        } else {
            fail("Tile-e tap hoyni.")
        }
    }

    fun typeText(text: String, index: Int = -1, append: Boolean = false): JSONObject {
        if (index >= 0) {
            val e = last.getOrNull(index) ?: return fail("$index number element nei. Age read_screen chalao.")
            clickAt(e.cx, e.cy)
            Thread.sleep(90)
        }
        // The box may still be appearing after a tap: look a few times before giving up.
        var target: AccessibilityNodeInfo? = null
        for (attempt in 0 until 5) {
            val root = rootInActiveWindow
            if (root != null) {
                target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
                    ?: findEditable(root, 0)
            }
            if (target != null) break
            Thread.sleep(120)
        }
        if (target == null) return fail("Kono text box paini. Age text box-e tap koro.")
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        var finalText = text
        if (append) {
            val showingHint = Build.VERSION.SDK_INT >= 26 && target.isShowingHintText
            val current = if (showingHint) "" else target.text?.toString().orEmpty()
            finalText = current + text
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, finalText)
        }
        var done = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (done) {
            // Some apps swallow set-text silently: check, and paste instead if the box is still empty.
            try { target.refresh() } catch (_: Throwable) {}
            val got = target.text?.toString().orEmpty()
            val showingHint = Build.VERSION.SDK_INT >= 26 && target.isShowingHintText
            if (finalText.isNotEmpty() && (got.isEmpty() || showingHint)) done = false
        }
        if (!done) done = pasteInto(target, finalText)
        return if (done) {
            ok("Lekha hoyeche (${text.length} akkhor).")
        } else {
            fail("Ei text box-e lekha gelo na. Box-e ekbar tap kore abar try koro.")
        }
    }

    /** Fallback typing: put the text on the clipboard, select what is there and paste over it. */
    private fun pasteInto(target: AccessibilityNodeInfo, text: String): Boolean {
        return try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("mishti", text))
            target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val sel = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, target.text?.length ?: 0)
            }
            target.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
            target.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        } catch (_: Throwable) {
            false
        }
    }

    private fun matches(e: El, q: String) =
        e.text.lowercase().contains(q) || e.desc.lowercase().contains(q)

    /** Scrolls until some text shows up (or gives up). Optionally taps it. */
    fun scrollFind(text: String, direction: String, max: Int, tap: Boolean): JSONObject {
        val q = text.trim().lowercase()
        if (q.isEmpty()) return fail("Ki khujbo?")
        val dir = direction.ifBlank { "down" }
        val rounds = max.coerceIn(1, 12)
        for (i in 0..rounds) {
            val snap = snapshot()
            if (snap.optString("status") != "ok") return snap
            val hit = last.firstOrNull { matches(it, q) }
            if (hit != null) {
                if (tap && !clickAt(hit.cx, hit.cy)) return fail("'$text' pawa gelo kintu tap hoyni.")
                return ok(if (tap) "'$text' peye tap korlam." else "'$text' screen-e ache.")
            }
            if (i < rounds) swipe(dir)
        }
        return fail("'$text' scroll kore-o paini.")
    }

    /** Waits until any of the texts is on screen. */
    fun waitForText(texts: List<String>, seconds: Int): JSONObject {
        val wanted = texts.map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (wanted.isEmpty()) return fail("Kon text-er jonno opekkha?")
        val deadline = System.currentTimeMillis() + seconds.coerceIn(1, 15) * 1000L
        while (System.currentTimeMillis() < deadline) {
            // cheap direct check first (no full screen read), then one real read so the list is fresh
            if (wanted.any { screenHas(it) }) {
                snapshot()
                return ok("Text screen-e eshe geche.")
            }
            Thread.sleep(80)
        }
        val lastSnap = snapshot()
        if (lastSnap.optString("status") == "ok" && last.any { e -> wanted.any { matches(e, it) } }) {
            return ok("Text screen-e eshe geche.")
        }
        return fail("Text ashe ni. read_screen diye dekho.")
    }

    /** On a Play Store page (search results or app page): taps Install and checks that it started. */
    fun playInstall(): JSONObject {
        val deadline = System.currentTimeMillis() + 14000
        var tapped = false
        while (System.currentTimeMillis() < deadline) {
            snapshot()
            fun has(vararg names: String) = last.any { e ->
                names.any { n -> e.text.equals(n, true) || e.desc.equals(n, true) }
            }
            if (!tapped) {
                val btn = last.firstOrNull { e ->
                    e.text.equals("Install", true) || e.desc.equals("Install", true) ||
                        e.text.equals("Get", true) || e.text.equals("Update", true)
                }
                if (btn != null) {
                    clickAt(btn.cx, btn.cy)
                    tapped = true
                    Thread.sleep(700)
                    continue
                }
                if (has("Open")) return ok("App agei install kora chhilo. open_app diye kholo.")
            } else {
                if (has("Cancel", "Open", "Installing", "Downloading", "Pending", "Installing…")) {
                    return ok("Install shuru hoyeche. Download hote kichu somoy lagbe.")
                }
                if (has("Sign in")) return fail("Play Store-e sign in kora nei.")
            }
            Thread.sleep(120)
        }
        return if (tapped) ok("Install-e tap korechhi, kintu confirm hote parini. Ektu por read_screen diye dekho.")
        else fail("Install button paini. read_screen diye dekho ki ache.")
    }

    private fun findEditable(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
        if (depth > 30 || !node.isVisibleToUser) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findEditable(child, depth + 1)?.let { return it }
        }
        return null
    }

    fun pressKey(key: String): JSONObject {
        val k = key.trim().lowercase()
        val action = when (k) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "lock" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return fail("Ei phone-e lock hobe na.")
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return fail("Ei phone-e screenshot hobe na.")
            "enter" -> return pressEnter()
            else -> return fail("'$key' key-ta chini na.")
        }
        return if (performGlobalAction(action)) ok("$k chapa hoyeche.") else fail("$k hoyni.")
    }

    fun pressEnter(): JSONObject {
        if (Build.VERSION.SDK_INT >= 30) {
            val focused = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null &&
                focused.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            ) {
                return ok("Enter chapa hoyeche.")
            }
        }
        return fail("Enter hoyni. Keyboard-er search button ba screen-er search button-e tap koro (read_screen).")
    }

    fun swipe(direction: String): JSONObject {
        val d = direction.trim().lowercase()

        // Vertical scroll: ask the biggest scrollable view to scroll itself. Far more reliable than a touch swipe.
        if (d == "down" || d == "up") {
            val root = rootInActiveWindow
            val target = root?.let { biggestScrollable(it, 0) }
            if (target != null) {
                val action = if (d == "down") AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                if (target.performAction(action)) {
                    Thread.sleep(60)
                    return ok("Scroll kora hoyeche.")
                }
            }
        }

        val m = realMetrics()
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val path = Path()
        when (d) {
            "down" -> { path.moveTo(w * 0.5f, h * 0.74f); path.lineTo(w * 0.5f, h * 0.28f) }
            "up" -> { path.moveTo(w * 0.5f, h * 0.28f); path.lineTo(w * 0.5f, h * 0.74f) }
            "left" -> { path.moveTo(w * 0.85f, h * 0.5f); path.lineTo(w * 0.15f, h * 0.5f) }
            "right" -> { path.moveTo(w * 0.15f, h * 0.5f); path.lineTo(w * 0.85f, h * 0.5f) }
            else -> return fail("direction hobe down, up, left ba right.")
        }
        return if (dispatch(path, 160)) {
            Thread.sleep(50)
            ok("Swipe kora hoyeche.")
        } else {
            fail("Swipe hoyni.")
        }
    }

    // ------------------------------------------------------------------ gestures

    private fun gestureTap(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return dispatch(path, 70)
    }

    // ------------------------------------------------------------------ more control

    /** Drags from one spot to another (percent of the screen): sliders, reordering, pulling things. */
    fun drag(x1: Int, y1: Int, x2: Int, y2: Int, ms: Long): JSONObject {
        val m = realMetrics()
        val path = Path().apply {
            moveTo(m.widthPixels * x1.coerceIn(0, 100) / 100f, m.heightPixels * y1.coerceIn(0, 100) / 100f)
            lineTo(m.widthPixels * x2.coerceIn(0, 100) / 100f, m.heightPixels * y2.coerceIn(0, 100) / 100f)
        }
        return if (dispatch(path, ms.coerceIn(100L, 3000L))) {
            Thread.sleep(60)
            ok("Drag kora hoyeche.")
        } else {
            fail("Drag hoyni.")
        }
    }

    /** Two-finger zoom in or out in the middle of the screen (maps, photos, pages). */
    fun pinch(zoomIn: Boolean): JSONObject {
        val m = realMetrics()
        val cx = m.widthPixels / 2f
        val cy = m.heightPixels / 2f
        val near = m.widthPixels * 0.06f
        val far = m.widthPixels * 0.32f
        val from = if (zoomIn) near else far
        val to = if (zoomIn) far else near
        val left = Path().apply { moveTo(cx - from, cy); lineTo(cx - to, cy) }
        val right = Path().apply { moveTo(cx + from, cy); lineTo(cx + to, cy) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(left, 0, 350))
            .addStroke(GestureDescription.StrokeDescription(right, 0, 350))
            .build()
        return if (runGesture(gesture)) {
            Thread.sleep(80)
            ok(if (zoomIn) "Zoom in hoyeche." else "Zoom out hoyeche.")
        } else {
            fail("Pinch hoyni.")
        }
    }

    /** Select all / copy / cut / paste / clear in the text box that has focus. */
    fun textEdit(action: String): JSONObject {
        val root = rootInActiveWindow ?: return fail("Screen padha jachhe na.")
        val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
            ?: findEditable(root, 0)
            ?: return fail("Kono text box paini. Age text box-e tap koro.")
        val a = action.trim().lowercase()
        val done = when (a) {
            "select_all" -> {
                val len = target.text?.length ?: 0
                val args = Bundle().apply {
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, len)
                }
                target.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, args)
            }
            "copy" -> target.performAction(AccessibilityNodeInfo.ACTION_COPY)
            "cut" -> target.performAction(AccessibilityNodeInfo.ACTION_CUT)
            "paste" -> target.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            "clear" -> {
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
                }
                target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            }
            else -> return fail("action hobe select_all, copy, cut, paste ba clear.")
        }
        return if (done) ok("$a hoyeche.") else fail("$a hoyni.")
    }

    /** Presses and holds a labelled thing (opens menus, selects text, picks up icons). */
    fun longPressText(query: String): JSONObject {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return fail("Kon text-e long press korbo?")
        val snap = snapshot()
        if (snap.optString("status") != "ok") return snap
        val hit = last.firstOrNull { matches(it, q) } ?: return fail("'$query' screen-e nei.")
        val path = Path().apply { moveTo(hit.cx.toFloat(), hit.cy.toFloat()) }
        return if (dispatch(path, 800)) {
            Thread.sleep(80)
            ok("Long press hoyeche.")
        } else {
            fail("Long press hoyni.")
        }
    }


    // ------------------------------------------------------------------ games

    private fun dirVec(d: String): Pair<Float, Float>? {
        val k = 0.7071f
        return when (d.trim().lowercase().replace("-", "_").replace(" ", "_")) {
            "up", "forward", "north" -> 0f to -1f
            "down", "back", "backward", "south" -> 0f to 1f
            "left", "west" -> -1f to 0f
            "right", "east" -> 1f to 0f
            "up_left", "left_up" -> -k to -k
            "up_right", "right_up" -> k to -k
            "down_left", "left_down" -> -k to k
            "down_right", "right_down" -> k to k
            else -> null
        }
    }

    /**
     * Several touches at the same time, like real fingers on a game pad: hold the stick while pressing a button,
     * tap fast in a row, swipe. Each action: control (saved name) or x,y in percent; dir for a stick; hold_ms; at_ms
     * (when it starts); to_x,to_y for a swipe.
     */
    fun gameAct(actions: JSONArray, pad: JSONObject): JSONObject {
        val m = realMetrics()
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val gb = GestureDescription.Builder()
        var n = 0
        var end = 0L
        val maxStrokes = GestureDescription.getMaxStrokeCount()
        for (i in 0 until actions.length()) {
            val a = actions.optJSONObject(i) ?: continue
            var x = if (a.has("x")) a.optDouble("x") else Double.NaN
            var y = if (a.has("y")) a.optDouble("y") else Double.NaN
            var kind = a.optString("kind")
            val c = a.optString("control").trim().lowercase()
            if (c.isNotEmpty()) {
                val p = pad.optJSONObject(c)
                    ?: return fail("'$c' control save kora nei. Age screen dekhe save_control chalao, ba x,y dao.")
                x = p.optDouble("x"); y = p.optDouble("y")
                if (kind.isBlank()) kind = p.optString("kind")
            }
            if (x.isNaN() || y.isNaN()) return fail("Action ${i + 1}-e control-er naam ba x,y nei.")
            if (n >= maxStrokes) return fail("Ekbar-e $maxStrokes-r beshi action hoy na. Bhag kore pathao.")
            val at = a.optLong("at_ms", 0).coerceIn(0L, 20000L)
            val hold = a.optLong("hold_ms", 90).coerceIn(30L, 15000L)
            val px = (w * x.coerceIn(0.0, 100.0) / 100.0).toFloat()
            val py = (h * y.coerceIn(0.0, 100.0) / 100.0).toFloat()
            val dir = a.optString("dir")
            val v = dirVec(dir)
            val path = Path()
            var dur: Long
            if (v != null) {
                // Stick: push out to the edge fast, then stay near the edge for the whole hold.
                val r = 0.15f * minOf(w, h)
                val tx = px + v.first * r
                val ty = py + v.second * r
                path.moveTo(px, py)
                path.lineTo(tx, ty)
                val k = (hold / 24).toInt().coerceIn(1, 80)
                val amp = (r * 0.2f * (hold / 24f / k)).coerceAtMost(r * 0.35f)
                // wiggle along the push direction so the stick stays held out
                for (j in 0 until k) {
                    val f = if (j % 2 == 0) -1f else 1f
                    path.lineTo(tx + v.first * f * amp * 0.5f, ty + v.second * f * amp * 0.5f)
                }
                dur = 120L + hold
            } else if (a.has("to_x") && a.has("to_y")) {
                path.moveTo(px, py)
                path.lineTo(
                    (w * a.optDouble("to_x").coerceIn(0.0, 100.0) / 100.0).toFloat(),
                    (h * a.optDouble("to_y").coerceIn(0.0, 100.0) / 100.0).toFloat()
                )
                dur = if (a.has("hold_ms")) hold else 250L
            } else {
                path.moveTo(px, py)
                dur = hold
            }
            gb.addStroke(GestureDescription.StrokeDescription(path, at, dur))
            n++
            end = maxOf(end, at + dur)
        }
        if (n == 0) return fail("Kono action paini.")
        return if (runGesture(gb.build(), end + 2500)) {
            Thread.sleep(40)
            ok("$n ta action hoyeche. Frame-e dekhe nao ki holo.")
        } else {
            fail("Gesture hoyni. Game bondho ba onno app-er upore, ba action-er sonkha beshi.")
        }
    }

    private fun runGesture(gesture: GestureDescription, waitMs: Long = 3000): Boolean {
        val latch = CountDownLatch(1)
        val done = AtomicBoolean(false)
        val accepted = dispatchGesture(
            gesture,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    done.set(true)
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            },
            null
        )
        if (!accepted) return false
        latch.await(waitMs, TimeUnit.MILLISECONDS)
        return done.get()
    }

    private fun dispatch(path: Path, durationMs: Long): Boolean {
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        val latch = CountDownLatch(1)
        val done = AtomicBoolean(false)
        val accepted = dispatchGesture(
            gesture,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    done.set(true)
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            },
            null
        )
        if (!accepted) return false
        latch.await(3, TimeUnit.SECONDS)
        return done.get()
    }

    private fun ok(msg: String) = JSONObject().put("status", "ok").put("message", msg)

    private fun fail(msg: String) = JSONObject().put("status", "error").put("message", msg)
}
