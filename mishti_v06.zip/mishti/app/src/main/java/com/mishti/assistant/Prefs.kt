package com.mishti.assistant

import android.content.Context
import org.json.JSONArray

/**
 * On-device settings. Values typed in the Settings screen win; if empty, the
 * build-time values from local.properties (BuildConfig) are used as a fallback.
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("mishti", Context.MODE_PRIVATE)

    init {
        // v05 moved to a newer default model; forget any older model name saved by earlier versions.
        if (sp.getInt("schema", 0) < 5) {
            sp.edit().remove("model").putInt("schema", 5).apply()
        }
    }

    var apiKey: String
        get() = sp.getString("api_key", "").orEmpty().ifBlank { BuildConfig.GEMINI_API_KEY }
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", "").orEmpty().ifBlank { BuildConfig.GEMINI_MODEL }
        set(v) = sp.edit().putString("model", v.trim()).apply()

    var voice: String
        get() = sp.getString("voice", "").orEmpty().ifBlank { BuildConfig.GEMINI_VOICE }
        set(v) = sp.edit().putString("voice", v.trim()).apply()

    var userName: String
        get() = sp.getString("user_name", "").orEmpty()
        set(v) = sp.edit().putString("user_name", v.trim()).apply()

    /** Pause length (ms) that ends the user's turn. 300 = fast, 800 = relaxed. */
    var silenceMs: Int
        get() = sp.getInt("silence_ms", 300)
        set(v) = sp.edit().putInt("silence_ms", v).apply()

    var webSearch: Boolean
        get() = sp.getBoolean("web_search", false)
        set(v) = sp.edit().putBoolean("web_search", v).apply()

    /** auto, bangla, hindi, english */
    var language: String
        get() = sp.getString("language", "bangla").orEmpty().ifBlank { "bangla" }
        set(v) = sp.edit().putString("language", v).apply()

    /** True = Mishti answers only when she hears her name. */
    var nameOnly: Boolean
        get() = sp.getBoolean("name_only", false)
        set(v) = sp.edit().putBoolean("name_only", v).apply()

    /** True = the user can interrupt Mishti by talking. */
    var bargeIn: Boolean
        get() = sp.getBoolean("barge_in", true)
        set(v) = sp.edit().putBoolean("barge_in", v).apply()

    /** True = Mishti keeps an eye on battery, heat, storage, memory and internet, and speaks up. */
    var deviceWatch: Boolean
        get() = sp.getBoolean("device_watch", true)
        set(v) = sp.edit().putBoolean("device_watch", v).apply()

    /** True = noisy room: needs a clearer voice to start a turn. */
    var noisyRoom: Boolean
        get() = sp.getBoolean("noisy_room", false)
        set(v) = sp.edit().putBoolean("noisy_room", v).apply()

    /** Raw typed values, so the Settings screen does not show the build fallback as if it were typed. */
    fun typed(key: String): String = sp.getString(key, "").orEmpty()

    // ---- things Mishti was asked to remember ----

    val notes: List<String>
        get() {
            val arr = try {
                JSONArray(sp.getString("notes", "[]"))
            } catch (e: Exception) {
                JSONArray()
            }
            return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
        }

    private fun saveNotes(list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        sp.edit().putString("notes", arr.toString()).apply()
    }

    @Synchronized
    fun addNote(note: String) {
        val clean = note.trim().take(200)
        if (clean.isEmpty()) return
        saveNotes((notes + clean).takeLast(40))
    }

    @Synchronized
    fun removeNotes(keyword: String): Int {
        val k = keyword.trim().lowercase()
        if (k.isEmpty()) return 0
        val before = notes
        val after = before.filterNot { it.lowercase().contains(k) }
        saveNotes(after)
        return before.size - after.size
    }

    @Synchronized
    fun clearNotes() = saveNotes(emptyList())
}
