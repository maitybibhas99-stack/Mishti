package com.mishti.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object MishtiColors {
    val Bg = Color(0xFF151515)
    val Surface = Color(0xFF262626)
    val SurfaceHigh = Color(0xFF303030)
    val Coral = Color(0xFFD97757)
    val Text = Color(0xFFF2F0EB)
    val TextDim = Color(0xFF9A9892)
    val Danger = Color(0xFFE5484D)
}

@Composable
fun MishtiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = MishtiColors.Bg,
            surface = MishtiColors.Surface,
            primary = MishtiColors.Coral,
            onBackground = MishtiColors.Text,
            onSurface = MishtiColors.Text,
        ),
        content = content
    )
}
