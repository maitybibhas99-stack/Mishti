package com.mishti.assistant.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val TAU = (2.0 * PI).toFloat()

private val Magenta = Color(0xFFFF3D8B)
private val Cyan = Color(0xFF39F2E0)
private val Blue = Color(0xFF5B7BFF)
private val Violet = Color(0xFFA16BFF)
private val Amber = Color(0xFFFFB86B)

/**
 * A glowing, glassy, iridescent orb that breathes by itself and swells with sound.
 *
 * [level] is read only while drawing, so a change 30 times a second redraws the orb and nothing else.
 * [energy] sets how lively it is: about 0.3 asleep or connecting, 0.7 listening, 1.0 speaking.
 */
@Composable
fun Orb(
    modifier: Modifier = Modifier,
    level: () -> Float = { 0f },
    energy: Float = 0.7f,
    rays: Boolean = true,
) {
    val clock = rememberInfiniteTransition(label = "orb")
    val spin = clock.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Restart),
        label = "spin"
    )
    val breath = clock.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4400, easing = LinearEasing), RepeatMode.Restart),
        label = "breath"
    )

    Canvas(modifier) {
        val lv = level().coerceIn(0f, 1f)
        val e = energy.coerceIn(0f, 1f)
        val c = Offset(size.width / 2f, size.height / 2f)
        val reach = size.minDimension / 2f
        val ph = spin.value * TAU
        val br = sin(breath.value * TAU)

        val orbR = reach * 0.40f * (1f + 0.035f * br + 0.15f * lv)
        val amp = 0.035f + 0.07f * e + 0.11f * lv

        // Soft glow behind everything.
        drawCircle(
            brush = Brush.radialGradient(
                0f to Cyan.copy(alpha = 0.10f + 0.16f * lv),
                0.45f to Violet.copy(alpha = 0.10f + 0.10f * e),
                1f to Color.Transparent,
                center = c,
                radius = reach
            ),
            radius = reach,
            center = c
        )

        // Light rays.
        if (rays) {
            val count = 64
            for (k in 0 until count) {
                val a = k * TAU / count + ph * 0.5f
                val wob = 0.5f + 0.5f * sin(ph * 3f + k * 1.7f)
                val seed = ((k * 7919) % 97) / 97f
                val len = orbR * (0.12f + (0.20f + 0.75f * seed) * wob * (0.25f + 0.6f * e + 1.1f * lv))
                val inner = orbR * 1.04f
                val x0 = c.x + cos(a) * inner
                val y0 = c.y + sin(a) * inner
                val x1 = c.x + cos(a) * (inner + len)
                val y1 = c.y + sin(a) * (inner + len)
                drawLine(
                    color = Color.White.copy(alpha = (0.08f + 0.22f * seed) * (0.5f + 0.5f * e + lv)),
                    start = Offset(x0, y0),
                    end = Offset(x1, y1),
                    strokeWidth = size.minDimension * (0.003f + 0.004f * seed),
                    cap = StrokeCap.Round,
                    blendMode = BlendMode.Plus
                )
            }
        }

        // Three colour channels, slightly apart: the fringing you see on glass.
        val d = orbR * 0.04f * (1f + 1.4f * lv)
        channel(c, orbR, amp, ph, 0.0f, Offset(-d, -d * 0.4f), Magenta)
        channel(c, orbR, amp, ph, 1.7f, Offset(d * 0.3f, d), Cyan)
        channel(c, orbR, amp, ph, 3.1f, Offset(d, -d * 0.3f), Blue)

        // Slow iridescent swirl inside the body.
        val body = blob(c, orbR * 0.97f, amp, ph, 1.7f)
        clipPath(body) {
            rotate(degrees = spin.value * 360f, pivot = c) {
                drawCircle(
                    brush = Brush.sweepGradient(
                        colors = listOf(Magenta, Amber, Cyan, Blue, Violet, Magenta),
                        center = c
                    ),
                    radius = orbR * 1.3f,
                    center = c,
                    alpha = 0.20f + 0.10f * e
                )
            }
            // Darker heart, bright rim: glass, not a flat disc.
            drawCircle(
                brush = Brush.radialGradient(
                    0f to Color(0xAA0B0B14),
                    0.65f to Color(0x330B0B14),
                    1f to Color.Transparent,
                    center = c,
                    radius = orbR
                ),
                radius = orbR,
                center = c
            )
        }

        // Two highlights.
        val h1 = Offset(c.x - orbR * 0.38f, c.y - orbR * 0.42f)
        drawCircle(
            brush = Brush.radialGradient(
                0f to Color.White.copy(alpha = 0.95f),
                1f to Color.Transparent,
                center = h1,
                radius = orbR * 0.17f
            ),
            radius = orbR * 0.17f,
            center = h1
        )
        val h2 = Offset(c.x + orbR * 0.46f, c.y + orbR * 0.30f)
        drawCircle(
            brush = Brush.radialGradient(
                0f to Color.White.copy(alpha = 0.85f),
                1f to Color.Transparent,
                center = h2,
                radius = orbR * 0.09f
            ),
            radius = orbR * 0.09f,
            center = h2
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.channel(
    c: Offset,
    r: Float,
    amp: Float,
    ph: Float,
    seed: Float,
    shift: Offset,
    color: Color,
) {
    val center = Offset(c.x + shift.x, c.y + shift.y)
    val path = blob(center, r, amp, ph, seed)
    drawPath(
        path = path,
        brush = Brush.radialGradient(
            0f to Color.Transparent,
            0.55f to color.copy(alpha = 0.06f),
            1f to color.copy(alpha = 0.50f),
            center = center,
            radius = r * 1.1f
        ),
        blendMode = BlendMode.Plus
    )
    drawPath(
        path = path,
        color = color.copy(alpha = 0.75f),
        style = Stroke(width = r * 0.028f),
        blendMode = BlendMode.Plus
    )
}

/** A circle that wobbles a little, like a soap bubble. */
private fun blob(c: Offset, r: Float, amp: Float, ph: Float, seed: Float): Path {
    val path = Path()
    val n = 96
    for (i in 0..n) {
        val a = i * TAU / n
        val wobble = 0.55f * sin(3f * a + ph + seed) +
            0.30f * sin(5f * a - ph * 1.3f + seed * 2f) +
            0.15f * sin(2f * a + ph * 0.7f)
        val rr = r * (1f + amp * wobble)
        val x = c.x + cos(a) * rr
        val y = c.y + sin(a) * rr
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}
