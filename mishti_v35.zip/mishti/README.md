# Mishti

Android voice assistant. Kotlin + Jetpack Compose, Gemini Live voice-to-voice.
Package: com.mishti.assistant

## Build on GitHub (no Android Studio needed)
1. Make a new GitHub repo and upload everything in this folder, including the hidden `.github` folder.
2. Push to `main`. Open the **Actions** tab. If the run has not started, open **Build Mishti APK** and press **Run workflow**.
3. When it turns green, open the run, download the **Mishti-debug-apk** artifact, unzip it and install `app-debug.apk`.

## First run
1. Open the app, tap the gear icon (top right) -> paste your Gemini API key (aistudio.google.com) -> Save.
2. Tap the white waveform button and talk. Allow the microphone when asked.

The key is stored only on the phone. If the connection fails with a model error, put the current Live model
name from AI Studio into Settings -> Model.

## Android Studio (optional)
Open the folder, let Gradle sync, run. You can also put `GEMINI_API_KEY=...` in `local.properties` as a fallback.

## Steps
1. Voice chat, Claude-style UI, Settings
2. Phone control: call, SMS, open apps
3. Background service, Accessibility screen control, play media, torch, volume, alarm, timer, memory, Google search
4. v05: gemini-3.8-live default, orb voice screen, always-on listening (auto reconnect, wake lock), text chat is silent,
   fast tools (play_youtube, quick_toggle, do_steps), click/scroll through real accessibility actions,
   language / listening / battery options in Settings 

## Updating
Upload the new `mishti_vNN.zip` to the repo. The workflow unzips the newest one and builds it.
Builds are signed with the fixed `debug.keystore`, so a new APK installs over the old one and keeps your settings.
5. v06: one steady sweet persona and voice, Bangla/Hindi never mixed, device watcher (battery, heat, storage, RAM, internet), install_app, scroll_find, wait_for_text, long text into notes (this version)
6. v07: persona rewritten in English with Bangla/Hindi script examples, language hint, new default voice Sulafat (this version)
7. v08: voice back to Aoede, bottom glow on voice screen, tap_at + richer read_screen (ids, switch state, positions) (this version)
8. v09: screen-edge breathing glow while working, routines (save_routine/run_routine), latest-info search on by default, spontaneous chat, premium textured UI, faster taps (this version)
9. v10: softer, lower, slower voice (playback pitch and speed in Settings), deeper girlfriend role-play (this version)
10. v11: realistic human-female speech style in the persona (this version)
11. v12: thinner, softer rounded-corner edge glow (this version)
12. v13: Hey Mishti wake mode (voice-gated, boot note), background research and queued tasks with results, softer thinner voice (this version)
13. v14: Mishti rests by voice and wakes by herself on Hey Mishti, session closes when idle (this version)
14. v15: notification access (announce messages, read important ones, clear junk, reply from notification) (this version)
15. v16: offline "Hey Mishti" listener (Vosk) wakes her fully from off, resting or lockscreen; off/rest returns to waiting (this version)
- v17: notun UI (3D glass orb, liquid glass typing bar, voice section only orb+mute+stop)
- v18: English UI, Bangla/Hindi only, glass settings, orb like reference
- v19: notification fixes (rebind, richer read, fallback by sight), in-app Notifications inbox
- v20: voice polish (EQ, loudness, limiter), tone and loudness settings
- v21: liquid glass (no blur) surfaces
- v22: liquid animations (press spring, sliding thumb, ripples, entrances, drifting liquid background)
- v23: speed pass (VAD 200ms, shorter UI waits, smaller playback buffer, quick pace, SPEED persona rules)
- v24: fix compile error (drawOutline)
- v25: brighter voice + never male voice, new screen tools (drag, pinch, long_press, text_edit)
- v26: minimal settings (key, language, voice), respectful boss/aap persona, location tools + permission
- v27: Voice ID (only owner voice, on/off + enroll in Settings), stop_task live control
- v28: Voice ID removed; look_screen (live screenshot to Gemini), copy/paste tools, careful control rules, faster turn-taking
- v29: brain (habits, lessons, usage learning, recall), situation rulebook in persona, faster turn-taking
- v30: make_plan checklist (multi-task never forgotten, PLAN_LEFT in every result)
- v31: faster screen actions (shorter waits), conversation-intelligence rules
- v32: softer sweet tone and human feel (persona only)
- v33: borderless flowing orb, status line under orb, Settings cards restored, daily greetings + good night, respect rules
- v34: crystal-clear animated liquid inside glass (waves, bubbles, glint), no blur
- v35: whole UI liquid glass (one shared clock), no blur
