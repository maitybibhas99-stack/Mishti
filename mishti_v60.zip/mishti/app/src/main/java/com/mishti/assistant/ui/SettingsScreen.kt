package com.mishti.assistant.ui

import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mishti.assistant.BuildConfig
import com.mishti.assistant.MishtiAccessibilityService
import com.mishti.assistant.Prefs
import kotlinx.coroutines.delay

// Female-sounding voices first. The Live model decides which ones it really supports.
private val VOICES = listOf(
    "Aoede", "Sulafat", "Vindemiatrix", "Achernar", "Leda", "Kore",
    "Zephyr", "Callirhoe", "Autonoe", "Despina", "Erinome", "Laomedeia"
)

@Composable
fun SettingsScreen(
    prefs: Prefs,
    wakeStatus: String,
    onSaved: () -> Unit,
    onBack: () -> Unit,
) {
    var key by remember { mutableStateOf(prefs.typed("api_key")) }
    var showKey by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(prefs.typed("model")) }
    var voice by remember { mutableStateOf(prefs.voice) }
    var name by remember { mutableStateOf(prefs.userName) }
    var silence by remember { mutableStateOf(prefs.silenceMs) }
    var webSearch by remember { mutableStateOf(prefs.webSearch) }
    var language by remember { mutableStateOf(prefs.language) }
    var nameOnly by remember { mutableStateOf(prefs.nameOnly) }
    var bargeIn by remember { mutableStateOf(prefs.bargeIn) }
    var noisy by remember { mutableStateOf(prefs.noisyRoom) }
    var watch by remember { mutableStateOf(prefs.deviceWatch) }
    var pitch by remember { mutableStateOf(prefs.voicePitch) }
    var pace by remember { mutableStateOf(prefs.voiceSpeed) }
    var polish by remember { mutableStateOf(prefs.voicePolish) }
    var loud by remember { mutableStateOf(prefs.voiceLoud) }
    var junk by remember { mutableStateOf(prefs.junkMode) }
    var aloud by remember { mutableStateOf(prefs.notifyAloud) }
    var notifOn by remember { mutableStateOf(com.mishti.assistant.MishtiNotificationService.instance != null) }
    var chatter by remember { mutableStateOf(prefs.spontaneous) }
    var noteCount by remember { mutableStateOf(prefs.notes.size) }
    var convOn by remember { mutableStateOf(prefs.convMemory) }
    var convCount by remember { mutableStateOf(prefs.journalSize()) }
    var brainCount by remember { mutableStateOf(prefs.habits.size + prefs.lessons.size) }
    var proMax by remember { mutableStateOf(prefs.proactiveMax) }
    var logLines by remember { mutableStateOf(prefs.actionLog().take(15)) }
    val context = LocalContext.current
    var accOn by remember { mutableStateOf(MishtiAccessibilityService.instance != null) }
    var overlayOn by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    val power = remember { context.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager }
    var batteryFree by remember { mutableStateOf(power.isIgnoringBatteryOptimizations(context.packageName)) }
    LaunchedEffect(Unit) {
        var tick = 0
        while (true) {
            if (tick % 5 == 0 && com.mishti.assistant.MishtiNotificationService.instance == null) {
                com.mishti.assistant.MishtiNotificationService.rebind(context)
            }
            tick++
            accOn = MishtiAccessibilityService.instance != null
            notifOn = com.mishti.assistant.MishtiNotificationService.instance != null
            overlayOn = Settings.canDrawOverlays(context)
            batteryFree = power.isIgnoringBatteryOptimizations(context.packageName)
            delay(1000)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .auroraBackground()
            .systemBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(64.dp)
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(42.dp)
                    .liquid(CircleShape)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Column(Modifier.padding(start = 14.dp)) {
                Text("Settings", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text("Make Mishti yours", color = MishtiColors.TextDim, fontSize = 12.sp)
            }
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(Modifier.height(2.dp))

            Card(Icons.Default.Lock, "Connection", "Your Gemini API key") {
                Field(
                    key,
                    { key = it },
                    "Gemini API key (AIza...)",
                    visual = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardType = KeyboardType.Password
                )
                Text(
                    if (showKey) "Hide key" else "Show key",
                    color = MishtiColors.Accent,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .padding(top = 8.dp)
                        .clickable { showKey = !showKey }
                )
                Hint("Get a free key at aistudio.google.com. It stays on this phone and goes only to Google.")
            }

            Card(Icons.Default.Language, "Language", "Mishti speaks one language, never a mix") {
                Segmented(listOf("Bangla" to "bangla", "Hindi" to "hindi"), language) { language = it }
            }

            Card(Icons.Default.RecordVoiceOver, "Voice", "Pitch lighter, pace normal, tone clear") {
                VOICES.chunked(3).forEach { row ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        row.forEach { v -> Chip(v, v == voice, Modifier.weight(1f)) { voice = v } }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                Hint("Choose a voice, then Save. Turn Mishti off and on again to hear it.")
            }

            Card(Icons.Default.Person, "About you", "What Mishti calls you") {
                Field(name, { name = it }, "Your name")
            }

            Card(Icons.Default.Hearing, "Listening", "How Mishti hears you") {
                ToggleRow("Wake word mode", "Answers only when you say \"Hey Mishti\"", nameOnly) { nameOnly = it }
                ToggleRow("Interrupt anytime", "You can speak while she is talking", bargeIn) { bargeIn = it }
                ToggleRow("Noisy room", "Ignores background noise more", noisy) { noisy = it }
            }

            Card(Icons.Default.Psychology, "Smart features", "What Mishti does by herself") {
                ToggleRow("Web search", "Looks up news, weather and facts", webSearch) { webSearch = it }
                ToggleRow("Watch the phone", "Warns about battery, heat and storage", watch) { watch = it }
                ToggleRow("Speak up sometimes", "A short helpful word now and then", chatter) { chatter = it }
                Text("Most helpful remarks per day", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp, bottom = 8.dp))
                Segmented(listOf("1" to 1, "3" to 3, "5" to 5), proMax) { proMax = it; prefs.proactiveMax = it }
                Hint("Quiet from 10 pm to 8 am. Never while a game or a task is running. Say \"stop\" and she stays quiet for the day.")
            }

            Card(Icons.Default.Notifications, "Notifications", "Reading and clearing them") {
                ToggleRow("Tell me about new messages", "Mishti says who messaged", aloud) { aloud = it }
                Text("Junk notifications", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp, bottom = 8.dp))
                Segmented(listOf("Auto-clear" to "auto", "Ask first" to "ask", "Off" to "off"), junk) { junk = it }
            }

            Card(Icons.Default.Favorite, "Memory", "$noteCount things remembered") {
                Hint("Mishti also learns your habits and what you teach her.")
                Spacer(Modifier.height(8.dp))
                PillButton("Forget notes") { prefs.clearNotes(); noteCount = 0 }
                Spacer(Modifier.height(10.dp))
                ToggleRow("Remember our talks", "Short lines, never passwords or numbers", convOn) { convOn = it; prefs.convMemory = it }
                Hint("$convCount conversation lines saved.")
                Spacer(Modifier.height(8.dp))
                PillButton("Forget conversations") { prefs.clearJournal(); convCount = 0 }
                Spacer(Modifier.height(10.dp))
                Hint("$brainCount habits and lessons learned.")
                Spacer(Modifier.height(8.dp))
                PillButton("Forget habits and lessons") { prefs.clearBrainAll(); brainCount = 0 }
            }

            Card(Icons.Default.Psychology, "Last actions", "What Mishti just did, to find what went wrong") {
                if (logLines.isEmpty()) Hint("Nothing yet.")
                logLines.forEach { Text(it, color = MishtiColors.TextDim, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 4.dp)) }
                Spacer(Modifier.height(8.dp))
                PillButton("Refresh") { logLines = prefs.actionLog().take(15) }
                Spacer(Modifier.height(8.dp))
                PillButton("Clear") { prefs.clearActionLog(); logLines = emptyList() }
            }

            Card(Icons.Default.Shield, "Permissions", "Needed so Mishti can control the phone") {
                PermissionRow("Accessibility", "See and control the screen", accOn, "Turn on") {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermissionRow("Notification access", "Read your notifications", notifOn, "Turn on") {
                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                PermissionRow("Show over apps", "Work on top of other apps", overlayOn, "Allow") {
                    context.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + context.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
                PermissionRow("Run in background", "Keep listening when the screen is off", batteryFree, "Allow") {
                    context.startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + context.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
        }

        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(Brush.verticalGradient(0f to Color(0xFF7CC8FF), 1f to Color(0xFF2F7BFF)))
                .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(30.dp))
                .clickable {
                    prefs.apiKey = key
                    prefs.model = model
                    prefs.voice = voice
                    prefs.userName = name
                    prefs.silenceMs = silence
                    prefs.webSearch = webSearch
                    prefs.language = language
                    prefs.nameOnly = nameOnly
                    prefs.bargeIn = bargeIn
                    prefs.noisyRoom = noisy
                    prefs.deviceWatch = watch
                    prefs.spontaneous = chatter
                    prefs.junkMode = junk
                    prefs.notifyAloud = aloud
                    prefs.voicePitch = 1.12f
                    prefs.voiceSpeed = 1.0f
                    prefs.voicePolish = "clear"
                    prefs.voiceLoud = 1.3f
                    onSaved()
                }
                .padding(vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Save", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun Card(icon: ImageVector, title: String, subtitle: String, content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .liquid(RoundedCornerShape(26.dp), strength = 0.9f)
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(0f to Color(0x4D58B8FF), 1f to Color(0x262F7BFF))),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = MishtiColors.Accent, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.size(12.dp))
            Column {
                Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = MishtiColors.TextDim, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        content()
    }
}

@Composable
private fun Sub(t: String) {
    Text(t, color = Color(0xFFCBD8F0), fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp, bottom = 8.dp))
}

@Composable
private fun Hint(t: String) {
    Text(t, color = MishtiColors.TextDim, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 8.dp))
}

/** A glass track with a liquid thumb that slides, with a little spring, to the chosen option. */
@Composable
private fun <T> Segmented(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    val shape = RoundedCornerShape(50)
    val idx = options.indexOfFirst { it.second == selected }.coerceAtLeast(0)
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0x33000000))
            .liquid(shape, strength = 0.8f)
            .padding(4.dp)
    ) {
        val gap = 4.dp
        val thumbW = (maxWidth - gap * (options.size - 1)) / options.size
        val x by animateDpAsState(
            targetValue = (thumbW + gap) * idx,
            animationSpec = spring(dampingRatio = 0.65f, stiffness = 380f),
            label = "thumb"
        )
        Box(
            Modifier
                .offset(x = x)
                .width(thumbW)
                .height(38.dp)
                .clip(shape)
                .background(Brush.verticalGradient(0f to Color(0xFF6FBFFF), 1f to Color(0xFF2F7BFF)))
                .liquid(shape, strength = 1.3f)
        )
        Row(
            Modifier
                .fillMaxWidth()
                .height(38.dp),
            horizontalArrangement = Arrangement.spacedBy(gap)
        ) {
            options.forEach { (label, value) ->
                val on = value == selected
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(shape)
                        .clickable { onSelect(value) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label,
                        color = if (on) Color.White else MishtiColors.TextDim,
                        fontSize = 13.sp,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            Text(desc, color = MishtiColors.TextDim, fontSize = 12.sp, lineHeight = 17.sp)
        }
        Spacer(Modifier.size(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF2F7BFF),
                uncheckedThumbColor = Color(0xFFB8C4DD),
                uncheckedTrackColor = Color(0x33FFFFFF),
                uncheckedBorderColor = Color(0x33FFFFFF)
            )
        )
    }
}

@Composable
private fun PermissionRow(title: String, desc: String, on: Boolean, action: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (on) MishtiColors.Good else Color(0xFFFFC857))
                )
                Spacer(Modifier.size(8.dp))
                Text(title, color = Color.White, fontSize = 15.sp)
                Spacer(Modifier.size(8.dp))
                Text(if (on) "On" else "Off", color = if (on) MishtiColors.Good else Color(0xFFFFC857), fontSize = 12.sp)
            }
            Text(desc, color = MishtiColors.TextDim, fontSize = 12.sp, lineHeight = 17.sp)
        }
        Spacer(Modifier.size(12.dp))
        if (!on) PillButton(action, onClick)
    }
}

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    visual: VisualTransformation = VisualTransformation.None,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    val shape = RoundedCornerShape(16.dp)
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        visualTransformation = visual,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
        cursorBrush = SolidColor(MishtiColors.Accent),
        modifier = Modifier.fillMaxWidth(),
        decorationBox = { inner ->
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(Color(0x33000000))
                    .liquid(shape, strength = 0.8f)
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                if (value.isEmpty()) Text(placeholder, color = MishtiColors.TextDim, fontSize = 16.sp, maxLines = 1)
                inner()
            }
        }
    )
}

@Composable
private fun Chip(name: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .clip(shape)
            .background(if (selected) Color(0x3358B8FF) else Color(0x0DFFFFFF))
            .liquid(shape, strength = if (selected) 1.3f else 0.8f)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name,
            color = if (selected) Color.White else MishtiColors.TextDim,
            fontSize = 13.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun PillButton(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(shape)
            .background(Color(0x3358B8FF))
            .liquid(shape, strength = 1.2f)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}
