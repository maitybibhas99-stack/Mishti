package com.mishti.assistant

import android.app.Application
import android.content.Context

class MishtiApplication : Application() {
    /** One assistant for the whole process, so it survives the screen being closed. */
    val assistant: Assistant by lazy { Assistant(this) }

    override fun onCreate() {
        super.onCreate()
        restoreV51Voice()
    }

    /**
     * One time after this update: put the voice settings (pitch, speed, tone, loudness, voice name)
     * back to the V51 values, in case a saved setting made her voice deep. Later changes in Settings stick.
     */
    private fun restoreV51Voice() {
        try {
            val sp = getSharedPreferences("mishti", Context.MODE_PRIVATE)
            if (sp.getBoolean("voice_restored_v51", false)) return
            sp.edit()
                .remove("voice_pitch")
                .remove("voice_speed")
                .remove("voice_polish")
                .remove("voice_loud")
                .remove("voice")
                .putBoolean("voice_restored_v51", true)
                .apply()
        } catch (_: Exception) {
        }
    }
}
